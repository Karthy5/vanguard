"""
Signals API tests. Offline: feeds are replaced with synthetic snapshots.

    pytest -q
"""

import json
from datetime import datetime, timedelta

import pytest

from vanguard import config, feeds, model, signals


@pytest.fixture()
def tmp_data(tmp_path, monkeypatch):
    monkeypatch.setattr(config, "DATA_DIR", tmp_path)
    monkeypatch.setattr(config, "BASELINE_PATH", tmp_path / "baseline.json")
    monkeypatch.setattr(config, "BACKTEST_PATH", tmp_path / "backtest.json")
    monkeypatch.setattr(config, "ZONES_GEOJSON_PATH", tmp_path / "taxi_zones.geojson")
    model.CAL.reload()
    return tmp_path


def _hour(offset):
    return datetime.now().replace(minute=0, second=0, microsecond=0) + timedelta(hours=offset)


def _live(rain_from=2, wind=10.0, temp=55.0, events=None):
    hourly = {}
    for i in range(-2, 30):
        t = _hour(i)
        wet = i >= rain_from
        hourly[t.strftime("%Y-%m-%dT%H")] = {"temp_f": temp, "precip_mm": 1.5 if wet else 0.0,
                                             "precip_prob": 80 if wet else 5, "wind_mph": wind}
    return {
        "weather": {"status": "live", "fetched_at": "x", "temp_f": temp, "precip_mm": 0.0,
                    "wind_mph": wind, "hourly": hourly},
        "traffic": {"status": "live", "median_mph": {"Manhattan": 8.0, "Queens": 18.0}},
        "airports": {"status": "live", "delays": {"JFK": ["Ground delay 45 min"], "LGA": []}},
        "events": {"status": "live", "events": events or []},
    }


def _offline():
    return {"weather": {"status": "offline"}, "traffic": {"status": "offline"},
            "airports": {"status": "offline"}, "events": {"status": "disabled", "events": []}}


def _all_keys(obj):
    if isinstance(obj, dict):
        for k, v in obj.items():
            yield k
            yield from _all_keys(v)
    elif isinstance(obj, list):
        for v in obj:
            yield from _all_keys(v)


def test_signals_shape_and_no_earnings(tmp_data):
    s = signals.build(_live(), hours=4)
    assert s["window"]["hours"] == 4 and len(s["city_hours"]) == 4
    assert len(s["zones"]) == len(model.zones())
    assert all(len(z["hours"]) == 4 for z in s["zones"])
    # The partner API never carries earnings or pay estimates
    banned = {"est", "lo", "hi", "pay_rate", "pay_per_engaged_hr", "utilization", "p25", "p75"}
    assert not banned & set(_all_keys(s))
    assert "$" not in json.dumps(s)


def test_rain_onset_alert_and_weather_effect(tmp_data):
    s = signals.build(_live(rain_from=2), hours=4)
    types = [[a["type"] for a in h["alerts"]] for h in s["city_hours"]]
    assert "rain_onset" not in types[0] and "rain_onset" not in types[1]
    assert "rain_onset" in types[2] and "rain_onset" not in types[3]
    midtown = next(z for z in s["zones"] if z["zone_id"] == 161)
    assert midtown["hours"][0]["weather_trip_effect_pct"] == 0.0
    assert midtown["hours"][2]["weather_trip_effect_pct"] > 0   # prior: rain raises trips


def test_wind_cold_and_ice_alerts(tmp_data):
    s = signals.build(_live(rain_from=0, wind=30.0, temp=31.0), hours=1)
    types = {a["type"] for a in s["city_hours"][0]["alerts"]}
    assert {"high_wind", "ice_risk"} <= types
    s = signals.build(_live(rain_from=99, temp=15.0), hours=1)
    assert {a["type"] for a in s["city_hours"][0]["alerts"]} == {"cold"}


def test_event_phases(tmp_data):
    t0 = _hour(0)
    ev = {"name": "Show", "venue": "Madison Square Garden", "segment": "Music", "zone_id": 186,
          "start": (t0 + timedelta(hours=1)).isoformat(), "est_end": (t0 + timedelta(hours=4)).isoformat(),
          "capacity_est": 19500}
    s = signals.build(_live(events=[ev]), hours=5, zone_ids={186, 161})
    msg = next(z for z in s["zones"] if z["zone_id"] == 186)
    phases = [[e["phase"] for e in h["events"]] for h in msg["hours"]]
    assert phases[0] == ["arrivals"] and phases[1] == [] and phases[4] == ["let_out"]
    let_out = msg["hours"][4]["events"][0]
    arrivals = msg["hours"][0]["events"][0]
    assert let_out["demand_lift_pct"] > arrivals["demand_lift_pct"] > 0
    other = next(z for z in s["zones"] if z["zone_id"] == 161)
    assert all(h["events"] == [] for h in other["hours"])


def test_traffic_airports_and_seasonal_index(tmp_data):
    s = signals.build(_live(), hours=1)
    z = {r["zone_id"]: r for r in s["zones"]}
    assert z[161]["now"]["traffic"]["speed_mph"] == 8.0
    assert z[161]["now"]["traffic"]["ratio_to_typical"] == round(8.0 / config.DEFAULT_SPEED_MPH["Manhattan"], 2)
    assert z[132]["now"]["airport_delays"] == ["Ground delay 45 min"]
    assert z[161]["now"]["airport_delays"] is None
    idx = sorted(r["hours"][0]["seasonal_trip_index"] for r in s["zones"])
    assert idx[len(idx) // 2] == 1.0
    assert s["calibration"]["mode"] == "priors"
    assert s["provenance"]["zones[].hours[].seasonal_trip_index"].startswith("placeholder_prior")


def test_offline_feeds_degrade_to_nulls(tmp_data):
    s = signals.build(_offline(), hours=3)
    assert all(h["weather"] is None and h["alerts"] == [] for h in s["city_hours"])
    assert all(r["now"]["traffic"]["speed_mph"] is None for r in s["zones"])
    assert s["sources"]["weather"]["status"] == "offline"
    assert s["sources"]["events"]["status"] == "disabled"


def test_signals_api_and_key(tmp_data, monkeypatch):
    import app as webapp
    monkeypatch.setattr(feeds, "snapshot", _live)
    c = webapp.app.test_client()
    r = c.get("/api/v1/signals?hours=2&zones=161,132")
    assert r.status_code == 200
    assert {z["zone_id"] for z in r.get_json()["zones"]} == {161, 132}
    assert c.get("/api/v1/signals?zones=999").status_code == 400
    assert c.get("/api/v1/signals?start=tomorrow").status_code == 400
    assert c.get("/api/v1/zones").get_json()["features"][0]["properties"]["region_id"]
    assert c.get("/api/v1/health").get_json()["sources"]["weather"] == "live"

    monkeypatch.setattr(config, "SIGNALS_API_KEY", "secret")
    assert c.get("/api/v1/signals").status_code == 401
    assert c.get("/api/v1/signals", headers={"X-API-Key": "wrong"}).status_code == 401
    assert c.get("/api/v1/signals?hours=1", headers={"X-API-Key": "secret"}).status_code == 200
    assert c.get("/api/zones").status_code == 200   # demo routes stay open
