"""
End-to-end tests on synthetic data with a known weather effect.
They check that the pipeline recovers a planted effect and that the
planner/app work offline. No network needed.

    pytest -q
"""

import json
import random
from datetime import datetime, timedelta

import duckdb
import numpy as np
import pytest

from vanguard import build, config, model, zones
from vanguard.stats import ols

PLANTED_RAIN_EFFECT = 0.15   # +15% trips per mm/hr


@pytest.fixture()
def tmp_data(tmp_path, monkeypatch):
    monkeypatch.setattr(config, "DATA_DIR", tmp_path)
    monkeypatch.setattr(config, "RAW_DIR", tmp_path / "raw")
    monkeypatch.setattr(config, "BASELINE_PATH", tmp_path / "baseline.json")
    monkeypatch.setattr(config, "BACKTEST_PATH", tmp_path / "backtest.json")
    monkeypatch.setattr(config, "ZONES_GEOJSON_PATH", tmp_path / "taxi_zones.geojson")
    return tmp_path


def _synthetic_weather(start, hours, seed=7):
    rng = random.Random(seed)
    rows, raining = [], 0
    for i in range(hours):
        ts = start + timedelta(hours=i)
        if raining == 0 and rng.random() < 0.03:
            raining = rng.randint(2, 8)
        p = round(rng.uniform(0.3, 4.0), 2) if raining else 0.0
        raining = max(0, raining - 1)
        rows.append((ts, 55 + 10 * np.sin(i / 24 * 2 * np.pi), p))
    return rows


def _synthetic_trips(path, weather):
    con = duckdb.connect()
    con.execute("SELECT setseed(0.42)")
    con.execute("CREATE TABLE wx (ts TIMESTAMP, temp DOUBLE, precip DOUBLE)")
    con.executemany("INSERT INTO wx VALUES (?, ?, ?)", weather)
    ids = ",".join(str(z) for z in zones.zone_ids())
    con.execute(f"""
        COPY (
          WITH lam AS (
            SELECT z.zone, w.ts,
                   (4 + 8 * (hour(w.ts) BETWEEN 17 AND 22)::INT + (z.zone % 5))
                   * (1 + {PLANTED_RAIN_EFFECT} * w.precip) AS lam
            FROM (SELECT unnest([{ids}]) AS zone) z, wx w
          ),
          n AS (SELECT zone, ts, greatest(0, round(lam + (random() - 0.5) * 2 * sqrt(lam)))::INT AS k FROM lam)
          SELECT zone AS PULocationID,
                 CASE WHEN random() < 0.5 THEN zone ELSE ([{ids}])[1 + (random() * {len(zones.zone_ids()) - 1})::INT] END AS DOLocationID,
                 ts + to_minutes((random() * 59)::INT) AS pickup_datetime,
                 18 + random() * 12 AS driver_pay,
                 1.5 AS tips,
                 600 + random() * 1200 AS trip_time
          FROM n, generate_series(1, n.k) g
          WHERE n.k > 0
        ) TO '{path.as_posix()}' (FORMAT PARQUET)
    """)


def test_ols_recovers_known_slope():
    rng = np.random.default_rng(0)
    x = rng.normal(size=2000)
    y = 1.0 + 2.5 * x + rng.normal(scale=0.5, size=2000)
    X = np.column_stack([np.ones_like(x), x])
    res = ols(X, y, ["intercept", "x"], clusters=np.arange(2000) // 24)
    b = res["coefs"][1]
    assert b["ci95"][0] < 2.5 < b["ci95"][1]


def test_build_recovers_planted_rain_effect(tmp_data, monkeypatch):
    start = datetime(2025, 7, 1)
    weather = _synthetic_weather(start, 24 * 42)
    parquet = tmp_data / "raw" / "fhvhv_tripdata_2025-07.parquet"
    parquet.parent.mkdir(parents=True)
    _synthetic_trips(parquet, weather)

    monkeypatch.setattr(build, "download_month", lambda ym: parquet)
    monkeypatch.setattr(build, "fetch_weather_archive", lambda s, e: weather)
    monkeypatch.setattr(build, "fetch_zone_polygons", lambda: False)
    build.run(["2025-07"])

    bt = json.loads(config.BACKTEST_PATH.read_text())
    coefs = {c["name"]: c for c in bt["final_fit"]["demand"]["coefs"]}
    # log(1+trips) slope near log(1.15) ~ 0.14 at these volumes. Check sign and rough size.
    assert 0.05 < coefs["precip_mm"]["beta"] < 0.2
    assert bt["holdout"]["demand"]["rain_error_reduction_pct"] > 0
    base = json.loads(config.BASELINE_PATH.read_text())
    assert str(zones.zone_ids()[0]) in base["zones"]
    # destination flows: shares from each region sum to 1
    f = base["flows"]["4"]["midtown_west"]
    assert abs(sum(f.values()) - 1) < 1e-3 and f["midtown_west"] > 0.3


def _offline_live():
    return {"weather": {"status": "offline"}, "traffic": {"status": "offline"},
            "airports": {"status": "offline"}, "events": {"status": "disabled", "events": []}}


def test_plan_offline_priors(tmp_data):
    model.CAL.reload()
    assert not model.CAL.calibrated
    layers = {"weather": True, "events": True, "travel": True}
    p = model.plan("jersey_city", 18, 5, layers, _offline_live())
    assert p["ranking"] and p["plan"]["blocks"]
    assert sum(len(b["hours"]) for b in p["plan"]["blocks"]) == 5
    # Viterbi is at least as good as the best stay-put option
    assert p["plan"]["total"] >= p["plan"]["stay_put_best"] - 1e-6
    # Coming from NJ, Manhattan zones carry the Hudson toll
    mn = next(r for r in p["ranking"] if r["borough"] == "Manhattan")
    assert mn["commute"]["toll"] == config.HUDSON_TOLL_USD


def test_event_lift_applies_at_egress(tmp_data):
    model.CAL.reload()
    when = datetime.now().replace(minute=0, second=0, microsecond=0)
    ev = {"zone_id": 186, "venue": "Madison Square Garden", "capacity_est": 19500,
          "start": (when - timedelta(hours=2)).isoformat(), "est_end": (when + timedelta(minutes=30)).isoformat()}
    live = {**_offline_live(), "events": {"status": "live", "events": [ev]}}
    on = model.hour_estimates(when, live, {"weather": False, "events": True, "travel": True})
    off = model.hour_estimates(when, live, {"weather": False, "events": False, "travel": True})
    assert on[186]["est"] > off[186]["est"]
    assert on[161]["est"] == pytest.approx(off[161]["est"])


def test_point_in_polygon():
    sq = {"type": "Polygon", "coordinates": [[[0, 0], [1, 0], [1, 1], [0, 1], [0, 0]]]}
    assert zones.point_in_geometry(0.5, 0.5, sq)
    assert not zones.point_in_geometry(1.5, 0.5, sq)


def test_api_smoke(tmp_data, monkeypatch):
    import app as webapp
    from vanguard import feeds
    monkeypatch.setattr(feeds, "snapshot", _offline_live)
    model.CAL.reload()
    c = webapp.app.test_client()
    r = c.get("/api/plan?origin=astoria&start=19&hours=4&weather=1&events=1&travel=1")
    assert r.status_code == 200 and r.get_json()["plan"]["blocks"]
    assert c.get("/api/zones").status_code == 200
    assert c.get("/api/backtest").get_json()["backtest"] is None
    assert c.get("/").status_code == 200


def test_driver_start_at_and_gps_origin(tmp_data, monkeypatch):
    import app as webapp
    from vanguard import feeds
    monkeypatch.setattr(feeds, "snapshot", _offline_live)
    model.CAL.reload()
    c = webapp.app.test_client()
    # A plan pinned to a start two hours ago must stay on that start (mid-shift)
    start = (datetime.now() - timedelta(hours=2)).replace(minute=0, second=0, microsecond=0)
    r = c.get(f"/api/plan?origin=here&lat=40.7178&lon=-74.0431&hours=5&start_at={start.isoformat(timespec='minutes')}")
    d = r.get_json()
    assert r.status_code == 200
    assert d["start"] == start.isoformat(timespec="minutes")
    assert d["origin"]["borough"] == "New Jersey"          # Jersey City GPS fix
    assert c.get("/api/plan?origin=here").status_code == 400
    assert c.get("/driver").status_code == 200
    assert model.borough_for_point(40.6782, -73.9442) == "Brooklyn"


def test_event_pulls_plan_and_moves_are_partly_paid(tmp_data):
    model.CAL.reload()
    start = model._start_time(18)
    msg = {"zone_id": 186, "venue": "Madison Square Garden", "capacity_est": 19500,
           "start": (start + timedelta(hours=1)).isoformat(), "est_end": (start + timedelta(hours=3, minutes=45)).isoformat()}
    layers = {"weather": True, "events": True, "travel": True}
    live = {**_offline_live(), "events": {"status": "live", "events": [msg]}}
    p = model.plan("crown_heights", 18, 6, layers, live)
    egress_hour = (start + timedelta(hours=3)).isoformat(timespec="minutes")
    region_at_egress = next(b["region_id"] for b in p["plan"]["blocks"] if any(h["t"] == egress_hour for h in b["hours"]))
    assert region_at_egress == "midtown_west"
    moves = [b["arrive"] for b in p["plan"]["blocks"][1:]]
    assert moves and all(m["paid_share"] >= config.REPOSITION_PAID_MIN for m in moves)
    assert all(m["unpaid_minutes"] < m["minutes"] for m in moves)


def test_no_platform_specific_strftime():
    # %-I style codes crash on Windows. Keep them out of the codebase.
    import pathlib
    root = pathlib.Path(__file__).resolve().parent.parent
    for f in list((root / "vanguard").glob("*.py")) + [root / "app.py"]:
        assert "%-" not in f.read_text(encoding="utf-8"), f.name
    assert model._clock(datetime(2026, 11, 7, 21, 45)) == "9:45pm"
    assert model._clock(datetime(2026, 11, 7, 0, 0)) == "12am"


def test_api_errors_are_json(tmp_data, monkeypatch):
    import app as webapp
    from vanguard import feeds
    monkeypatch.setattr(feeds, "snapshot", _offline_live)
    monkeypatch.setattr(model, "plan", lambda *a, **k: 1 / 0)
    r = webapp.app.test_client().get("/api/plan?origin=midtown")
    assert r.status_code == 500 and "ZeroDivisionError" in r.get_json()["error"]
