"""
Parsers and aggregations for the added public sources, on sample payloads
shaped like the real ones. Offline.

    pytest -q
"""

import json
from datetime import datetime, timedelta

import pytest

from vanguard import config, extras, feeds, model, signals
from vanguard.stateplane import to_latlon


@pytest.fixture()
def tmp_data(tmp_path, monkeypatch):
    for name, fn in [("DATA_DIR", ""), ("BASELINE_PATH", "baseline.json"), ("BACKTEST_PATH", "backtest.json"),
                     ("ZONES_GEOJSON_PATH", "taxi_zones.geojson"), ("EXTRAS_PATH", "extras.json")]:
        monkeypatch.setattr(config, name, tmp_path / fn if fn else tmp_path)
    model.CAL.reload()
    return tmp_path


# ---------------------------------------------------------------------------
# Small helpers
# ---------------------------------------------------------------------------
def test_stateplane_matches_reference_projection():
    # Reference values from pyproj (EPSG:2263 -> EPSG:4326)
    ref = {(1003823, 229840): (40.79751200639324, -73.92930750750912),
           (988000, 211900): (40.74829228276725, -73.98646600120296),
           (913788, 120939): (40.498344667755966, -74.25335185022024),
           (1067214, 271703): (40.91204497869009, -73.69983901507636)}
    for (x, y), (lat, lon) in ref.items():
        got = to_latlon(x, y)
        assert abs(got[0] - lat) < 1e-6 and abs(got[1] - lon) < 1e-6
    assert to_latlon(None, 5) is None


@pytest.mark.parametrize("raw,hour", [("0840A", 8), ("1230A", 0), ("1205P", 12), ("0105P", 13),
                                      ("1159P", 23), ("", None), ("2500A", None), ("08:40", None)])
def test_ticket_time(raw, hour):
    assert extras.parse_ticket_hour(raw) == hour


def test_dow_and_precinct_parsing():
    assert extras.soql_dow_to_python(0) == 6       # Sunday
    assert extras.soql_dow_to_python(1) == 0       # Monday
    assert extras.parse_precincts("14, 18,") == [14, 18]
    assert feeds._precincts(" 25,") == [25]


# ---------------------------------------------------------------------------
# Live feed parsers
# ---------------------------------------------------------------------------
def test_nws_dedupes_across_boroughs_and_converts_time():
    feat = {"properties": {"id": "urn:a1", "event": "Wind Advisory", "severity": "Moderate",
                           "headline": "Wind Advisory until 6 PM", "onset": "2026-12-04T15:00:00+00:00",
                           "ends": "2026-12-04T23:00:00+00:00"}}
    out = feeds.parse_nws({"Manhattan": [feat], "Brooklyn": [feat], "Queens": []})
    assert len(out) == 1 and out[0]["boroughs"] == ["Manhattan", "Brooklyn"]
    assert out[0]["start"] == "2026-12-04T10:00"            # 15:00 UTC = 10:00 EST


def _mta(now, camel=False):
    ap, ie, ht = ("activePeriod", "informedEntity", "headerText") if camel else ("active_period", "informed_entity", "header_text")
    rid, sid = ("routeId", "stopId") if camel else ("route_id", "stop_id")
    ts = lambda dt: int(dt.timestamp())  # noqa: E731
    return {"entity": [
        {"id": "a", "alert": {ap: [{"start": ts(now - timedelta(minutes=10))}],
                              ie: [{rid: "A"}, {sid: "A27"}],
                              ht: {"translation": [{"text": "<p>x</p>", "language": "en-html"},
                                                   {"text": "A trains delayed", "language": "en"}]},
                              "transit_realtime.mercury_alert": {"alert_type": "Delays"}}},
        {"id": "b", "alert": {ap: [{"start": ts(now + timedelta(days=3)), "end": ts(now + timedelta(days=4))}],
                              ie: [{rid: "L"}], ht: {"translation": [{"text": "Weekend work"}]},
                              "transit_realtime.mercury_alert": {"alert_type": "Planned - Suspended"}}},
        {"id": "c", "alert": {ap: [{"start": ts(now + timedelta(hours=2)), "end": ts(now + timedelta(hours=6))}],
                              ie: [{rid: "Q"}], ht: {"translation": [{"text": "Tonight"}]},
                              "transit_realtime.mercury_alert": {"alert_type": "Planned - Part Suspended"}}},
    ]}


@pytest.mark.parametrize("camel", [False, True])
def test_mta_alerts_window_and_fields(camel):
    now = datetime.now().replace(microsecond=0)
    out = feeds.parse_mta_alerts(_mta(now, camel), "subway", now=now)
    assert [a["id"] for a in out] == ["a", "c"]               # 3 days out is beyond the 24h window
    a = out[0]
    assert a["header"] == "A trains delayed" and a["routes"] == ["A"] and a["stops"] == ["A27"]
    assert a["alert_type"] == "Delays" and not a["planned"] and out[1]["planned"]


def test_permits_skip_league_games_unless_streets_close():
    rows = [
        {"event_id": "1", "event_name": "Soccer", "event_type": "Sport - Youth", "street_closure_type": "N/A",
         "start_date_time": "2026-12-04T08:00:00.000", "end_date_time": "2026-12-04T12:00:00.000", "police_precinct": "25,"},
        {"event_id": "2", "event_name": "Street Fair", "event_type": "Street Event",
         "street_closure_type": "Full Street Closure", "event_location": "BROADWAY between W 34 ST and W 42 ST",
         "start_date_time": "2026-12-04T10:00:00.000", "end_date_time": "2026-12-04T18:00:00.000",
         "police_precinct": "14, 18,"},
        {"event_id": "3", "event_name": "Run", "event_type": "Sport - Adult", "street_closure_type": "Full Street Closure",
         "start_date_time": "2026-12-04T07:00:00.000", "end_date_time": "2026-12-04T09:00:00.000", "police_precinct": "20,"},
    ]
    out = feeds.parse_permits(rows)
    assert [e["id"] for e in out] == ["2", "3"]
    assert out[0]["precincts"] == [14, 18] and out[0]["street_closure"] == "Full Street Closure"


def test_closure_midpoint_and_gbfs_join():
    rows = [{"the_geom": {"type": "MultiLineString", "coordinates": [[[-73.99, 40.75], [-73.989, 40.751], [-73.988, 40.752]]]},
             "onstreetname": "W 34 ST", "work_end_date": "2026-12-20T00:00:00.000"}]
    c = feeds.parse_closures(rows)[0]
    assert (c["lat"], c["lon"]) == (40.751, -73.989) and c["end"] == "2026-12-20"
    info = {"data": {"stations": [{"station_id": "s1", "lat": 40.75, "lon": -73.99},
                                  {"station_id": "s2", "lat": 40.76, "lon": -73.98}]}}
    stat = {"data": {"stations": [{"station_id": "s1", "num_bikes_available": 5, "num_ebikes_available": 2,
                                   "num_docks_available": 9, "is_renting": 1},
                                  {"station_id": "s2", "num_bikes_available": 3, "is_renting": 0}]}}
    st = feeds.parse_gbfs(info, stat)
    assert len(st) == 1 and st[0]["ebikes"] == 2


# ---------------------------------------------------------------------------
# Build-time aggregations
# ---------------------------------------------------------------------------
MIDTOWN_BOX = {"type": "MultiPolygon", "coordinates": [[[[-74.01, 40.74], [-73.96, 40.74], [-73.96, 40.77],
                                                         [-74.01, 40.77], [-74.01, 40.74]]]]}


def test_precinct_mapping(tmp_data):
    zone_pct, pct_zones = extras.zones_by_precinct([{"precinct": "14", "the_geom": MIDTOWN_BOX}])
    assert zone_pct[186] == 14 and zone_pct[161] == 14 and 132 not in zone_pct
    assert 186 in pct_zones["14"]


def test_subway_ridership_crash_ticket_and_curb_aggregation(tmp_data):
    stations = [{"gtfs_stop_id": "A28", "complex_id": "611", "daytime_routes": "A C E", "gtfs_latitude": "40.7496",
                 "gtfs_longitude": "-73.9925"},
                {"gtfs_stop_id": "X99", "complex_id": "999", "daytime_routes": "Z", "gtfs_latitude": "40.60",
                 "gtfs_longitude": "-73.80"}]                     # far from any tracked zone
    m = extras.subway_maps(stations)
    assert m["stop_zone"] == {"A28": 186} and m["complex_zone"] == {"611": 186}
    assert m["route_zones"]["A"] == [186] and "Z" not in m["route_zones"]

    rid = extras.ridership_by_zone([{"station_complex_id": "611", "dow": "1", "hr": "8", "riders": "800"},
                                    {"station_complex_id": "999", "dow": "1", "hr": "8", "riders": "5"}],
                                   m["complex_zone"], weeks=8)
    assert rid == {"186": {"0-8": 100.0}}                       # Monday 8am, 800 / 8 weeks

    cr = extras.crashes_by_zone([{"crash_time": "8:15", "latitude": "40.7496", "longitude": "-73.9925",
                                  "number_of_cyclist_injured": "1"},
                                 {"crash_time": "9:40", "latitude": None, "longitude": None}], days=365)
    assert cr["186"]["injury_crashes"]["08-12"] == 1.0 and cr["186"]["cyclist_injuries"]["08-12"] == 1.0

    tk = extras.tickets_by_precinct([{"violation_precinct": "14", "violation_time": "0840A", "n": "900"},
                                     {"violation_precinct": "14", "violation_time": "0815A", "n": "90"},
                                     {"violation_precinct": "0", "violation_time": "0840A", "n": "5"}], days=90)
    assert tk == {"14": {"8": 11.0}}

    # (988000, 211900) is ~W 35th St & Broadway, inside Midtown South (164)
    relief = [{"order_number": "P-1", "on_street": "W 35 ST", "sign_x_coord": "988000", "sign_y_coord": "211900",
               "sign_description": "TAXI RELIEF STAND"},
              {"order_number": "P-1", "sign_x_coord": "988010", "sign_y_coord": "211905"}]
    loading = [{"order_number": "P-2", "sign_x_coord": "988000", "sign_y_coord": "211900"},
               {"order_number": "P-2", "sign_x_coord": "988020", "sign_y_coord": "211900"},
               {"order_number": "P-3", "sign_x_coord": "988000", "sign_y_coord": "211950"}]
    curb = extras.curb_by_zone(relief, loading)
    assert len(curb["164"]["relief_stands"]) == 1 and curb["164"]["loading_zone_blocks"] == 2


# ---------------------------------------------------------------------------
# Signals with every source present
# ---------------------------------------------------------------------------
def _hour(offset=0):
    return datetime.now().replace(minute=0, second=0, microsecond=0) + timedelta(hours=offset)


def _write_extras(path):
    t = _hour()
    path.write_text(json.dumps({
        "meta": {"generated_at": "x", "sections": {"subway": {"status": "ok"}}},
        "precincts": {"zone_precinct": {"186": 14, "161": 18}, "precinct_zones": {"14": [186], "18": [161]}},
        "subway": {"stop_zone": {"A28": 186}, "route_zones": {"Q": [161, 186]}},
        "ridership": {"zones": {"186": {f"{t.weekday()}-{t.hour}": 900.0},
                                "161": {f"{t.weekday()}-{t.hour}": 300.0}}},
        "crashes": {"zones": {"186": {"injury_crashes": {f"{(t.hour // 4) * 4:02d}-{(t.hour // 4) * 4 + 4:02d}": 12.0},
                                      "cyclist_injuries": {}}}},
        "tickets": {"precincts": {"14": {str(t.hour): 40.0}}},
        "curb": {"zones": {"186": {"relief_stands": [{"on_street": "W 31 ST"}], "loading_zone_blocks": 7}}},
    }))


def _full_live():
    t = _hour()
    iso = lambda dt: dt.isoformat(timespec="minutes")  # noqa: E731
    return {
        "weather": {"status": "offline"}, "traffic": {"status": "offline"}, "airports": {"status": "offline"},
        "events": {"status": "disabled", "events": []},
        "nws_alerts": {"status": "live", "alerts": [{"event": "Winter Storm Warning", "severity": "Severe",
                                                     "headline": "Snow", "boroughs": ["Manhattan"],
                                                     "start": iso(t + timedelta(hours=1)), "end": None}]},
        "transit_alerts": {"status": "live", "alerts": [
            {"mode": "subway", "alert_type": "Delays", "planned": False, "routes": ["A"], "stops": ["A28N"],
             "header": "A delays", "start": iso(t), "end": None},
            {"mode": "subway", "alert_type": "Suspended", "planned": False, "routes": ["Q"], "stops": [],
             "header": "No Q", "start": iso(t), "end": None},
            {"mode": "lirr", "alert_type": "Delays", "planned": False, "routes": ["1"], "stops": [],
             "header": "LIRR delays", "start": iso(t), "end": None}]},
        "permitted_events": {"status": "live", "events": [
            {"name": "Street Fair", "type": "Street Event", "street_closure": "Full Street Closure",
             "location": "W 34 ST", "precincts": [14], "start": iso(t - timedelta(hours=1)),
             "end": iso(t + timedelta(hours=1, minutes=30))}]},
        "street_closures": {"status": "live", "fetched_at": "f1", "closures": [
            {"on_street": "W 31 ST", "from_street": "8 AV", "to_street": "9 AV", "purpose": "PAVING",
             "end": "2026-12-20", "lat": 40.7496, "lon": -73.9925}]},
        "citibike": {"status": "live", "fetched_at": "f1", "stations": [
            {"lat": 40.7496, "lon": -73.9925, "bikes": 4, "ebikes": 3, "docks": 10}]},
    }


def test_signals_use_every_source(tmp_data):
    _write_extras(config.EXTRAS_PATH)
    s = signals.build(_full_live(), hours=3, zone_ids={186, 161})
    assert s["extras"]["built"]
    z = {r["zone_id"]: r for r in s["zones"]}
    msg, mid = z[186], z[161]

    assert [a["type"] for a in s["city_hours"][1]["alerts"]] == ["nws"]
    assert s["city_hours"][0]["alerts"] == []

    tr = {a["header"]: a["match"] for a in msg["now"]["transit_alerts"]}
    assert tr == {"A delays": "stop", "No Q": "route", "LIRR delays": "terminal"}
    assert [a["header"] for a in mid["now"]["transit_alerts"]] == ["No Q"]

    assert msg["now"]["street_closures"]["count"] == 1 and mid["now"]["street_closures"]["count"] == 0
    assert msg["now"]["citibike"] == {"stations": 1, "bikes": 4, "ebikes": 3, "docks": 10}
    assert mid["now"]["citibike"] is None

    h0, h2 = msg["hours"][0], msg["hours"][2]
    assert [p["name"] for p in h0["permitted_events"]] == ["Street Fair"] and h2["permitted_events"] == []
    assert mid["hours"][0]["permitted_events"] == []
    assert h0["subway_entries_per_hr"] == 900.0 and h0["subway_entries_index"] == 1.0
    assert mid["hours"][0]["subway_entries_index"] == pytest.approx(0.33, abs=0.01)
    assert h0["injury_crashes_per_yr"] == 12.0 and h0["parking_tickets_per_day"] == 40.0
    assert mid["hours"][0]["parking_tickets_per_day"] is None            # precinct 18 has no ticket rows
    assert msg["curb"]["loading_zone_blocks"] == 7 and msg["police_precinct"] == 14
    assert "$" not in json.dumps(s)


def test_signals_without_extras_report_nulls(tmp_data):
    s = signals.build(_full_live(), hours=1, zone_ids={186})
    z = s["zones"][0]
    assert not s["extras"]["built"] and z["curb"] is None and z["police_precinct"] is None
    h = z["hours"][0]
    assert h["subway_entries_per_hr"] is None and h["injury_crashes_per_yr"] is None
    assert h["permitted_events"] == []        # can't place permits without precincts


def test_windows_cover_the_range_without_gaps():
    end = datetime(2026, 11, 1)
    w = extras._windows(end, 90, 10)
    assert w[0][1] == end and w[-1][0] == end - timedelta(days=90) and len(w) == 9
    assert all(a[0] == b[1] for a, b in zip(w, w[1:]))
    assert extras._windows(end, 7 * 8, 7)[-1][0] == end - timedelta(weeks=8)


def test_socrata_retries_then_succeeds(monkeypatch):
    import requests
    from vanguard import socrata
    calls = []

    class Resp:
        def __init__(self, code):
            self.status_code = code

        def raise_for_status(self):
            if self.status_code >= 400:
                raise requests.HTTPError(response=self)

        def json(self):
            return [{"ok": 1}]

    seq = [requests.Timeout(), Resp(503), Resp(200)]

    def fake_get(*a, **k):
        calls.append(1)
        x = seq.pop(0)
        if isinstance(x, Exception):
            raise x
        return x
    monkeypatch.setattr(socrata.requests, "get", fake_get)
    monkeypatch.setattr(socrata.time, "sleep", lambda s: None)
    assert socrata.get("d", "x") == [{"ok": 1}] and len(calls) == 3

    seq[:] = [Resp(400)]
    with pytest.raises(requests.HTTPError):
        socrata.get("d", "x")        # client errors are not retried
