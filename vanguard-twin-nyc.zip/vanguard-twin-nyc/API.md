# Vanguard Signals API v1

The Signals API gives an hour-by-hour view of conditions in each tracked NYC zone: weather and safety alerts, demand signals, transit disruptions, traffic, street closures, curb access and risk. It's built for a partner to plug into its own earnings model and assistant.

**It returns no earnings estimates.** The partner combines these signals with its own earnings data. Every field is labeled as live, aggregated from public records, learned from public data, or an assumption.

All data comes from public sources (see [Sources and terms](#sources-and-terms)).

## Endpoints

| Method | Path | What it returns |
|---|---|---|
| GET | `/api/v1/signals` | Signals for each zone × hour in a time window |
| GET | `/api/v1/zones` | Tracked zones as GeoJSON (TLC polygons after a build, otherwise points) |
| GET | `/api/v1/health` | API version, calibration mode, build-time data status, and live / stale / offline status per source |

### Authentication

If `SIGNALS_API_KEY` is set in `.env`, every `/api/v1` request must send it:

```
X-API-Key: <key>
```

A missing or wrong key returns `401`. With no key set, the API is open, which is fine on localhost but not on a public host.

### `GET /api/v1/signals`

| Parameter | Default | Notes |
|---|---|---|
| `hours` | `6` | 1–24 clock hours |
| `start` | current hour | ISO 8601 local NYC time, e.g. `2026-12-04T18:00`. Rounded down to the hour |
| `zones` | all tracked | Comma-separated TLC LocationIDs, e.g. `161,186,132`. Unknown IDs return `400` with the tracked list |

```bash
curl -H "X-API-Key: $KEY" "http://localhost:5001/api/v1/signals?hours=3&zones=186,132"
```

Look-ahead varies by source:

- **About 48 hours:** weather forecasts.
- **About 24 hours:** events and permits.
- **Current only:** traffic, airport delays, transit alerts, street closures and Citi Bike. These sit under `now`, not under each hour.

## Response

Values below are illustrative.

```json
{
  "api_version": "1.0",
  "generated_at": "2026-12-04T21:05:12",
  "timezone": "America/New_York",
  "window": {"start": "2026-12-04T21:00", "hours": 2},
  "calibration": {"mode": "calibrated", "message": "Calibrated on 38,512,004 TLC HVFHV trips (2026-08, 2026-09)"},
  "extras": {"built": true, "generated_at": "2026-12-01T09:12:44", "sections": {"ridership": {"status": "ok"}}},
  "sources": {"nws_alerts": {"provider": "National Weather Service alerts ...", "status": "live",
                             "fetched_at": "2026-12-04T21:03:40", "error": null, "terms": "..."}},
  "provenance": {"zones[].hours[].subway_entries_per_hr": "public records: ..."},
  "city_hours": [
    {"t": "2026-12-04T22:00",
     "weather": {"temp_f": 33.0, "precip_mm": 1.5, "precip_prob_pct": 80, "wind_mph": 12.0},
     "alerts": [
       {"type": "rain_onset", "message": "Rain likely to start this hour"},
       {"type": "ice_risk", "message": "Precipitation near freezing; roads and bike lanes may ice"},
       {"type": "nws", "event": "Winter Weather Advisory", "severity": "Moderate", "message": "...",
        "boroughs": ["Manhattan", "Brooklyn"], "start": "2026-12-04T19:00", "end": "2026-12-05T07:00"}]}
  ],
  "transit_alerts": [{"mode": "subway", "alert_type": "Delays", "planned": false, "routes": ["A", "C"],
                      "header": "A and C trains are running with delays", "start": "2026-12-04T20:48", "end": null}],
  "zones": [
    {
      "zone_id": 186, "name": "Penn Station / MSG West", "borough": "Manhattan",
      "region_id": "midtown_west", "lat": 40.7496, "lon": -73.9925, "airport": false,
      "staging_hint": "W 31st St & 8th Ave (Moynihan side)", "police_precinct": 14,
      "curb": {"relief_stands": [{"on_street": "W 31 ST", "from_street": "8 AVENUE", "to_street": "9 AVENUE",
                                  "side": "N", "lat": 40.7503, "lon": -73.9951, "sign": "..."}],
               "loading_zone_blocks": 23},
      "now": {
        "traffic": {"speed_mph": 8.0, "ratio_to_typical": 0.73},
        "airport_delays": null,
        "transit_alerts": [{"mode": "subway", "alert_type": "Delays", "routes": ["A", "C"], "match": "stop", "...": "..."},
                           {"mode": "lirr", "alert_type": "Delays", "match": "terminal", "...": "..."}],
        "street_closures": {"count": 2, "examples": [{"on_street": "W 33 ST", "from_street": "8 AVENUE",
                                                      "to_street": "9 AVENUE", "purpose": "DOT IN-HOUSE PAVING", "end": "2026-12-12"}]},
        "citibike": {"stations": 6, "bikes": 41, "ebikes": 9, "docks": 77}
      },
      "hours": [
        {"t": "2026-12-04T22:00",
         "seasonal_trips_per_hr": 412.3, "seasonal_trip_index": 2.31, "weather_trip_effect_pct": 11.6,
         "events": [{"name": "Knicks vs. Celtics", "venue": "Madison Square Garden", "phase": "let_out",
                     "start": "2026-12-04T19:30", "est_end": "2026-12-04T22:15", "capacity_est": 19500,
                     "demand_lift_pct": 34.1, "source": "Ticketmaster", "...": "..."}],
         "permitted_events": [{"name": "Holiday Market", "type": "Street Event", "street_closure": "Sidewalk and Curb Lane Closure",
                               "location": "...", "start": "2026-12-04T08:00", "end": "2026-12-04T23:00", "match": "precinct"}],
         "subway_entries_per_hr": 5120.4, "subway_entries_index": 3.8,
         "injury_crashes_per_yr": 14.0, "cyclist_injuries_per_yr": 3.0,
         "parking_tickets_per_day": 61.2}
      ]
    }
  ]
}
```

### Fields

**City level, per hour (`city_hours[]`)**

| Field | Meaning |
|---|---|
| `weather.temp_f`, `precip_mm`, `precip_prob_pct`, `wind_mph` | Forecast for that hour at one point in Midtown. `null` beyond the forecast |
| `alerts[]` (type ≠ `nws`) | Conditions that make the hour harder or riskier to work, especially on a bike or e-bike: `rain_onset`, `heavy_rain`, `high_wind`, `heat`, `cold`, `ice_risk` |
| `alerts[]` (type = `nws`) | Official NWS watches, warnings and advisories active that hour, with the boroughs they cover |

**City level, current (`transit_alerts[]`)**: every subway, LIRR and Metro-North alert active now or starting within 24 hours. `planned` marks planned work as opposed to live disruptions.

**Zone level, static**

| Field | Meaning |
|---|---|
| `police_precinct` | NYPD precinct containing the zone's centre (used to place permits and tickets) |
| `curb.relief_stands[]` | DOT-signed taxi / FHV relief stands in the zone: legal places for drivers to wait |
| `curb.loading_zone_blocks` | Number of block faces with commercial loading signs (commercial meters, truck loading, loading only) |

**Zone level, current (`zones[].now`)**

| Field | Meaning |
|---|---|
| `traffic.speed_mph` | Median NYC DOT link speed in the zone's borough right now |
| `traffic.ratio_to_typical` | That speed ÷ an assumed typical speed for the borough. Below 1 is slower than usual |
| `airport_delays` | FAA programs at JFK or LGA (airport zones only; `null` elsewhere) |
| `transit_alerts[]` | Alerts touching the zone. `match` says how: `stop` (an affected station is in the zone), `route` (a route serving the zone is affected), `terminal` (LIRR at Penn or Atlantic Terminal, Metro-North at Grand Central) |
| `street_closures` | Construction closures active today with their midpoint in the zone: a count and up to 3 examples |
| `citibike` | Bikes, e-bikes and docks available at stations inside the zone. `null` if the zone has none |

**Zone level, per hour (`zones[].hours[]`)**

| Field | Meaning |
|---|---|
| `seasonal_trips_per_hr` | Average for-hire pickups in this zone for this weekday and hour, from TLC records |
| `seasonal_trip_index` | That figure ÷ the median tracked zone in the same hour. Above 1 is busier than a typical zone |
| `weather_trip_effect_pct` | Estimated change in trips from this hour's weather vs. a dry, mild hour |
| `events[]` | Ticketmaster events affecting the zone this hour. `phase` is `arrivals` (up to 90 min before start) or `let_out` (around the estimated end) |
| `events[].demand_lift_pct` | Prior estimate of the extra demand. Not validated |
| `permitted_events[]` | City-permitted events active this hour in the zone's precinct: parades, street fairs, block parties, film shoots. League games are left out unless they close a street |
| `subway_entries_per_hr` | Average subway entries at stations in the zone for this weekday and hour, over recent weeks |
| `subway_entries_index` | That figure ÷ the median zone with stations, same hour |
| `injury_crashes_per_yr`, `cyclist_injuries_per_yr` | Crashes with injuries, and cyclists injured, in the zone during this hour's 4-hour block over the last 12 months |
| `parking_tickets_per_day` | Average parking tickets issued per day in the zone's precinct during this hour |

### Provenance

| Signal | Status |
|---|---|
| Weather, NWS alerts, traffic speed, airport delays, transit alerts, street closures, Citi Bike | **Live** feeds |
| Conditions alerts, traffic ratio to typical | **Assumption**: thresholds and typical speeds in `vanguard/config.py`, overridable in `.env` |
| Seasonal trips and index, weather trip effect | **Learned** from TLC records after `python -m vanguard.build`; placeholder priors before |
| Subway entries, crashes, parking tickets, curb | **Public records**, aggregated by `python -m vanguard.extras`; `null` until it has run |
| Permitted events, parking tickets | Placed by **police precinct**, not exact location. A precinct covers several zones |
| Event demand lift | **Prior**, not validated: there's no free historical event feed |

The response's own `calibration`, `extras` and `provenance` fields say which applies at the time of the request.

### Errors

Errors return JSON with an `error` field: `400` for bad parameters, `401` for a missing or wrong key, `500` for server errors. A feed that fails doesn't fail the request. Its fields come back empty or `null`, and `sources.<name>.status` reads `stale` (last good value) or `offline`.

## Build-time data

`python -m vanguard.extras` writes `data/extras.json`. Run it after `python -m vanguard.build`, so it can use the real zone polygons, and re-run it monthly. Each section builds independently, and `/api/v1/health` shows which ones succeeded.

| Section | Source | Window |
|---|---|---|
| `precincts` | Police Precincts polygons | Current |
| `subway` | MTA Subway Stations | Current |
| `ridership` | MTA Subway Hourly Ridership | Last 8 weeks of published data |
| `crashes` | Motor Vehicle Collisions – Crashes (with injuries) | Last 12 months of published data |
| `tickets` | Parking Violations Issued (current fiscal year dataset) | Last 90 days of published data |
| `curb` | Parking Regulation Locations and Signs | Current inventory |

## Sources and terms

| Source | Dataset / endpoint | Terms for a partner deployment |
|---|---|---|
| NYC TLC trip records | HVFHV monthly files | Public NYC Open Data |
| Open-Meteo | forecast + archive API | Free tier is non-commercial. **A commercial deployment needs an Open-Meteo plan in the partner's name** |
| National Weather Service | `api.weather.gov/alerts/active` | US government work, public domain. Send an identifying `NWS_USER_AGENT` |
| NYC DOT real-time speeds | NYC Open Data `i4gi-tjb9` | NYC Open Data terms of use |
| FAA NAS status | `nasstatus.faa.gov` | Public |
| Ticketmaster Discovery | Discovery API v2 | **Use the partner's own key**, under Ticketmaster's terms (attribution, caching and commercial limits) |
| NYC Permitted Events | NYC Open Data `tvpp-9vvx` | NYC Open Data terms of use |
| DOT street closures | NYC Open Data `i6b5-j7bu` | NYC Open Data terms of use |
| Police precincts | NYC Open Data `y76i-bdw7` | NYC Open Data terms of use |
| Collisions | NYC Open Data `h9gi-nx95` | NYC Open Data terms of use |
| Parking violations | NYC Open Data `pvqr-7yc4` (FY2026; set `DS_PARKING_VIOLATIONS` for later years) | NYC Open Data terms of use |
| Parking signs | NYC Open Data `nfid-uabd` | NYC Open Data terms of use |
| MTA service alerts | `api-endpoint.mta.info` GTFS-rt alerts (subway, LIRR, Metro-North) | MTA developer terms and conditions |
| MTA subway stations, hourly ridership | NY Open Data `39hk-dx4f`, `5wq4-mkjj` | NY Open Data terms; MTA terms |
| Citi Bike | GBFS `station_information`, `station_status` | Citi Bike Data License Agreement |

## Known limits

- **Weather is one point.** NYC gets one forecast for the whole city, so local storms can be missed. NWS alerts are checked per borough.
- **Ticketmaster events are large venues only.** City permits add parades, fairs and film shoots, but only by precinct.
- **Traffic is by borough,** not by street or zone.
- **Seasonal figures are for-hire trips.** They come from rideshare (HVFHV) pickups. Public data doesn't show food delivery demand, so delivery effects need partner data.
- **Subway data counts entries.** Exits aren't published hourly. Entries are a proxy for foot traffic around stations.
- **No live parking availability.** NYC doesn't publish open spaces. Curb data says what's allowed and where tickets cluster.
- **Recent months only.** The trip build fits on the 2 most recent published TLC months by default (`--months N` for more). TLC publishes with about a 2-month lag.
- **Some datasets need yearly upkeep.** NYC publishes parking violations as a new dataset each fiscal year.
