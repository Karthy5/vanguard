# Vanguard: NYC driver positioning

Tells a rideshare driver where to start a shift, when to move, and what that's likely worth after commute, tolls and operating cost.

It's calibrated on public NYC TLC trip records, and its forecasts are checked out-of-sample. Every number that isn't learned from data is labeled as an assumption.

## Quick start

```bash
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env                                   # optional: add a Ticketmaster key

python -m vanguard.build                               # ~1 GB download, 5–15 min the first time
python -m vanguard.extras                              # subway ridership, crashes, tickets, curb: a few minutes
python app.py                                          # http://localhost:5001
```

To check everything end to end, open `validate_signals.ipynb` and run all cells.

The app runs without the build step, but it then uses placeholder priors and shows a banner saying so.

## Signals API for partners

`GET /api/v1/signals` returns external signals for each zone and hour:

- **Weather and safety:** hourly forecast, conditions alerts for workers (rain onset, heavy rain, wind, heat, cold, ice) and official National Weather Service warnings.
- **Demand:** seasonal for-hire trips, subway entries by hour, Ticketmaster events with arrival and let-out windows, and city-permitted events (parades, street fairs, film shoots).
- **Getting around:** live traffic speeds, subway, LIRR and Metro-North alerts, street closures for construction, airport delays, and Citi Bike availability.
- **Curb and risk:** FHV relief stands, commercial loading-zone blocks, parking tickets by hour, and injury crashes by time of day.

 It returns no earnings estimates, so a partner can plug it into its own earnings model and assistant. Every field says whether it's live, learned from public data, or an assumption.

```bash
echo "SIGNALS_API_KEY=$(python -c 'import secrets; print(secrets.token_urlsafe(24))')" >> .env
python app.py
curl -H "X-API-Key: <key>" "http://localhost:5001/api/v1/signals?hours=6"
```

Full reference: [API.md](API.md).

### Before a partner deploys it

- **Accounts in the partner's name.** Get a Ticketmaster key and, for commercial use, an Open-Meteo plan. Don't reuse the developers' keys.
- **Set `SIGNALS_API_KEY`** on any host that isn't localhost.
- **Set `NWS_USER_AGENT`** to an app name and contact email, as the Weather Service asks.
- **Run the builds** (`python -m vanguard.build`, then `python -m vanguard.extras`) and check `/api/v1/health` shows `"mode": "calibrated"` and `"built": true`. Re-run them monthly. Each July, point `DS_PARKING_VIOLATIONS` at the new fiscal year's dataset.
- **Serve it with a production server,** e.g. `pip install gunicorn` then `gunicorn -w 2 -b 0.0.0.0:5001 app:app`, not `python app.py` (which runs Flask's debug server).

## What it does

**Plan tab.** Pick a starting point (NJ, Queens, Brooklyn, Bronx, Midtown), a start time and shift length. You get:

- One answer: which zone, a suggested staging street, expected $/hr over the shift with an interquartile range, and the commute cost.
- An hour-by-hour plan. An exact dynamic program over zones × hours decides when moving pays for the travel time it costs.
- A map of every tracked zone colored by expected net $/hr, plus live weather, NYC DOT traffic speeds, FAA airport programs and upcoming events.
- Layer toggles (weather / events / travel cost) to see what each input changes.

**Driver view** (`/driver`, built for a phone). The driver sets shift length (remembered from last time) and taps where they're starting from, or GPS. That one tap starts the shift and opens one screen:

- **Where to go now:** zone, staging cross-street, expected $/hr range, and buttons that open Google Maps or Waze.
- **What's next:** the next move with a countdown, or "stay here to the end".
- **Alerts:** event let-outs and incoming rain near the plan.
- **Progress:** estimated earnings for the shift with a likely range, how much the plan expects by now, and the rest of the plan.
- **Replan from here:** uses GPS to rebuild the rest of the shift from where the driver actually is.

The shift is saved on the phone, the screen stays awake while a shift is open (where the browser supports it), and live data refreshes every 5 minutes. To open it on a phone, run `python app.py`, then visit `http://<your-laptop-ip>:5001/driver` on the same Wi-Fi (start with `HOST=0.0.0.0 python app.py`). GPS on a phone needs HTTPS outside localhost; a tunnel such as `ngrok http 5001` handles that for a demo.

**Model tab.** The backtest: forecast error on 14 held-out days with and without the weather model, coefficient estimates with day-clustered 95% CIs, and the list of assumptions public data can't pin down.

## How the model works

```
est $/hr (zone, hour) = pay per engaged hour   ×   utilization
                        └ learned: TLC records     └ ASSUMED: base rate × relative demand^elasticity
                          zone × weekday × hour       demand = seasonal trips × weather effect × event prior
                          + weather regression
```

| Component | Source | Status |
|---|---|---|
| Seasonal trips and pay per engaged hour, by zone × weekday × hour | NYC TLC High-Volume FHV trip records (`driver_pay`, `tips`, `trip_time`) | **Learned** |
| Weather effect on trips and on pay rate | Open-Meteo hourly archive joined to TLC; OLS, SEs clustered by day | **Learned, tested on held-out days** |
| Commute and move time | Distance × detour factor ÷ live NYC DOT borough speeds, plus crossing delays | Heuristic |
| Tolls and operating cost | Hudson eastbound toll; $/mile operating cost; no CRZ charge for TLC-plated FHVs | Configurable constants |
| Utilization (share of logged-in time on a trip) | Not in public data | **Assumption** |
| Event egress lift (demand and surge pay) | Ticketmaster Discovery (live only, no historical feed) | **Unvalidated prior** |
| Trip flows between areas | TLC pickup → dropoff locations | **Learned** |
| Paid share of a move, leakage cost | Mapping from measured flows | **Assumption** |

The assumptions live in `vanguard/config.py` and can be overridden in `.env`.

### Areas, not single zones

Every trip carries a driver somewhere else, so "stay in this zone for 3 hours" isn't a real instruction. The planner works with 11 areas (Midtown West, Village / Union Sq, North Brooklyn, JFK and so on):

- **Where to wait.** Each hour, the best zone inside an area is the suggested staging spot between trips.
- **Trips that leave.** The build measures, from TLC pickup and dropoff locations, what share of trips from each area end in each other area, by 4-hour block. Areas that lose most of their trips (airports, outer neighborhoods late at night) are discounted for the unpaid drive back.
- **Moving.** A move between areas is mostly done on paid trips: "accept trips heading to X, or set your destination filter". The paid share rises with the measured A→B trip flow, so only the unpaid part of a move costs time and money. That's why plans now move when an event lets out or rain starts, instead of always staying put.

### What the backtest shows and what it doesn't

It shows whether weather improves out-of-sample forecasts of trip volume and pay per engaged hour, overall and in rain hours.

It doesn't show earnings per *logged-in* hour, whether the event prior is right, or whether drivers who follow the plan earn more. Those need driver-level earnings and session data in a controlled pilot. See [Validating with a partner](#validating-with-a-partner).

## Project layout

```
app.py                  Flask server: /api/plan, /api/zones, /api/backtest, /api/v1/* (signals API)
API.md                  Signals API reference
vanguard/
  signals.py            partner signals: zone × hour, no earnings estimates
  extras.py             build-time public data: ridership, crashes, tickets, curb, precincts
  socrata.py            NYC / NY Open Data client
  stateplane.py         NY State Plane (EPSG:2263) to lat/lon, for DOT sign coordinates
  build.py              download TLC + weather, fit, backtest, write data/*.json
  model.py              hourly estimates, travel, Viterbi shift planner
  feeds.py              live feeds with TTL cache and honest live/stale/offline status
  stats.py              numpy OLS with cluster-robust SEs
  zones.py              TLC zone list, polygons, point-in-polygon
  config.py             every assumption in one place
templates/, static/     UI (MapLibre and IBM Plex vendored, so no CDN needed)
tests/                  synthetic end-to-end tests, incl. recovering a planted rain effect
validate_signals.ipynb  live end-to-end validation with a pass/fail summary
```

Run the tests with `pytest -q`. No network needed.

## Data sources and terms

- **NYC TLC trip records**: public and free. TLC publishes monthly with a lag of about 2 months.
- **Open-Meteo**: no key needed. The free tier is for non-commercial use, so commercial deployment needs their paid plan.
- **NYC DOT real-time speeds** (`i4gi-tjb9`) and **FAA NAS status**: public.
- **Ticketmaster Discovery API**: free key, subject to Ticketmaster's terms (attribution, caching and commercial limits). Keys stay in `.env` and are never committed.
- **National Weather Service alerts**: US government work, public domain. Requires an identifying User-Agent.
- **MTA service alerts and subway ridership**: MTA developer terms and conditions.
- **Citi Bike GBFS**: Citi Bike Data License Agreement.
- **NYC Open Data** (permitted events, street closures, police precincts, collisions, parking violations, parking signs) and **NY Open Data** (subway stations, hourly ridership): open-data terms of use.

The full table, with dataset ids, is in [API.md](API.md#sources-and-terms).

## Validating with a partner

The public data gets the forecast layer most of the way. The parts that decide what a driver actually earns need partner data, and none of it has to be raw PII:

1. **Utilization by zone × hour.** Aggregated session time vs. trip time replaces the assumed curve.
2. **Event effects.** Partner earnings around past event end times validate or replace the prior.
3. **Causal lift.** Randomize a small share of users to plan-on vs. plan-off. The primary metric is net earnings per logged-in hour, net of commute; also track adherence and unpaid miles. Pre-register the metric and the minimum detectable effect before launch.

The engine runs on the partner side or in a clean room against aggregates, so driver-level data never has to leave the partner.
