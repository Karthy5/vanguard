# Third-party notices

This project bundles the following third-party components. Each keeps its own license.

| Component | Version | License | Full text |
|---|---|---|---|
| MapLibre GL JS | 4.7.1 | BSD 3-Clause (includes code from mapbox-gl-js v1.13 and earlier, BSD 3-Clause) | [static/vendor/LICENSE-maplibre-gl.txt](static/vendor/LICENSE-maplibre-gl.txt) |
| IBM Plex Sans and IBM Plex Mono | woff2 subsets | SIL Open Font License 1.1 | [static/vendor/fonts/LICENSE-ibm-plex.txt](static/vendor/fonts/LICENSE-ibm-plex.txt) |

Python dependencies (installed from PyPI, not bundled) are listed in `requirements.txt` under their own licenses.

## Data sources

Data is fetched at build time or run time and is not bundled. Each source keeps its own terms. The full list, with dataset ids, is in the "Sources and terms" section of [API.md](API.md#sources-and-terms):

- NYC TLC trip records, NYC DOT speeds, permitted events, street closures, police precincts, collisions, parking violations and parking signs (NYC Open Data)
- MTA subway stations and hourly ridership (NY Open Data) and MTA service alerts (MTA developer terms)
- National Weather Service alerts (public domain)
- FAA NAS status (public)
- Open-Meteo (free tier non-commercial)
- Ticketmaster Discovery API (Ticketmaster terms)
- Citi Bike GBFS (Citi Bike Data License Agreement)
