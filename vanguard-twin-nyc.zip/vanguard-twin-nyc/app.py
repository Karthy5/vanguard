"""
Vanguard Twin: NYC driver positioning engine.

    pip install -r requirements.txt
    python -m vanguard.build      # optional but recommended: fit on real TLC data
    python app.py                 # http://localhost:5001
"""

from datetime import datetime

from dotenv import load_dotenv

load_dotenv()

from flask import Flask, jsonify, render_template, request  # noqa: E402

import hmac  # noqa: E402

from vanguard import config, feeds, model, signals  # noqa: E402
from vanguard.zones import load_polygons, region_of_zone, zones  # noqa: E402

app = Flask(__name__)


@app.before_request
def _require_api_key():
    """When SIGNALS_API_KEY is set, /api/v1 requires it in the X-API-Key header."""
    if not request.path.startswith("/api/v1/") or not config.SIGNALS_API_KEY:
        return None
    sent = request.headers.get("X-API-Key", "")
    if not hmac.compare_digest(sent.encode(), config.SIGNALS_API_KEY.encode()):
        return jsonify({"error": "missing or invalid X-API-Key"}), 401
    return None


def _int(name, default, lo, hi):
    try:
        return max(lo, min(hi, int(request.args.get(name, default))))
    except (TypeError, ValueError):
        return default


@app.get("/")
def index():
    return render_template("index.html", origins=config.ORIGINS)


@app.get("/driver")
def driver():
    return render_template("driver.html", origins=config.ORIGINS)


@app.get("/api/plan")
def api_plan():
    layers = {k: request.args.get(k, "1") == "1" for k in ("weather", "events", "travel")}
    live = feeds.snapshot()
    start_at = here = None
    if request.args.get("start_at"):
        try:
            start_at = datetime.fromisoformat(request.args["start_at"]).replace(tzinfo=None)
        except ValueError:
            return jsonify({"error": "start_at must be ISO 8601"}), 400
    if request.args.get("origin") == "here":
        try:
            here = (float(request.args["lat"]), float(request.args["lon"]))
        except (KeyError, ValueError):
            return jsonify({"error": "origin=here needs lat and lon"}), 400
    result = model.plan(
        origin_id=request.args.get("origin", "midtown"),
        start_hour=_int("start", 18, 0, 23),
        shift_hours=_int("hours", 5, 1, 12),
        layers=layers,
        live=live,
        start_at=start_at,
        here=here,
    )
    result["live"] = {
        "weather": {k: v for k, v in live["weather"].items() if k != "hourly"},
        "traffic": live["traffic"],
        "airports": live["airports"],
        "events": live["events"],
    }
    return jsonify(result)


@app.errorhandler(Exception)
def api_error(exc):
    """Return JSON for API failures so the page shows the real error
    instead of trying to parse Flask's HTML error page."""
    from werkzeug.exceptions import HTTPException
    if isinstance(exc, HTTPException) and not request.path.startswith("/api/"):
        return exc
    app.logger.exception("request failed: %s", request.path)
    code = exc.code if isinstance(exc, HTTPException) else 500
    return jsonify({"error": f"{exc.__class__.__name__}: {exc}"}), code


@app.get("/api/zones")
def api_zones():
    polys = load_polygons()
    return jsonify({
        "type": "FeatureCollection",
        "has_polygons": bool(polys),
        "features": [{
            "type": "Feature",
            "properties": {"id": z["id"], "name": z["name"]},
            "geometry": polys.get(z["id"]) or {"type": "Point", "coordinates": [z["lon"], z["lat"]]},
        } for z in zones()],
    })


@app.get("/api/backtest")
def api_backtest():
    model.CAL.maybe_reload()
    return jsonify({"calibration": model.CAL.status(), "backtest": model.CAL.backtest,
                    "assumptions": model.assumptions()})


# ---------------------------------------------------------------------------
# Signals API v1: external signals only, no earnings estimates. See API.md.
# ---------------------------------------------------------------------------
@app.get("/api/v1/signals")
def api_v1_signals():
    start = None
    if request.args.get("start"):
        try:
            start = datetime.fromisoformat(request.args["start"]).replace(tzinfo=None)
        except ValueError:
            return jsonify({"error": "start must be ISO 8601, e.g. 2026-12-04T18:00"}), 400
    zone_ids = None
    if request.args.get("zones"):
        try:
            zone_ids = {int(z) for z in request.args["zones"].split(",") if z.strip()}
        except ValueError:
            return jsonify({"error": "zones must be comma-separated TLC LocationIDs"}), 400
        unknown = zone_ids - {z["id"] for z in zones()}
        if unknown:
            return jsonify({"error": f"untracked zone ids: {sorted(unknown)}",
                            "tracked": sorted(z["id"] for z in zones())}), 400
    hours = _int("hours", 6, 1, config.SIGNALS_MAX_HOURS)
    return jsonify(signals.build(feeds.snapshot(), start=start, hours=hours, zone_ids=zone_ids))


@app.get("/api/v1/zones")
def api_v1_zones():
    polys = load_polygons()
    region = region_of_zone()
    return jsonify({
        "type": "FeatureCollection",
        "has_polygons": bool(polys),
        "features": [{
            "type": "Feature",
            "properties": {"zone_id": z["id"], "name": z["name"], "borough": z["borough"],
                           "region_id": region.get(z["id"]), "airport": z["airport"],
                           "staging_hint": z["staging"]},
            "geometry": polys.get(z["id"]) or {"type": "Point", "coordinates": [z["lon"], z["lat"]]},
        } for z in zones()],
    })


@app.get("/api/v1/health")
def api_v1_health():
    live = feeds.snapshot()
    model.CAL.maybe_reload()
    return jsonify({"api_version": config.SIGNALS_API_VERSION, "calibration": model.CAL.status(),
                    "extras": signals.EXTRAS.status(),
                    "sources": {k: (live.get(k) or {}).get("status", "offline") for k in signals.SOURCES}})


if __name__ == "__main__":
    import os
    # HOST=0.0.0.0 lets a phone on the same Wi-Fi open /driver
    app.run(debug=True, host=os.getenv("HOST", "127.0.0.1"), port=int(os.getenv("PORT", "5001")))
