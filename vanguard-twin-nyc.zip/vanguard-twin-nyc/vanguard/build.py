"""
Calibrate the model on real public data and run an out-of-sample backtest.

    python -m vanguard.build              # 2 most recent published months
    python -m vanguard.build --months 3
    python -m vanguard.build --month 2025-08 --month 2025-09

Pipeline
  1. Download NYC TLC High-Volume FHV trip records (Uber/Lyft, every trip,
     with driver_pay and tips) as monthly parquet files.
  2. Aggregate to zone x hour with DuckDB: trips, driver pay + tips, engaged hours.
  3. Pull matching hourly weather from the Open-Meteo archive.
  4. Hold out the last 14 days. Fit a seasonal baseline (zone x weekday x hour)
     and weather regressions on the rest. Score both on the holdout.
  5. Refit on all data and write data/baseline.json and data/backtest.json,
     which the app reads.

Each monthly file is a few hundred MB. They're cached in data/raw/ (gitignored).
"""

import argparse
import json
import sys
from datetime import date, datetime, timedelta

import duckdb
import numpy as np
import requests

from . import config
from .stats import mae, ols
from .zones import AIRPORT_IDS, region_of_zone, zone_by_id, zone_ids

TLC_URL = "https://d37ci6vzurychx.cloudfront.net/trip-data/fhvhv_tripdata_{ym}.parquet"
ARCHIVE_URL = "https://archive-api.open-meteo.com/v1/archive"
ZONE_GEOJSON_CANDIDATES = [
    "https://data.cityofnewyork.us/api/geospatial/d3c5-ddgc?method=export&format=GeoJSON",
    "https://data.cityofnewyork.us/resource/8meu-9t5y.geojson?$limit=300",
]
HOLDOUT_DAYS = 14
RAIN_THRESHOLD_MM = 0.2

FEATURES = ["intercept", "precip_mm", "rain_flag", "precip_x_manhattan", "precip_x_airport",
            "cold_deg_below_45F", "hot_deg_above_82F"]


def log(msg):
    print(f"[build] {msg}", flush=True)


# ---------------------------------------------------------------------------
# 1. Trip data
# ---------------------------------------------------------------------------
def _month_back(d, k):
    y, m = d.year, d.month - k
    while m <= 0:
        m += 12
        y -= 1
    return f"{y:04d}-{m:02d}"


def latest_available_months(n, search_back=10):
    found = []
    today = date.today()
    for k in range(1, search_back + 1):
        ym = _month_back(today, k)
        try:
            r = requests.head(TLC_URL.format(ym=ym), timeout=15, allow_redirects=True)
            if r.status_code == 200:
                found.append(ym)
                if len(found) == n:
                    break
        except requests.RequestException:
            continue
    return sorted(found)


def download_month(ym):
    config.RAW_DIR.mkdir(parents=True, exist_ok=True)
    dest = config.RAW_DIR / f"fhvhv_tripdata_{ym}.parquet"
    if dest.exists() and dest.stat().st_size > 1_000_000:
        log(f"cached {dest.name}")
        return dest
    url = TLC_URL.format(ym=ym)
    log(f"downloading {url}")
    tmp = dest.with_suffix(".part")
    with requests.get(url, stream=True, timeout=60) as r:
        r.raise_for_status()
        total = int(r.headers.get("content-length", 0))
        done = 0
        with open(tmp, "wb") as fh:
            for chunk in r.iter_content(chunk_size=1 << 20):
                fh.write(chunk)
                done += len(chunk)
                if total:
                    sys.stdout.write(f"\r         {done / total:6.1%} of {total / 1e6:,.0f} MB")
                    sys.stdout.flush()
    print()
    tmp.rename(dest)
    return dest


# ---------------------------------------------------------------------------
# 2. Weather
# ---------------------------------------------------------------------------
def fetch_weather_archive(start, end):
    r = requests.get(ARCHIVE_URL, params={
        "latitude": config.NYC_LAT, "longitude": config.NYC_LON,
        "start_date": start, "end_date": end,
        "hourly": "temperature_2m,precipitation",
        "temperature_unit": "fahrenheit", "timezone": config.TZ,
    }, timeout=60)
    r.raise_for_status()
    h = r.json()["hourly"]
    rows = []
    for t, temp, p in zip(h["time"], h["temperature_2m"], h["precipitation"]):
        if temp is None or p is None:
            continue
        rows.append((datetime.fromisoformat(t), float(temp), float(p)))
    return rows


# ---------------------------------------------------------------------------
# 3. Optional zone polygons for the map
# ---------------------------------------------------------------------------
def fetch_zone_polygons():
    wanted = set(zone_ids())
    for url in ZONE_GEOJSON_CANDIDATES:
        try:
            r = requests.get(url, timeout=60)
            r.raise_for_status()
            gj = r.json()
            feats = []
            for f in gj.get("features", []):
                props = f.get("properties", {}) or {}
                lid = None
                for k in ("location_id", "locationid", "LocationID", "objectid"):
                    if props.get(k) not in (None, ""):
                        lid = int(float(props[k]))
                        break
                if lid in wanted and f.get("geometry"):
                    f["geometry"]["coordinates"] = _round_coords(f["geometry"]["coordinates"])
                    feats.append({"type": "Feature", "properties": {"location_id": lid},
                                  "geometry": f["geometry"]})
            if len(feats) >= len(wanted) * 0.8:
                config.ZONES_GEOJSON_PATH.write_text(json.dumps({"type": "FeatureCollection", "features": feats}))
                log(f"zone polygons: {len(feats)} zones from {url.split('?')[0]}")
                return True
        except Exception as exc:  # noqa: BLE001 - try the next source
            log(f"polygons unavailable from {url.split('?')[0]} ({exc.__class__.__name__})")
    log("no polygons; the map will use centroid markers")
    return False


def _round_coords(c):
    if isinstance(c, (int, float)):
        return round(c, 5)
    return [_round_coords(x) for x in c]


# ---------------------------------------------------------------------------
# 4. Panel + model
# ---------------------------------------------------------------------------
def build_panel(con, parquet_files, weather_rows):
    ids = ",".join(str(z) for z in zone_ids())
    files = ", ".join(f"'{p.as_posix()}'" for p in parquet_files)
    log("aggregating trips with DuckDB (this is the slow part)")
    con.execute(f"""
        CREATE OR REPLACE TABLE agg AS
        SELECT PULocationID::INT AS zone,
               date_trunc('hour', pickup_datetime) AS ts,
               count(*) AS trips,
               sum(driver_pay + coalesce(tips, 0)) AS pay,
               sum(trip_time) / 3600.0 AS eh
        FROM read_parquet([{files}])
        WHERE PULocationID IN ({ids})
          AND driver_pay > 0
          AND trip_time BETWEEN 60 AND 10800
        GROUP BY ALL
    """)
    con.execute("CREATE OR REPLACE TABLE wx (ts TIMESTAMP, temp DOUBLE, precip DOUBLE)")
    con.executemany("INSERT INTO wx VALUES (?, ?, ?)", weather_rows)

    lo, hi = con.execute("SELECT min(ts), max(ts) FROM agg").fetchone()
    cutoff = hi - timedelta(days=HOLDOUT_DAYS)
    con.execute(f"""
        CREATE OR REPLACE TABLE panel AS
        WITH grid AS (
          SELECT z.zone, h.ts
          FROM (SELECT DISTINCT zone FROM agg) z,
               (SELECT unnest(generate_series(TIMESTAMP '{lo}', TIMESTAMP '{hi}', INTERVAL 1 HOUR)) AS ts) h
        )
        SELECT g.zone, g.ts,
               coalesce(a.trips, 0) AS trips,
               coalesce(a.pay, 0) AS pay,
               coalesce(a.eh, 0) AS eh,
               w.temp, least(w.precip, 10.0) AS precip,
               isodow(g.ts) - 1 AS dow,
               hour(g.ts) AS hr,
               g.ts > TIMESTAMP '{cutoff}' AS holdout
        FROM grid g
        LEFT JOIN agg a USING (zone, ts)
        JOIN wx w ON w.ts = g.ts
    """)
    n_trips = con.execute("SELECT sum(trips) FROM panel").fetchone()[0]
    log(f"panel: {con.execute('SELECT count(*) FROM panel').fetchone()[0]:,} zone-hours, "
        f"{int(n_trips):,} trips, {lo:%Y-%m-%d} to {hi:%Y-%m-%d}, holdout after {cutoff:%Y-%m-%d}")
    return {"start": str(lo), "end": str(hi), "cutoff": str(cutoff), "trips": int(n_trips)}


FLOW_BUCKET_HOURS = 4


def compute_flows(con, parquet_files):
    """Where trips that start in each region end up, by 4-hour block of the day.
    flows[bucket][from_region][to_region] = share of trips (to_region may be "other")."""
    ids = ",".join(str(z) for z in zone_ids())
    files = ", ".join(f"'{p.as_posix()}'" for p in parquet_files)
    log("computing trip destination flows")
    rows = con.execute(f"""
        SELECT PULocationID::INT AS pu, DOLocationID::INT AS dz,
               hour(pickup_datetime) // {FLOW_BUCKET_HOURS} AS b, count(*) AS n
        FROM read_parquet([{files}])
        WHERE PULocationID IN ({ids}) AND driver_pay > 0 AND trip_time BETWEEN 60 AND 10800
        GROUP BY ALL
    """).fetchall()
    reg = region_of_zone()
    counts = {}
    for pu, dz, b, n in rows:
        ra, rb = reg[pu], reg.get(dz, "other")
        d = counts.setdefault(str(b), {}).setdefault(ra, {})
        d[rb] = d.get(rb, 0) + n
    flows = {}
    for b, by_from in counts.items():
        for ra, dests in by_from.items():
            tot = sum(dests.values())
            flows.setdefault(b, {})[ra] = {rb: round(n / tot, 4) for rb, n in dests.items()}
    return flows


def seasonal_baseline(con, where):
    con.execute(f"""
        CREATE OR REPLACE TABLE base AS
        SELECT zone, dow, hr,
               avg(ln(1 + trips)) AS mu_log,
               avg(trips) AS trips_mean,
               sum(pay) / nullif(sum(eh), 0) AS pay_rate,
               quantile_cont(CASE WHEN eh >= 0.5 THEN pay / eh END, 0.25) AS pay_p25,
               quantile_cont(CASE WHEN eh >= 0.5 THEN pay / eh END, 0.75) AS pay_p75,
               count(*) AS n
        FROM panel WHERE {where}
        GROUP BY ALL
    """)


def design_rows(con, where):
    manhattan = ",".join(str(z) for z in zone_ids() if zone_by_id(z)["borough"] == "Manhattan")
    airports = ",".join(str(z) for z in AIRPORT_IDS)
    cols = con.execute(f"""
        SELECT p.zone, p.trips, p.pay, p.eh, p.precip, p.temp,
               strftime(p.ts, '%Y-%m-%d') AS day, p.ts,
               b.mu_log, b.trips_mean, b.pay_rate,
               p.zone IN ({manhattan}) AS is_mn, p.zone IN ({airports}) AS is_ap
        FROM panel p JOIN base b USING (zone, dow, hr)
        WHERE {where}
        ORDER BY p.ts, p.zone
    """).fetchnumpy()
    precip = cols["precip"].astype(float)
    temp = cols["temp"].astype(float)
    X = np.column_stack([
        np.ones_like(precip),
        precip,
        (precip >= RAIN_THRESHOLD_MM).astype(float),
        precip * cols["is_mn"].astype(float),
        precip * cols["is_ap"].astype(float),
        np.clip(45 - temp, 0, None),
        np.clip(temp - 82, 0, None),
    ])
    return cols, X


def fit_models(con, where):
    cols, X = design_rows(con, where)
    y_dem = np.log1p(cols["trips"].astype(float)) - cols["mu_log"].astype(float)
    demand = ols(X, y_dem, FEATURES, clusters=cols["day"])

    eh = cols["eh"].astype(float)
    pay_rate_base = np.nan_to_num(cols["pay_rate"].astype(float))
    m = eh >= 0.5
    y_pay = cols["pay"].astype(float)[m] / eh[m] - pay_rate_base[m]
    pay = ols(X[m], y_pay, FEATURES, clusters=cols["day"][m], weights=eh[m])
    return demand, pay


def evaluate_holdout(con, demand, pay):
    cols, X = design_rows(con, "holdout")
    trips = cols["trips"].astype(float)
    mu = cols["mu_log"].astype(float)
    pred_base = np.expm1(mu)
    pred_wx = np.expm1(mu + X @ demand["beta"])
    rain = cols["precip"].astype(float) >= RAIN_THRESHOLD_MM

    eh = cols["eh"].astype(float)
    m = eh >= 0.5
    actual_rate = cols["pay"].astype(float)[m] / eh[m]
    base_rate = np.nan_to_num(cols["pay_rate"].astype(float))[m]
    wx_rate = base_rate + X[m] @ pay["beta"]

    def pct(a, b):
        return round((a - b) / a * 100, 2) if a else None

    out = {
        "holdout_zone_hours": int(len(trips)),
        "holdout_rain_zone_hours": int(rain.sum()),
        "demand": {
            "mae_trips_baseline": mae(trips, pred_base),
            "mae_trips_with_weather": mae(trips, pred_wx),
            "rain_mae_trips_baseline": mae(trips[rain], pred_base[rain]) if rain.any() else None,
            "rain_mae_trips_with_weather": mae(trips[rain], pred_wx[rain]) if rain.any() else None,
        },
        "pay": {
            "wmae_pay_rate_baseline": mae(actual_rate, base_rate, eh[m]),
            "wmae_pay_rate_with_weather": mae(actual_rate, wx_rate, eh[m]),
        },
    }
    d = out["demand"]
    d["error_reduction_pct"] = pct(d["mae_trips_baseline"], d["mae_trips_with_weather"])
    if d["rain_mae_trips_baseline"]:
        d["rain_error_reduction_pct"] = pct(d["rain_mae_trips_baseline"], d["rain_mae_trips_with_weather"])
    p = out["pay"]
    p["error_reduction_pct"] = pct(p["wmae_pay_rate_baseline"], p["wmae_pay_rate_with_weather"])

    # City-level hourly series for the chart
    ts = cols["ts"]
    series = {}
    for i in range(len(trips)):
        key = str(ts[i])[:13]
        s = series.setdefault(key, [0.0, 0.0, 0.0, float(cols["precip"][i])])
        s[0] += trips[i]
        s[1] += pred_base[i]
        s[2] += pred_wx[i]
    out["city_hourly"] = [
        {"ts": k, "actual": round(v[0]), "baseline": round(v[1]), "with_weather": round(v[2]), "precip_mm": v[3]}
        for k, v in sorted(series.items())
    ]
    return out


def export_baseline(con, meta, flows=None):
    rows = con.execute("SELECT zone, dow, hr, trips_mean, mu_log, pay_rate, pay_p25, pay_p75, n FROM base").fetchall()
    zones_out = {}
    for zone, dow, hr, tm, mu, pr, p25, p75, n in rows:
        zones_out.setdefault(str(zone), {})[f"{dow}-{hr}"] = [
            round(tm, 2), round(mu, 4),
            round(pr, 2) if pr is not None else None,
            round(p25, 2) if p25 is not None else None,
            round(p75, 2) if p75 is not None else None,
            int(n),
        ]
    payload = {"meta": meta, "fields": ["trips_mean", "mu_log", "pay_rate", "pay_p25", "pay_p75", "n_weeks"],
               "zones": zones_out, "flow_bucket_hours": FLOW_BUCKET_HOURS, "flows": flows or {}}
    config.BASELINE_PATH.write_text(json.dumps(payload))


def _strip(model):
    return {k: v for k, v in model.items() if k != "beta"}


def run(months):
    config.DATA_DIR.mkdir(exist_ok=True)
    if not months:
        log("finding the latest published HVFHV months (TLC publishes with a ~2 month lag)")
        months = latest_available_months(2)
    if not months:
        sys.exit("No TLC months reachable. Check your connection or pass --month YYYY-MM.")
    log(f"months: {', '.join(months)}")

    files = [download_month(m) for m in months]

    start = f"{months[0]}-01"
    y, mo = map(int, months[-1].split("-"))
    end = (date(y + (mo == 12), mo % 12 + 1, 1) - timedelta(days=1)).isoformat()
    log(f"weather archive {start} to {end}")
    weather = fetch_weather_archive(start, end)

    fetch_zone_polygons()

    con = duckdb.connect()
    span = build_panel(con, files, weather)

    log("fitting on training window")
    seasonal_baseline(con, "NOT holdout")
    demand, pay = fit_models(con, "NOT holdout")
    holdout = evaluate_holdout(con, demand, pay)
    log(f"holdout trips MAE: baseline {holdout['demand']['mae_trips_baseline']:.2f} -> "
        f"with weather {holdout['demand']['mae_trips_with_weather']:.2f} "
        f"({holdout['demand']['error_reduction_pct']}% lower error)")

    log("refitting on all data for the app")
    seasonal_baseline(con, "TRUE")
    demand_all, pay_all = fit_models(con, "TRUE")

    meta = {
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "months": months,
        "source": "NYC TLC High Volume FHV Trip Records + Open-Meteo archive",
        **span,
    }
    export_baseline(con, meta, compute_flows(con, files))
    config.BACKTEST_PATH.write_text(json.dumps({
        "meta": {**meta, "holdout_days": HOLDOUT_DAYS, "rain_threshold_mm": RAIN_THRESHOLD_MM},
        "train_fit": {"demand": _strip(demand), "pay": _strip(pay)},
        "holdout": holdout,
        "final_fit": {"demand": _strip(demand_all), "pay": _strip(pay_all)},
    }, indent=1, allow_nan=False))
    log(f"wrote {config.BASELINE_PATH.name} and {config.BACKTEST_PATH.name} in {config.DATA_DIR}")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--months", type=int, default=2, help="number of recent months to use (default 2)")
    ap.add_argument("--month", action="append", help="specific month YYYY-MM (repeatable)")
    a = ap.parse_args()
    months = sorted(a.month) if a.month else latest_available_months(a.months)
    run(months)


if __name__ == "__main__":
    main()
