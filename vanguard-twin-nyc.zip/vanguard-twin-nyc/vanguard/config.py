"""
Every number in this file is either an assumption or a published rate.
None of them are learned from data. They're kept in one place so they can
be read, argued with, and replaced once partner data is available.
"""

import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = ROOT / "data"
RAW_DIR = DATA_DIR / "raw"

BASELINE_PATH = DATA_DIR / "baseline.json"
EXTRAS_PATH = DATA_DIR / "extras.json"          # written by `python -m vanguard.extras`
BACKTEST_PATH = DATA_DIR / "backtest.json"
ZONES_GEOJSON_PATH = DATA_DIR / "taxi_zones.geojson"

TZ = "America/New_York"
NYC_LAT, NYC_LON = 40.7505, -73.9934

TICKETMASTER_API_KEY = os.getenv("TICKETMASTER_API_KEY", "").strip()
FEED_TTL_SECONDS = int(os.getenv("FEED_TTL_SECONDS", "300"))


def _f(name, default):
    return float(os.getenv(name, default))


# ---------------------------------------------------------------------------
# Utilization: share of logged-in time spent on a paid trip.
# Public TLC trip records give pay per *engaged* hour. They don't show idle
# time, so converting to pay per *logged-in* hour needs an assumption.
# This is the main thing partner data would calibrate.
# ---------------------------------------------------------------------------
ASSUMED_BASE_UTILIZATION = _f("ASSUMED_BASE_UTILIZATION", "0.55")
UTILIZATION_DEMAND_ELASTICITY = _f("UTILIZATION_DEMAND_ELASTICITY", "0.35")
UTILIZATION_FLOOR, UTILIZATION_CEIL = 0.25, 0.85
AIRPORT_QUEUE_UTILIZATION_FACTOR = _f("AIRPORT_QUEUE_UTILIZATION_FACTOR", "0.70")

# ---------------------------------------------------------------------------
# Event egress prior (NOT validated: there's no free historical event feed).
# The model raises demand in the zone around the end of an event.
# ---------------------------------------------------------------------------
EVENT_EGRESS_MAX_DEMAND_LIFT = _f("EVENT_EGRESS_MAX_DEMAND_LIFT", "0.35")
EVENT_EGRESS_MAX_PAY_LIFT = _f("EVENT_EGRESS_MAX_PAY_LIFT", "0.15")   # surge pricing at let-out
EVENT_FULL_EFFECT_CAPACITY = 20000
EVENT_DURATION_HOURS = {"Sports": 2.75, "Music": 3.0, "Arts & Theatre": 2.5}
EVENT_DEFAULT_DURATION = 2.5

# ---------------------------------------------------------------------------
# Repositioning. Drivers don't drive empty to a new area: they accept trips
# heading there (or use the apps' destination filter). The share of a move
# that's paid rises with how many trips naturally flow from A to B, a share
# measured from TLC pickup/dropoff data. The mapping is an assumption.
# ---------------------------------------------------------------------------
REPOSITION_PAID_MIN = _f("REPOSITION_PAID_MIN", "0.25")
REPOSITION_PAID_MAX = _f("REPOSITION_PAID_MAX", "0.85")
REPOSITION_FLOW_SLOPE = _f("REPOSITION_FLOW_SLOPE", "3.0")
# Share of an hour's earnings lost to unpaid returns if every trip left the area.
LEAKAGE_COST = _f("LEAKAGE_COST", "0.15")
ORIGIN_REGION_MAX_MILES = 2.0   # a home within this distance of a region can take trips from it

# ---------------------------------------------------------------------------
# Travel and cost
# ---------------------------------------------------------------------------
ROAD_DETOUR_FACTOR = 1.30            # road miles per straight-line mile
OPERATING_COST_PER_MILE = _f("OPERATING_COST_PER_MILE", "0.30")  # fuel + wear, excl. depreciation
DEFAULT_SPEED_MPH = {"Manhattan": 11.0, "Brooklyn": 15.0, "Queens": 18.0, "Bronx": 16.0,
                     "Staten Island": 22.0, "New Jersey": 22.0}
HUDSON_CROSSING_DELAY_MIN = {"offpeak": 12, "peak": 30}
EAST_RIVER_CROSSING_DELAY_MIN = {"offpeak": 5, "peak": 14}
PEAK_HOURS = {7, 8, 9, 16, 17, 18, 19}

# Hudson crossings (Holland/Lincoln) charge eastbound only. Verify the current
# PANYNJ E-ZPass rate before quoting it.
HUDSON_TOLL_USD = _f("HUDSON_TOLL_USD", "15.38")

# Congestion pricing: TLC-licensed FHVs aren't charged the daily CRZ toll.
# Passengers pay a per-trip surcharge instead. So the driver-side cost is 0.
CRZ_DRIVER_COST_FHV = 0.0

# ---------------------------------------------------------------------------
# Signals API (/api/v1/*)
# ---------------------------------------------------------------------------
SIGNALS_API_VERSION = "1.0"
# If set, every /api/v1 request must send it in the X-API-Key header.
SIGNALS_API_KEY = os.getenv("SIGNALS_API_KEY", "").strip()
SIGNALS_MAX_HOURS = 24

# Worker conditions alerts. These thresholds are ASSUMPTIONS: they mark hours
# that are harder or riskier to work, especially on a bike or e-bike. They are
# not learned from data, and partners should tune them.
ALERT_RAIN_MM = _f("ALERT_RAIN_MM", "0.2")              # wet hour
ALERT_HEAVY_RAIN_MM = _f("ALERT_HEAVY_RAIN_MM", "4.0")  # heavy rain
ALERT_RAIN_PROB_PCT = _f("ALERT_RAIN_PROB_PCT", "60")   # likely rain
ALERT_HIGH_WIND_MPH = _f("ALERT_HIGH_WIND_MPH", "25")
ALERT_HEAT_F = _f("ALERT_HEAT_F", "90")
ALERT_COLD_F = _f("ALERT_COLD_F", "20")
ALERT_ICE_MAX_F = _f("ALERT_ICE_MAX_F", "34")           # precipitation at or below this may freeze

# ---------------------------------------------------------------------------
# Additional public sources (see API.md, "Sources and terms")
# ---------------------------------------------------------------------------
# NWS asks every client to identify itself with a contact in the User-Agent.
NWS_USER_AGENT = os.getenv("NWS_USER_AGENT", "vanguard-twin-nyc (set NWS_USER_AGENT to app name and contact email)")
NWS_POINTS = {   # one point per borough; alerts are deduplicated across them
    "Manhattan": (40.7831, -73.9712), "Brooklyn": (40.6782, -73.9442), "Queens": (40.7282, -73.7949),
    "Bronx": (40.8448, -73.8648), "Staten Island": (40.5795, -74.1502),
}
MTA_ALERTS_URL = "https://api-endpoint.mta.info/Dataservice/mtagtfsfeeds/camsys%2F{feed}.json"
MTA_ALERT_FEEDS = {"subway": "subway-alerts", "lirr": "lirr-alerts", "mnr": "mnr-alerts"}
MTA_API_KEY = os.getenv("MTA_API_KEY", "").strip()   # not needed today; sent as x-api-key if set
# Railroad terminals: LIRR and Metro-North alerts are attached to the zones these fall in
RAIL_HUBS = {"lirr": [("Penn Station", 40.7506, -73.9935), ("Atlantic Terminal", 40.6845, -73.9776)],
             "mnr": [("Grand Central", 40.7527, -73.9772)]}
CITIBIKE_GBFS = "https://gbfs.citibikenyc.com/gbfs/en/{feed}.json"

# NYC Open Data / NY Open Data dataset ids
DS_PERMITTED_EVENTS = "tvpp-9vvx"        # NYC Permitted Event Information (next ~month)
DS_STREET_CLOSURES = "i6b5-j7bu"         # Street Closures due to Construction Activities by Block
DS_PRECINCTS = "y76i-bdw7"               # Police Precincts (polygons)
DS_SUBWAY_STATIONS = "39hk-dx4f"         # MTA Subway Stations (data.ny.gov)
DS_SUBWAY_RIDERSHIP = os.getenv("DS_SUBWAY_RIDERSHIP", "5wq4-mkjj")    # Subway Hourly Ridership: Beginning 2025
DS_COLLISIONS = "h9gi-nx95"              # Motor Vehicle Collisions - Crashes
# Parking Violations Issued is one dataset per fiscal year (Jul-Jun). FY2026 is pvqr-7yc4;
# point this at the current year's dataset once NYC publishes it.
DS_PARKING_VIOLATIONS = os.getenv("DS_PARKING_VIOLATIONS", "pvqr-7yc4")
DS_PARKING_SIGNS = "nfid-uabd"           # Parking Regulation Locations and Signs

SLOW_FEED_TTL_SECONDS = int(os.getenv("SLOW_FEED_TTL_SECONDS", "3600"))   # permits, closures
EXTRAS_SUBWAY_WEEKS = 8
EXTRAS_CRASH_DAYS = 365
EXTRAS_TICKET_DAYS = 90
# Permitted events skipped unless they close a street: youth/adult league games etc.
PERMIT_SKIP_TYPE_PREFIXES = ("Sport - Youth", "Sport - Adult")
RELIEF_STAND_PATTERNS = ("%RELIEF STAND%",)
LOADING_PATTERNS = ("%COMMERCIAL VEHICLES ONLY%", "%TRUCK LOADING%", "%LOADING ONLY%", "%LOADING ZONE%")

# Starting points a driver can pick
ORIGINS = {
    "jersey_city": {"label": "Jersey City / Journal Sq, NJ", "lat": 40.7330, "lon": -74.0630, "borough": "New Jersey"},
    "astoria": {"label": "Astoria, Queens", "lat": 40.7644, "lon": -73.9235, "borough": "Queens"},
    "jamaica": {"label": "Jamaica, Queens", "lat": 40.7027, "lon": -73.7890, "borough": "Queens"},
    "crown_heights": {"label": "Crown Heights, Brooklyn", "lat": 40.6681, "lon": -73.9448, "borough": "Brooklyn"},
    "south_bronx": {"label": "Mott Haven, Bronx", "lat": 40.8090, "lon": -73.9230, "borough": "Bronx"},
    "midtown": {"label": "Already in Midtown", "lat": 40.7549, "lon": -73.9840, "borough": "Manhattan"},
}
