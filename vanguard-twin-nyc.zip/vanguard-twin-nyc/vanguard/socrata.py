"""
Small client for Socrata open-data portals (NYC Open Data, NY Open Data).

An app token is optional: set SOCRATA_APP_TOKEN in .env to get higher rate
limits. Free tokens come from https://data.cityofnewyork.us/profile/edit/developer_settings
"""

import os
import time

import requests

NYC = "data.cityofnewyork.us"
NYS = "data.ny.gov"
UA = {"User-Agent": "vanguard-twin-nyc/0.3"}


def _headers():
    h = dict(UA)
    token = os.getenv("SOCRATA_APP_TOKEN", "").strip()
    if token:
        h["X-App-Token"] = token
    return h


RETRY_WAITS = (5, 20, 60)   # seconds between attempts: open-data servers often 503 or time out briefly


def get(domain, dataset, params=None, timeout=30, retries=None):
    """One SoQL request, retried on timeouts, 429 and 5xx. Returns a list of row dicts.
    retries=None uses every wait in RETRY_WAITS (build time); live feeds pass a small number."""
    waits = RETRY_WAITS if retries is None else RETRY_WAITS[:retries]
    for attempt in range(len(waits) + 1):
        try:
            r = requests.get(f"https://{domain}/resource/{dataset}.json", params=params or {},
                             headers=_headers(), timeout=timeout)
            r.raise_for_status()
            return r.json()
        except (requests.Timeout, requests.ConnectionError, requests.HTTPError) as exc:
            status = getattr(getattr(exc, "response", None), "status_code", None)
            retryable = status is None or status == 429 or status >= 500
            if not retryable or attempt == len(waits):
                raise
            wait = waits[attempt]
            print(f"    {dataset}: {exc.__class__.__name__}{f' {status}' if status else ''}, retrying in {wait}s", flush=True)
            time.sleep(wait)


def latest(domain, dataset, field, where=None):
    """Most recent value of a date field, via ORDER BY DESC LIMIT 1 (fast on indexed fields)."""
    q = {"$select": field, "$order": f"{field} DESC", "$limit": 1, "$where": f"{field} IS NOT NULL"}
    if where:
        q["$where"] += f" AND {where}"
    rows = get(domain, dataset, q)
    return rows[0][field] if rows else None


def get_all(domain, dataset, params=None, page=50000, max_rows=500000, timeout=60, retries=None):
    """Page through a SoQL query with $limit/$offset. Needs a stable $order."""
    params = dict(params or {})
    out, offset = [], 0
    while offset < max_rows:
        rows = get(domain, dataset, {**params, "$limit": page, "$offset": offset}, timeout=timeout, retries=retries)
        out.extend(rows)
        if len(rows) == page:
            print(f"    {dataset}: {len(out):,} rows so far", flush=True)
        if len(rows) < page:
            break
        offset += page
    return out
