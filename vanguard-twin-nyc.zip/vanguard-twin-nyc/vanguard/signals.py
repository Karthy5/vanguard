"""
External signals for partners: what is happening in each NYC zone, hour by hour.

This module returns no earnings estimates. A partner combines these signals
with its own earnings data. Every field is labeled with where it comes from
(live feed, aggregated public records, learned from public data, or an
assumption), so nothing reads as more certain than it is.
"""

import json
import math
from datetime import datetime, timedelta

from . import config
from .model import CAL, _dot, _features
from .zones import assign_points, region_of_zone, zone_for_point, zones

AIRPORT_CODES = {132: "JFK", 138: "LGA"}

SOURCES = {
    "weather": {"provider": "Open-Meteo hourly forecast (one point in Midtown)",
                "terms": "Free tier is non-commercial; commercial use needs an Open-Meteo plan"},
    "nws_alerts": {"provider": "National Weather Service alerts (api.weather.gov), one point per borough",
                   "terms": "US government work, public domain; send an identifying User-Agent"},
    "traffic": {"provider": "NYC DOT real-time link speeds (NYC Open Data i4gi-tjb9)", "terms": "NYC Open Data terms of use"},
    "airports": {"provider": "FAA National Airspace System status", "terms": "Public"},
    "events": {"provider": "Ticketmaster Discovery API",
               "terms": "Ticketmaster API terms: attribution, caching and commercial limits apply; use your own key"},
    "permitted_events": {"provider": "NYC Permitted Event Information (NYC Open Data tvpp-9vvx)",
                         "terms": "NYC Open Data terms of use"},
    "transit_alerts": {"provider": "MTA GTFS-realtime service alerts: subway, LIRR, Metro-North",
                       "terms": "MTA developer terms and conditions (mta.info/developers/terms-and-conditions)"},
    "street_closures": {"provider": "NYC DOT street closures for construction (NYC Open Data i6b5-j7bu)",
                        "terms": "NYC Open Data terms of use"},
    "citibike": {"provider": "Citi Bike GBFS station information and status",
                 "terms": "Citi Bike Data License Agreement (citibikenyc.com/data-sharing-policy)"},
}


# ---------------------------------------------------------------------------
# Build-time extras (data/extras.json), reloaded when the file changes
# ---------------------------------------------------------------------------
class Extras:
    def __init__(self):
        self._mtime, self.data = None, {}

    def get(self):
        p = config.EXTRAS_PATH
        mtime = p.stat().st_mtime if p.exists() else None
        if mtime != self._mtime:
            try:
                self.data = json.loads(p.read_text()) if mtime else {}
            except (OSError, ValueError):
                self.data = {}
            self._mtime = mtime
        return self.data

    def status(self):
        d = self.get()
        if not d:
            return {"built": False, "message": "Run `python -m vanguard.extras` for ridership, crashes, tickets and curb data."}
        return {"built": True, "generated_at": d["meta"]["generated_at"], "sections": d["meta"]["sections"]}


EXTRAS = Extras()
_memo = {}


def _zones_for(name, feed, items):
    """Map a feed's points to zones once per fetch."""
    key = (name, (feed or {}).get("fetched_at"), len(items))
    if key not in _memo:
        if len(_memo) > 32:
            _memo.clear()
        _memo[key] = assign_points([(i.get("lat"), i.get("lon")) for i in items])
    return _memo[key]


def _provenance(calibrated):
    learned = "learned" if calibrated else "placeholder_prior"
    return {
        "city_hours[].weather": "live: Open-Meteo forecast",
        "city_hours[].alerts[type!=nws]": "assumption: thresholds in vanguard/config.py applied to the forecast",
        "city_hours[].alerts[type=nws]": "live: National Weather Service",
        "transit_alerts": "live: MTA GTFS-realtime",
        "zones[].now.traffic.speed_mph": "live: NYC DOT median link speed in the zone's borough",
        "zones[].now.traffic.ratio_to_typical": "assumption: typical speeds in vanguard/config.py",
        "zones[].now.airport_delays": "live: FAA NAS status",
        "zones[].now.transit_alerts": "live: MTA alerts, placed by station (stop match) or by route served (route match)",
        "zones[].now.street_closures": "live: DOT construction permits active today, placed by block midpoint",
        "zones[].now.citibike": "live: Citi Bike GBFS, stations inside the zone",
        "zones[].curb": "public records: DOT parking-sign inventory (relief stands, commercial loading signs)",
        "zones[].hours[].seasonal_trips_per_hr": f"{learned}: average TLC HVFHV pickups, zone x weekday x hour",
        "zones[].hours[].seasonal_trip_index": f"{learned}: zone's seasonal trips / median zone, same weekday and hour",
        "zones[].hours[].weather_trip_effect_pct": f"{learned}: regression of trips on weather, tested on held-out days",
        "zones[].hours[].events[].demand_lift_pct": "prior: not validated (no free historical event feed)",
        "zones[].hours[].permitted_events": "live: NYC permits, placed by police precinct (not exact location)",
        "zones[].hours[].subway_entries_per_hr": "public records: MTA hourly ridership, recent weeks averaged",
        "zones[].hours[].injury_crashes_per_yr": "public records: NYPD collisions with injuries, last 12 months, 4-hour block",
        "zones[].hours[].parking_tickets_per_day": "public records: DOF tickets in the zone's precinct, by hour",
    }


# ---------------------------------------------------------------------------
# Weather and alerts
# ---------------------------------------------------------------------------
def _hour_weather(wx, when, now_hour):
    hourly = (wx or {}).get("hourly") or {}
    h = hourly.get(when.strftime("%Y-%m-%dT%H"))
    if h:
        return {"temp_f": h.get("temp_f"), "precip_mm": h.get("precip_mm"),
                "precip_prob_pct": h.get("precip_prob"), "wind_mph": h.get("wind_mph")}
    if when == now_hour and (wx or {}).get("status") in ("live", "stale"):
        return {"temp_f": wx.get("temp_f"), "precip_mm": wx.get("precip_mm"),
                "precip_prob_pct": None, "wind_mph": wx.get("wind_mph")}
    return None


def _wet(w):
    if not w:
        return False
    if (w.get("precip_mm") or 0) >= config.ALERT_RAIN_MM:
        return True
    return (w.get("precip_prob_pct") or 0) >= config.ALERT_RAIN_PROB_PCT


def _alerts(w, prev_w):
    if not w:
        return []
    out = []
    temp, wind, precip = w.get("temp_f"), w.get("wind_mph"), w.get("precip_mm") or 0
    if _wet(w) and prev_w is not None and not _wet(prev_w):
        out.append({"type": "rain_onset", "message": "Rain likely to start this hour"})
    if precip >= config.ALERT_HEAVY_RAIN_MM:
        out.append({"type": "heavy_rain", "message": f"Heavy rain, about {precip:.1f} mm/hr"})
    if wind is not None and wind >= config.ALERT_HIGH_WIND_MPH:
        out.append({"type": "high_wind", "message": f"Wind about {wind:.0f} mph; hard going on a bike"})
    if temp is not None and temp >= config.ALERT_HEAT_F:
        out.append({"type": "heat", "message": f"About {temp:.0f}°F"})
    if temp is not None and temp <= config.ALERT_COLD_F:
        out.append({"type": "cold", "message": f"About {temp:.0f}°F"})
    if temp is not None and temp <= config.ALERT_ICE_MAX_F and _wet(w):
        out.append({"type": "ice_risk", "message": "Precipitation near freezing; roads and bike lanes may ice"})
    return out


def _overlaps(start, end, t0, t1):
    """ISO strings or None; True if [start, end] overlaps [t0, t1)."""
    s = datetime.fromisoformat(start) if start else None
    e = datetime.fromisoformat(end) if end else None
    return (s is None or s < t1) and (e is None or e >= t0)


def _nws_for_hour(nws, t):
    t1 = t + timedelta(hours=1)
    return [{"type": "nws", "event": a.get("event"), "severity": a.get("severity"),
             "message": a.get("headline"), "boroughs": a.get("boroughs"), "start": a.get("start"), "end": a.get("end")}
            for a in nws if _overlaps(a.get("start"), a.get("end"), t, t1)]


# ---------------------------------------------------------------------------
# Events
# ---------------------------------------------------------------------------
def _zone_events(zone_id, when, events):
    """Ticketmaster events that affect this zone in this clock hour, with the phase."""
    out = []
    mid = when + timedelta(minutes=30)
    for e in events:
        if e.get("zone_id") != zone_id:
            continue
        try:
            start, end = datetime.fromisoformat(e["start"]), datetime.fromisoformat(e["est_end"])
        except (KeyError, ValueError):
            continue
        size = config.EVENT_EGRESS_MAX_DEMAND_LIFT * min(1.0, e.get("capacity_est", 0) / config.EVENT_FULL_EFFECT_CAPACITY)
        if end - timedelta(minutes=30) <= mid <= end + timedelta(minutes=75):
            phase, lift = "let_out", size
        elif start - timedelta(minutes=90) <= mid <= start:
            phase, lift = "arrivals", size * 0.4
        else:
            continue
        out.append({
            "name": e.get("name"), "venue": e.get("venue"), "segment": e.get("segment"),
            "phase": phase, "start": e["start"], "est_end": e["est_end"],
            "capacity_est": e.get("capacity_est"), "demand_lift_pct": round(lift * 100, 1),
            "url": e.get("url"), "source": "Ticketmaster",
        })
    return out


def _permits_for(zone_precinct, permits, t):
    if zone_precinct is None:
        return []
    t1 = t + timedelta(hours=1)
    return [{"name": p["name"], "type": p["type"], "street_closure": p["street_closure"],
             "location": p["location"], "start": p["start"], "end": p["end"], "match": "precinct"}
            for p in permits if zone_precinct in p["precincts"] and _overlaps(p["start"], p["end"], t, t1)]


# ---------------------------------------------------------------------------
# Transit alerts -> zones
# ---------------------------------------------------------------------------
def _hub_zones():
    out = {}
    for mode, hubs in config.RAIL_HUBS.items():
        out[mode] = sorted({z for z in (zone_for_point(lat, lon) for _, lat, lon in hubs) if z is not None})
    return out


def _transit_by_zone(alerts, subway_maps):
    stop_zone = subway_maps.get("stop_zone") or {}
    route_zones = subway_maps.get("route_zones") or {}
    hubs = _hub_zones()
    by_zone = {}
    for a in alerts:
        matched = {}
        if a["mode"] == "subway":
            for s in a.get("stops") or []:
                z = stop_zone.get(s) or stop_zone.get(s[:-1])   # GTFS stops may carry an N/S suffix
                if z is not None:
                    matched[z] = "stop"
            if not matched:
                for r in a.get("routes") or []:
                    for z in route_zones.get(r, []):
                        matched.setdefault(z, "route")
        else:
            for z in hubs.get(a["mode"], []):
                matched[z] = "terminal"
        compact = {k: a.get(k) for k in ("mode", "alert_type", "planned", "routes", "header", "start", "end")}
        for z, how in matched.items():
            by_zone.setdefault(z, []).append({**compact, "match": how})
    return by_zone


def _source_status(live):
    out = {}
    for name, meta in SOURCES.items():
        feed = live.get(name) or {}
        out[name] = {**meta, "status": feed.get("status", "offline"),
                     "fetched_at": feed.get("fetched_at"), "error": feed.get("error")}
    return out


def _r(v, nd=1):
    return round(v, nd) if isinstance(v, (int, float)) else None


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------
def build(live, start=None, hours=6, zone_ids=None):
    """Signals for every tracked zone (or zone_ids) for `hours` clock hours from `start`."""
    CAL.maybe_reload()
    ex = EXTRAS.get()
    now_hour = datetime.now().replace(minute=0, second=0, microsecond=0)
    start = (start or now_hour).replace(minute=0, second=0, microsecond=0)
    hours = max(1, min(config.SIGNALS_MAX_HOURS, int(hours)))
    times = [start + timedelta(hours=i) for i in range(hours)]

    wx = live.get("weather") or {}
    events = (live.get("events") or {}).get("events", []) or []
    traffic = (live.get("traffic") or {}).get("median_mph") or {}
    delays = (live.get("airports") or {}).get("delays") or {}
    nws = (live.get("nws_alerts") or {}).get("alerts", []) or []
    transit = (live.get("transit_alerts") or {}).get("alerts", []) or []
    permits = (live.get("permitted_events") or {}).get("events", []) or []
    closures = (live.get("street_closures") or {}).get("closures", []) or []
    bikes = (live.get("citibike") or {}).get("stations", []) or []

    # City-level weather and alerts, one row per hour
    prev = _hour_weather(wx, start - timedelta(hours=1), now_hour)
    city_hours, weather_by_t = [], {}
    for t in times:
        w = _hour_weather(wx, t, now_hour)
        weather_by_t[t] = w
        city_hours.append({"t": t.isoformat(timespec="minutes"), "weather": w,
                           "alerts": _alerts(w, prev) + _nws_for_hour(nws, t)})
        prev = w

    selected = [z for z in zones() if zone_ids is None or z["id"] in zone_ids]
    region = region_of_zone()

    # Seasonal trips for every zone, so the index compares to the whole city
    seasonal = {t: {z["id"]: (CAL.slot(z, t.weekday(), t.hour) or {}).get("trips") for z in zones()} for t in times}
    medians = {t: _median(v.values()) for t, v in seasonal.items()}

    # Extras: subway entries and its per-hour median across zones with stations
    rid = (ex.get("ridership") or {}).get("zones") or {}
    rid_med = {t: _median(rid.get(str(z["id"]), {}).get(f"{t.weekday()}-{t.hour}") for z in zones()) for t in times}
    crashes = (ex.get("crashes") or {}).get("zones") or {}
    tickets = (ex.get("tickets") or {}).get("precincts") or {}
    zone_pct = (ex.get("precincts") or {}).get("zone_precinct") or {}
    curb = (ex.get("curb") or {}).get("zones") or {}

    # Live point feeds -> zones
    transit_zone = _transit_by_zone(transit, ex.get("subway") or {})
    closure_zone, bike_zone = {}, {}
    for c, z in zip(closures, _zones_for("closures", live.get("street_closures"), closures)):
        if z is not None:
            closure_zone.setdefault(z, []).append(c)
    for b, z in zip(bikes, _zones_for("citibike", live.get("citibike"), bikes)):
        if z is not None:
            bike_zone.setdefault(z, []).append(b)

    zone_rows = []
    for z in selected:
        zid, key = z["id"], str(z["id"])
        speed = traffic.get(z["borough"])
        typical = config.DEFAULT_SPEED_MPH.get(z["borough"])
        zc = closure_zone.get(zid, [])
        zb = bike_zone.get(zid)
        now = {
            "traffic": {"speed_mph": speed,
                        "ratio_to_typical": round(speed / typical, 2) if speed and typical else None},
            "airport_delays": delays.get(AIRPORT_CODES[zid], []) if zid in AIRPORT_CODES else None,
            "transit_alerts": transit_zone.get(zid, []),
            "street_closures": {"count": len(zc), "examples": [
                {k: c[k] for k in ("on_street", "from_street", "to_street", "purpose", "end")} for c in zc[:3]]},
            "citibike": {"stations": len(zb), "bikes": sum(b["bikes"] for b in zb),
                         "ebikes": sum(b["ebikes"] for b in zb), "docks": sum(b["docks"] for b in zb)} if zb else None,
        }
        pct = zone_pct.get(key)
        hour_rows = []
        for t in times:
            trips, med, w = seasonal[t][zid], medians[t], weather_by_t[t]
            effect = None
            if w and w.get("precip_mm") is not None:
                x = _features(z, w.get("precip_mm"), w.get("temp_f"))
                effect = round((math.exp(_dot(x[1:], CAL.coefs["demand"][1:])) - 1) * 100, 1)
            entries = rid.get(key, {}).get(f"{t.weekday()}-{t.hour}")
            block = f"{(t.hour // 4) * 4:02d}-{(t.hour // 4) * 4 + 4:02d}"
            zc_ = crashes.get(key) or {}
            hour_rows.append({
                "t": t.isoformat(timespec="minutes"),
                "seasonal_trips_per_hr": _r(trips),
                "seasonal_trip_index": round(trips / med, 2) if trips is not None and med else None,
                "weather_trip_effect_pct": effect,
                "events": _zone_events(zid, t, events),
                "permitted_events": _permits_for(pct, permits, t),
                "subway_entries_per_hr": _r(entries),
                "subway_entries_index": round(entries / rid_med[t], 2) if entries is not None and rid_med[t] else None,
                "injury_crashes_per_yr": _r((zc_.get("injury_crashes") or {}).get(block)) if crashes else None,
                "cyclist_injuries_per_yr": _r((zc_.get("cyclist_injuries") or {}).get(block)) if crashes else None,
                "parking_tickets_per_day": _r((tickets.get(str(pct)) or {}).get(str(t.hour)), 2)
                if tickets and pct is not None else None,
            })
        zcurb = curb.get(key) or {}
        zone_rows.append({
            "zone_id": zid, "name": z["name"], "borough": z["borough"],
            "region_id": region.get(zid), "lat": z["lat"], "lon": z["lon"],
            "airport": z["airport"], "staging_hint": z["staging"], "police_precinct": pct,
            "curb": {"relief_stands": zcurb.get("relief_stands", []),
                     "loading_zone_blocks": zcurb.get("loading_zone_blocks", 0)} if curb else None,
            "now": now, "hours": hour_rows,
        })

    return {
        "api_version": config.SIGNALS_API_VERSION,
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "timezone": config.TZ,
        "window": {"start": start.isoformat(timespec="minutes"), "hours": hours},
        "calibration": CAL.status(),
        "extras": EXTRAS.status(),
        "sources": _source_status(live),
        "provenance": _provenance(CAL.calibrated),
        "city_hours": city_hours,
        "transit_alerts": [{k: a.get(k) for k in ("mode", "alert_type", "planned", "routes", "header", "start", "end")}
                           for a in transit],
        "zones": zone_rows,
    }


def _median(values):
    vals = sorted(v for v in values if v is not None)
    return vals[len(vals) // 2] if vals else None
