"""Small numpy-only OLS with cluster-robust standard errors."""

import math

import numpy as np


def ols(X, y, names, clusters=None, weights=None):
    """
    Fit y = X @ beta. X must already include an intercept column if wanted.
    Standard errors are clustered by `clusters` (e.g. calendar day) when given,
    otherwise HC1. Hourly errors are autocorrelated within a day, so
    clustering by day is the honest default.
    """
    X = np.asarray(X, dtype=float)
    y = np.asarray(y, dtype=float)
    n, k = X.shape
    if weights is not None:
        sw = np.sqrt(np.asarray(weights, dtype=float))
        Xw, yw = X * sw[:, None], y * sw
    else:
        Xw, yw = X, y

    beta, *_ = np.linalg.lstsq(Xw, yw, rcond=None)
    resid = yw - Xw @ beta
    bread = np.linalg.pinv(Xw.T @ Xw)

    if clusters is not None:
        clusters = np.asarray(clusters)
        groups = np.unique(clusters)
        g = len(groups)
        meat = np.zeros((k, k))
        for grp in groups:
            m = clusters == grp
            s = Xw[m].T @ resid[m]
            meat += np.outer(s, s)
        adj = (g / max(1, g - 1)) * ((n - 1) / max(1, n - k))
        se_kind = f"clustered by day (G={g})"
    else:
        meat = (Xw * resid[:, None] ** 2).T @ Xw
        adj = n / max(1, n - k)
        se_kind = "HC1 robust"

    cov = adj * bread @ meat @ bread
    se = np.sqrt(np.clip(np.diag(cov), 0, None))

    ss_res = float(resid @ resid)
    ss_tot = float(((yw - yw.mean()) ** 2).sum())
    r2 = 1 - ss_res / ss_tot if ss_tot > 0 else None

    coefs = []
    for i, name in enumerate(names):
        # A feature with no variation (e.g. no hot hours in winter data) has no SE.
        t = float(beta[i] / se[i]) if se[i] > 0 else None
        p = math.erfc(abs(t) / math.sqrt(2)) if t is not None else None
        coefs.append({
            "name": name,
            "beta": float(beta[i]),
            "se": float(se[i]),
            "ci95": [float(beta[i] - 1.96 * se[i]), float(beta[i] + 1.96 * se[i])] if se[i] > 0 else None,
            "t": t,
            "p": p,
        })
    return {"coefs": coefs, "n": int(n), "r2": r2, "se_kind": se_kind, "beta": beta}


def mae(a, b, weights=None):
    a, b = np.asarray(a, float), np.asarray(b, float)
    err = np.abs(a - b)
    if weights is None:
        return float(err.mean())
    w = np.asarray(weights, float)
    return float((err * w).sum() / w.sum())
