"""
Live public feeds. Each fetch is cached for FEED_TTL_SECONDS and reports
an honest status (live / stale / offline) so the UI never shows a fallback
number as live.
"""

import threading
import time
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

import requests

from . import config, socrata
from .zones import haversine_miles, zone_by_id, zone_for_point

UA = {"User-Agent": "vanguard-twin-nyc/0.2 (+https://github.com/)"}
_cache = {}
_lock = threading.Lock()


def _cached(name, fn, ttl=None):
    now = time.time()
    ttl = config.FEED_TTL_SECONDS if ttl is None else ttl
    with _lock:
        hit = _cache.get(name)
        if hit and now - hit["at"] < ttl:
            return hit["value"]
    try:
        value = fn()
        value["status"] = "live"
        value["fetched_at"] = datetime.now().isoformat(timespec="seconds")
    except Exception as exc:  # noqa: BLE001 - every feed must degrade gracefully
        if hit:
            value = {**hit["value"], "status": "stale", "error": exc.__class__.__name__}
        else:
            value = {"status": "offline", "error": f"{exc.__class__.__name__}: {str(exc)[:80]}"}
    with _lock:
        _cache[name] = {"at": now, "value": value}
    return value


# ---------------------------------------------------------------------------
# Weather: current conditions + hourly forecast (Open-Meteo, no key)
# ---------------------------------------------------------------------------
def weather():
    def fetch():
        r = requests.get("https://api.open-meteo.com/v1/forecast", params={
            "latitude": config.NYC_LAT, "longitude": config.NYC_LON,
            "current": "temperature_2m,precipitation,weather_code,wind_speed_10m",
            "hourly": "temperature_2m,precipitation,precipitation_probability,wind_speed_10m",
            "forecast_days": 2, "temperature_unit": "fahrenheit", "wind_speed_unit": "mph",
            "timezone": config.TZ,
        }, headers=UA, timeout=20)
        r.raise_for_status()
        j = r.json()
        c, h = j["current"], j["hourly"]
        wind = h.get("wind_speed_10m") or [None] * len(h["time"])
        hourly = {t[:13]: {"temp_f": tf, "precip_mm": p or 0.0, "precip_prob": pp, "wind_mph": w}
                  for t, tf, p, pp, w in zip(h["time"], h["temperature_2m"], h["precipitation"],
                                             h["precipitation_probability"], wind)}
        return {
            "temp_f": c["temperature_2m"], "precip_mm": c["precipitation"],
            "wind_mph": c["wind_speed_10m"], "code": c["weather_code"],
            "label": _wmo_label(c["weather_code"]), "hourly": hourly,
        }
    return _cached("weather", fetch)


def _wmo_label(code):
    table = [((0,), "Clear"), ((1, 2), "Partly cloudy"), ((3,), "Overcast"), ((45, 48), "Fog"),
             ((51, 53, 55, 56, 57), "Drizzle"), ((61, 63, 66, 80, 81), "Rain"), ((65, 67, 82), "Heavy rain"),
             ((71, 73, 75, 77, 85, 86), "Snow"), ((95, 96, 99), "Thunderstorm")]
    return next((label for codes, label in table if code in codes), "—")


# ---------------------------------------------------------------------------
# Traffic: NYC DOT real-time link speeds (Socrata i4gi-tjb9)
# ---------------------------------------------------------------------------
def traffic():
    def fetch():
        r = requests.get("https://data.cityofnewyork.us/resource/i4gi-tjb9.json",
                         params={"$limit": 400, "$order": "data_as_of DESC"}, headers=UA, timeout=8)
        r.raise_for_status()
        rows = r.json()
        by_boro = {}
        for row in rows:
            try:
                spd = float(row.get("speed", 0))
            except (TypeError, ValueError):
                continue
            b = row.get("borough")
            if b and 1 < spd < 70:
                by_boro.setdefault(b, []).append(spd)
        speeds = {b: round(sorted(v)[len(v) // 2], 1) for b, v in by_boro.items() if len(v) >= 3}
        return {"median_mph": speeds, "links": len(rows),
                "as_of": (rows[0].get("data_as_of", "")[:16] if rows else "")}
    return _cached("traffic", fetch)


# ---------------------------------------------------------------------------
# Airports: FAA NAS status (JFK / LGA ground delays, closures)
# ---------------------------------------------------------------------------
def airports():
    def fetch():
        r = requests.get("https://nasstatus.faa.gov/api/airport-status-information", headers=UA, timeout=8)
        r.raise_for_status()
        root = ET.fromstring(r.content)
        out = {"JFK": [], "LGA": []}
        for node in root.iter():
            arpt = (node.findtext("ARPT") or "").strip().upper()
            if arpt in out:
                reason = node.findtext("Reason") or node.tag
                avg = node.findtext("Avg") or node.findtext(".//Avg_Delay") or ""
                out[arpt].append(f"{reason} {avg}".strip())
        return {"delays": out}
    return _cached("airports", fetch)


# ---------------------------------------------------------------------------
# Events: Ticketmaster Discovery v2 (needs a free key in .env)
# ---------------------------------------------------------------------------
# Rough seated capacities for venues that matter. Unknown venues default to
# 1,500 so a museum or a jazz club can't look like an arena.
VENUE_CAPACITY = {
    "madison square garden": 19500, "barclays center": 17700, "yankee stadium": 46500,
    "citi field": 41900, "radio city music hall": 5960, "ubs arena": 17000,
    "beacon theatre": 2894, "kings theatre": 3000, "terminal 5": 3000,
    "hammerstein ballroom": 2500, "brooklyn steel": 1800, "webster hall": 1500,
    "the theater at madison square garden": 5600, "carnegie hall": 2804,
    "apollo theater": 1500, "forest hills stadium": 14000, "metlife stadium": 82500,
}
DEFAULT_CAPACITY = 1500
SKIP_WORDS = ("parking", "admission", "upgrade", "package", "tour ", "flex", "voucher", "gift card", "museum")


def events():
    if not config.TICKETMASTER_API_KEY:
        return {"status": "disabled", "events": [],
                "error": "Set TICKETMASTER_API_KEY in .env to enable the event layer"}

    def fetch():
        now = datetime.now()
        r = requests.get("https://app.ticketmaster.com/discovery/v2/events.json", params={
            "apikey": config.TICKETMASTER_API_KEY,
            "latlong": f"{config.NYC_LAT},{config.NYC_LON}", "radius": 12, "unit": "miles",
            "startDateTime": (now - timedelta(hours=4)).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "endDateTime": (now + timedelta(hours=20)).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "size": 100, "sort": "date,asc",
        }, headers=UA, timeout=8)
        r.raise_for_status()
        out, seen = [], set()
        for e in r.json().get("_embedded", {}).get("events", []):
            name = e.get("name", "")
            if any(w in name.lower() for w in SKIP_WORDS):
                continue
            seg = ((e.get("classifications") or [{}])[0].get("segment") or {}).get("name", "")
            if seg not in config.EVENT_DURATION_HOURS:
                continue
            start = (e.get("dates") or {}).get("start") or {}
            if not start.get("localDate") or not start.get("localTime"):
                continue
            v = ((e.get("_embedded") or {}).get("venues") or [{}])[0]
            loc = v.get("location") or {}
            if not loc.get("latitude"):
                continue
            lat, lon = float(loc["latitude"]), float(loc["longitude"])
            zid = zone_for_point(lat, lon)
            if zid is None:
                continue
            vname = v.get("name", "Venue")
            st = datetime.fromisoformat(f"{start['localDate']}T{start['localTime']}")
            key = (vname, st)
            if key in seen:
                continue
            seen.add(key)
            end = st + timedelta(hours=config.EVENT_DURATION_HOURS.get(seg, config.EVENT_DEFAULT_DURATION))
            cap = VENUE_CAPACITY.get(vname.lower(), DEFAULT_CAPACITY)
            out.append({
                "name": name, "venue": vname, "segment": seg, "zone_id": zid,
                "zone_name": zone_by_id(zid)["name"], "start": st.isoformat(timespec="minutes"),
                "est_end": end.isoformat(timespec="minutes"), "capacity_est": cap,
                "lat": lat, "lon": lon, "url": e.get("url"),
            })
        return {"events": out}
    return _cached("events", fetch)


# ---------------------------------------------------------------------------
# Time helpers: every timestamp leaves this module as naive NYC local time
# ---------------------------------------------------------------------------
_NYC = ZoneInfo(config.TZ)


def _local(value):
    """ISO string with offset, or epoch seconds -> naive NYC local datetime (or None)."""
    if value in (None, "", 0, "0"):
        return None
    try:
        if isinstance(value, (int, float)) or str(value).isdigit():
            return datetime.fromtimestamp(int(value), _NYC).replace(tzinfo=None)
        dt = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        return dt.astimezone(_NYC).replace(tzinfo=None) if dt.tzinfo else dt
    except (ValueError, OSError, OverflowError):
        return None


def _iso(dt):
    return dt.isoformat(timespec="minutes") if dt else None


# ---------------------------------------------------------------------------
# NWS alerts: official watches, warnings and advisories (api.weather.gov)
# ---------------------------------------------------------------------------
def parse_nws(features_by_borough):
    """{borough: [GeoJSON feature]} -> deduplicated alert list."""
    alerts = {}
    for borough, features in features_by_borough.items():
        for f in features:
            p = f.get("properties") or {}
            aid = p.get("id") or f.get("id")
            if not aid:
                continue
            a = alerts.setdefault(aid, {
                "id": aid, "event": p.get("event"), "severity": p.get("severity"),
                "urgency": p.get("urgency"), "certainty": p.get("certainty"),
                "headline": p.get("headline"),
                "start": _iso(_local(p.get("onset") or p.get("effective"))),
                "end": _iso(_local(p.get("ends") or p.get("expires"))),
                "boroughs": [],
            })
            if borough not in a["boroughs"]:
                a["boroughs"].append(borough)
    return sorted(alerts.values(), key=lambda a: (a["start"] or "", a["event"] or ""))


def nws_alerts():
    def fetch():
        headers = {"User-Agent": config.NWS_USER_AGENT, "Accept": "application/geo+json"}
        by_boro = {}
        for boro, (lat, lon) in config.NWS_POINTS.items():
            r = requests.get("https://api.weather.gov/alerts/active", params={"point": f"{lat},{lon}"},
                             headers=headers, timeout=8)
            r.raise_for_status()
            by_boro[boro] = r.json().get("features", [])
        return {"alerts": parse_nws(by_boro)}
    return _cached("nws_alerts", fetch)


# ---------------------------------------------------------------------------
# MTA service alerts: subway, LIRR, Metro-North (GTFS-realtime, JSON flavour)
# ---------------------------------------------------------------------------
def _g(d, *keys):
    """First present key, so both snake_case and camelCase JSON work."""
    for k in keys:
        if isinstance(d, dict) and k in d:
            return d[k]
    return None


def _english(ts):
    for t in (_g(ts, "translation") or []):
        if (t.get("language") or "en") == "en":
            return t.get("text")
    tr = _g(ts, "translation") or []
    return tr[0].get("text") if tr else None


def parse_mta_alerts(feed_json, mode, now=None, horizon_hours=24):
    """GTFS-rt alerts JSON -> alerts active now or starting within horizon_hours."""
    now = now or datetime.now()
    horizon = now + timedelta(hours=horizon_hours)
    out = []
    for ent in feed_json.get("entity", []) or []:
        al = ent.get("alert")
        if not al:
            continue
        periods = []
        for p in _g(al, "active_period", "activePeriod") or []:
            periods.append((_local(p.get("start")), _local(p.get("end"))))
        if periods and not any((s is None or s <= horizon) and (e is None or e >= now) for s, e in periods):
            continue
        merc = _g(al, "transit_realtime.mercury_alert", "mercuryAlert") or {}
        atype = _g(merc, "alert_type", "alertType")
        routes, stops = set(), set()
        for ie in _g(al, "informed_entity", "informedEntity") or []:
            if _g(ie, "route_id", "routeId"):
                routes.add(str(_g(ie, "route_id", "routeId")))
            if _g(ie, "stop_id", "stopId"):
                stops.add(str(_g(ie, "stop_id", "stopId")))
        active = [(s, e) for s, e in periods if (s is None or s <= horizon) and (e is None or e >= now)]
        start = min((s for s, _ in active if s), default=None)
        end = max((e for _, e in active if e), default=None)
        out.append({
            "id": ent.get("id"), "mode": mode, "alert_type": atype,
            "planned": bool(atype and str(atype).lower().startswith("planned")),
            "routes": sorted(routes), "stops": sorted(stops),
            "header": _english(_g(al, "header_text", "headerText") or {}),
            "start": _iso(start), "end": _iso(end),
        })
    return out


def transit_alerts():
    def fetch():
        headers = dict(UA)
        if config.MTA_API_KEY:
            headers["x-api-key"] = config.MTA_API_KEY
        alerts, failed = [], []
        for mode, feed in config.MTA_ALERT_FEEDS.items():
            try:
                r = requests.get(config.MTA_ALERTS_URL.format(feed=feed), headers=headers, timeout=10)
                r.raise_for_status()
                alerts.extend(parse_mta_alerts(r.json(), mode))
            except Exception as exc:  # noqa: BLE001 - one mode failing shouldn't hide the others
                failed.append(f"{mode}: {exc.__class__.__name__}")
        if failed and not alerts:
            raise RuntimeError("; ".join(failed))
        return {"alerts": alerts, "partial_errors": failed}
    return _cached("transit_alerts", fetch)


# ---------------------------------------------------------------------------
# NYC Permitted Events (parades, street fairs, block parties, film shoots ...)
# ---------------------------------------------------------------------------
def _precincts(value):
    out = []
    for part in str(value or "").replace(";", ",").split(","):
        part = part.strip()
        if part.isdigit():
            out.append(int(part))
    return out


def parse_permits(rows):
    out = []
    for r in rows:
        etype = r.get("event_type") or ""
        closure = r.get("street_closure_type") or ""
        closes_street = bool(closure) and closure.upper() != "N/A"
        if etype.startswith(config.PERMIT_SKIP_TYPE_PREFIXES) and not closes_street:
            continue
        start, end = _local(r.get("start_date_time")), _local(r.get("end_date_time"))
        if not start or not end:
            continue
        out.append({
            "id": r.get("event_id"), "name": r.get("event_name"), "type": etype,
            "agency": r.get("event_agency"), "borough": r.get("event_borough"),
            "location": (r.get("event_location") or "").strip()[:160],
            "street_closure": closure if closes_street else None,
            "precincts": _precincts(r.get("police_precinct")),
            "start": _iso(start), "end": _iso(end),
        })
    return out


def permitted_events():
    def fetch():
        now = datetime.now()
        lo, hi = (now - timedelta(hours=2)).strftime("%Y-%m-%dT%H:%M:%S"), (now + timedelta(hours=26)).strftime("%Y-%m-%dT%H:%M:%S")
        rows = socrata.get(socrata.NYC, config.DS_PERMITTED_EVENTS, {
            "$where": f"start_date_time <= '{hi}' AND end_date_time >= '{lo}'",
            "$limit": 5000, "$order": "start_date_time"}, timeout=20, retries=1)
        return {"events": parse_permits(rows), "rows": len(rows)}
    return _cached("permitted_events", fetch, ttl=config.SLOW_FEED_TTL_SECONDS)


# ---------------------------------------------------------------------------
# DOT street closures for construction (active today)
# ---------------------------------------------------------------------------
def _line_midpoint(geom):
    if not geom:
        return None
    coords = geom.get("coordinates") or []
    if geom.get("type") == "MultiLineString":
        coords = max(coords, key=len) if coords else []
    if not coords:
        return None
    lon, lat = coords[len(coords) // 2][:2]
    return lat, lon


def parse_closures(rows):
    out = []
    for r in rows:
        mid = _line_midpoint(r.get("the_geom"))
        if not mid:
            continue
        out.append({
            "on_street": r.get("onstreetname"), "from_street": r.get("fromstreetname"),
            "to_street": r.get("tostreetname"), "purpose": r.get("purpose"),
            "start": (r.get("work_start_date") or "")[:10], "end": (r.get("work_end_date") or "")[:10],
            "lat": mid[0], "lon": mid[1],
        })
    return out


def street_closures():
    def fetch():
        today = datetime.now().strftime("%Y-%m-%dT00:00:00")
        rows = socrata.get_all(socrata.NYC, config.DS_STREET_CLOSURES, {
            "$select": "the_geom, onstreetname, fromstreetname, tostreetname, purpose, work_start_date, work_end_date",
            "$where": f"work_start_date <= '{today}' AND work_end_date >= '{today}'",
            "$order": "uniqueid"}, page=20000, max_rows=100000, timeout=30, retries=1)
        return {"closures": parse_closures(rows), "rows": len(rows)}
    return _cached("street_closures", fetch, ttl=config.SLOW_FEED_TTL_SECONDS)


# ---------------------------------------------------------------------------
# Citi Bike availability (GBFS)
# ---------------------------------------------------------------------------
def parse_gbfs(info_json, status_json):
    status = {s.get("station_id"): s for s in (status_json.get("data") or {}).get("stations", [])}
    out = []
    for st in (info_json.get("data") or {}).get("stations", []):
        s = status.get(st.get("station_id"))
        if not s or not s.get("is_renting", 1):
            continue
        out.append({"lat": st.get("lat"), "lon": st.get("lon"),
                    "bikes": s.get("num_bikes_available", 0) or 0,
                    "ebikes": s.get("num_ebikes_available", 0) or 0,
                    "docks": s.get("num_docks_available", 0) or 0})
    return out


def citibike():
    def fetch():
        info = requests.get(config.CITIBIKE_GBFS.format(feed="station_information"), headers=UA, timeout=10)
        stat = requests.get(config.CITIBIKE_GBFS.format(feed="station_status"), headers=UA, timeout=10)
        info.raise_for_status()
        stat.raise_for_status()
        return {"stations": parse_gbfs(info.json(), stat.json())}
    return _cached("citibike", fetch)


def snapshot():
    return {"weather": weather(), "traffic": traffic(), "airports": airports(), "events": events(),
            "nws_alerts": nws_alerts(), "transit_alerts": transit_alerts(),
            "permitted_events": permitted_events(), "street_closures": street_closures(),
            "citibike": citibike()}


def nearest_speed(traffic_feed, borough):
    speeds = (traffic_feed or {}).get("median_mph") or {}
    return speeds.get(borough) or config.DEFAULT_SPEED_MPH.get(borough, 14.0)


__all__ = ["weather", "traffic", "airports", "events", "nws_alerts", "transit_alerts", "permitted_events",
           "street_closures", "citibike", "snapshot", "nearest_speed", "haversine_miles"]
