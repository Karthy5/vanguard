"""
NY State Plane Long Island (EPSG:2263, US survey feet) to WGS84 lat/lon.

Several NYC datasets (DOT parking signs among them) publish coordinates in
this projection. This is the standard Lambert Conformal Conic inverse
(Snyder, Map Projections: A Working Manual, eqs. 15-1 to 15-11, 7-9) on the
GRS80 ellipsoid, so no GIS library is needed. NAD83 and WGS84 differ by
about a metre here, which doesn't matter for zone lookups.
"""

import math

_A = 6378137.0
_F = 1 / 298.257222101
_E = math.sqrt(2 * _F - _F ** 2)
_FT = 1200 / 3937                       # US survey foot in metres
_LAT1, _LAT2 = math.radians(41 + 2 / 60), math.radians(40 + 40 / 60)
_LAT0, _LON0 = math.radians(40 + 10 / 60), math.radians(-74.0)
_FE, _FN = 300000.0, 0.0                # metres


def _m(phi):
    return math.cos(phi) / math.sqrt(1 - (_E * math.sin(phi)) ** 2)


def _t(phi):
    s = _E * math.sin(phi)
    return math.tan(math.pi / 4 - phi / 2) / ((1 - s) / (1 + s)) ** (_E / 2)


_N = (math.log(_m(_LAT1)) - math.log(_m(_LAT2))) / (math.log(_t(_LAT1)) - math.log(_t(_LAT2)))
_BIGF = _m(_LAT1) / (_N * _t(_LAT1) ** _N)
_RHO0 = _A * _BIGF * _t(_LAT0) ** _N


def to_latlon(x_ft, y_ft):
    """EPSG:2263 (feet) -> (lat, lon) in degrees. Returns None for bad input."""
    try:
        x, y = float(x_ft) * _FT - _FE, float(y_ft) * _FT - _FN
    except (TypeError, ValueError):
        return None
    dy = _RHO0 - y
    rho = math.copysign(math.hypot(x, dy), _N)
    if rho == 0:
        return None
    t = (rho / (_A * _BIGF)) ** (1 / _N)
    lon = math.atan2(x, dy) / _N + _LON0
    phi = math.pi / 2 - 2 * math.atan(t)
    for _ in range(10):
        s = _E * math.sin(phi)
        nxt = math.pi / 2 - 2 * math.atan(t * ((1 - s) / (1 + s)) ** (_E / 2))
        if abs(nxt - phi) < 1e-12:
            phi = nxt
            break
        phi = nxt
    return math.degrees(phi), math.degrees(lon)
