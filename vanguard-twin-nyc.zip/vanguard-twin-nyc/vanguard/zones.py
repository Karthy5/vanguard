"""
NYC TLC taxi zones used for ranking.

IDs are official TLC LocationIDs, the same keys used in TLC trip records.
Centroids are approximate. If data/taxi_zones.geojson exists (written by the
build step), the real polygons are used for the map and for mapping venues to zones.
"""

import json
import math
from functools import lru_cache

from .config import ZONES_GEOJSON_PATH

# (location_id, name, borough, lat, lon, staging_hint)
_ZONES = [
    (132, "JFK Airport", "Queens", 40.6413, -73.7781, "FHV waiting lot; join queue only when FAA arrivals are flowing"),
    (138, "LaGuardia Airport", "Queens", 40.7769, -73.8740, "FHV waiting lot off 94th St"),
    (161, "Midtown Center", "Manhattan", 40.7580, -73.9776, "Side streets off Madison Ave, E 50s"),
    (162, "Midtown East", "Manhattan", 40.7547, -73.9707, "Lexington Ave, E 40s/50s"),
    (163, "Midtown North", "Manhattan", 40.7643, -73.9790, "W 55th–57th St between 6th & 7th Ave"),
    (164, "Midtown South", "Manhattan", 40.7488, -73.9856, "W 35th St near Herald Sq"),
    (170, "Murray Hill", "Manhattan", 40.7479, -73.9757, "3rd Ave, E 30s"),
    (186, "Penn Station / MSG West", "Manhattan", 40.7496, -73.9925, "W 31st St & 8th Ave (Moynihan side)"),
    (230, "Times Sq / Theatre District", "Manhattan", 40.7590, -73.9865, "W 46th St & 8th Ave"),
    (48, "Clinton East", "Manhattan", 40.7625, -73.9900, "9th Ave, W 40s/50s"),
    (100, "Garment District", "Manhattan", 40.7536, -73.9905, "W 38th St & 8th Ave"),
    (246, "West Chelsea / Hudson Yards", "Manhattan", 40.7510, -74.0030, "10th Ave & W 33rd St"),
    (68, "East Chelsea", "Manhattan", 40.7440, -73.9990, "8th Ave, W 20s"),
    (234, "Union Sq", "Manhattan", 40.7359, -73.9906, "E 17th St & Broadway"),
    (90, "Flatiron", "Manhattan", 40.7410, -73.9900, "W 21st St & 6th Ave"),
    (107, "Gramercy", "Manhattan", 40.7368, -73.9830, "3rd Ave & E 20th St"),
    (79, "East Village", "Manhattan", 40.7265, -73.9830, "2nd Ave & E 9th St"),
    (113, "Greenwich Village North", "Manhattan", 40.7335, -73.9960, "University Pl & E 11th St"),
    (114, "Greenwich Village South", "Manhattan", 40.7290, -74.0000, "W 4th St & 6th Ave"),
    (249, "West Village", "Manhattan", 40.7350, -74.0050, "Hudson St & Bank St"),
    (148, "Lower East Side", "Manhattan", 40.7180, -73.9880, "Essex St & Rivington St"),
    (231, "TriBeCa / Civic Center", "Manhattan", 40.7180, -74.0080, "Varick St & Franklin St"),
    (87, "Financial District North", "Manhattan", 40.7090, -74.0070, "William St & Fulton St"),
    (261, "World Trade Center", "Manhattan", 40.7115, -74.0130, "West St & Vesey St"),
    (237, "Upper East Side South", "Manhattan", 40.7690, -73.9610, "2nd Ave & E 70s"),
    (236, "Upper East Side North", "Manhattan", 40.7790, -73.9530, "2nd Ave & E 80s"),
    (142, "Lincoln Square East", "Manhattan", 40.7730, -73.9820, "Columbus Ave & W 65th St"),
    (239, "Upper West Side South", "Manhattan", 40.7800, -73.9800, "Amsterdam Ave & W 70s"),
    (41, "Central Harlem", "Manhattan", 40.8090, -73.9480, "125th St & Lenox Ave"),
    (255, "Williamsburg North Side", "Brooklyn", 40.7190, -73.9580, "Bedford Ave & N 7th St"),
    (256, "Williamsburg South Side", "Brooklyn", 40.7090, -73.9620, "Broadway & Bedford Ave"),
    (66, "DUMBO / Vinegar Hill", "Brooklyn", 40.7030, -73.9880, "Front St & Jay St"),
    (65, "Downtown Brooklyn / MetroTech", "Brooklyn", 40.6930, -73.9850, "Jay St & Willoughby St"),
    (97, "Fort Greene", "Brooklyn", 40.6890, -73.9730, "Atlantic Ave & Flatbush Ave"),
    (25, "Boerum Hill", "Brooklyn", 40.6860, -73.9830, "Atlantic Ave & Bond St"),
    (181, "Park Slope", "Brooklyn", 40.6720, -73.9780, "5th Ave & Union St"),
    (37, "Bushwick South", "Brooklyn", 40.7000, -73.9220, "Myrtle Ave & Wyckoff Ave"),
    (112, "Greenpoint", "Brooklyn", 40.7300, -73.9510, "Manhattan Ave & Greenpoint Ave"),
    (7, "Astoria", "Queens", 40.7640, -73.9230, "Steinway St & 30th Ave"),
    (145, "Long Island City / Hunters Point", "Queens", 40.7440, -73.9530, "Vernon Blvd & 49th Ave"),
    (129, "Jackson Heights", "Queens", 40.7510, -73.8830, "Roosevelt Ave & 74th St"),
    (247, "West Concourse", "Bronx", 40.8300, -73.9250, "River Ave & E 161st St"),
]

AIRPORT_IDS = {132, 138}


def haversine_miles(lat1, lon1, lat2, lon2):
    r = 3958.8
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp, dl = math.radians(lat2 - lat1), math.radians(lon2 - lon1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * r * math.asin(math.sqrt(a))


@lru_cache(maxsize=1)
def zones():
    return [
        {"id": z[0], "name": z[1], "borough": z[2], "lat": z[3], "lon": z[4],
         "staging": z[5], "airport": z[0] in AIRPORT_IDS}
        for z in _ZONES
    ]


def zone_ids():
    return [z["id"] for z in zones()]


def zone_by_id(zid):
    return next((z for z in zones() if z["id"] == zid), None)


# ---------------------------------------------------------------------------
# Polygons (optional)
# ---------------------------------------------------------------------------
def _location_id(props):
    for k in ("location_id", "locationid", "LocationID", "objectid", "OBJECTID"):
        if k in props and props[k] not in (None, ""):
            try:
                return int(float(props[k]))
            except (TypeError, ValueError):
                pass
    return None


_polygon_cache = {"mtime": None, "data": None}


def load_polygons():
    """Return {location_id: geometry} for curated zones, or {} if no geojson.
    Reloaded when the file changes (e.g. after a build)."""
    if not ZONES_GEOJSON_PATH.exists():
        return {}
    mtime = ZONES_GEOJSON_PATH.stat().st_mtime
    if _polygon_cache["mtime"] == mtime:
        return _polygon_cache["data"]
    gj = json.loads(ZONES_GEOJSON_PATH.read_text())
    wanted = set(zone_ids())
    out = {}
    for f in gj.get("features", []):
        lid = _location_id(f.get("properties", {}))
        if lid in wanted and f.get("geometry"):
            out[lid] = f["geometry"]
    _polygon_cache.update(mtime=mtime, data=out)
    return out


def _point_in_ring(lon, lat, ring):
    inside = False
    j = len(ring) - 1
    for i in range(len(ring)):
        xi, yi = ring[i][0], ring[i][1]
        xj, yj = ring[j][0], ring[j][1]
        if (yi > lat) != (yj > lat) and lon < (xj - xi) * (lat - yi) / (yj - yi + 1e-15) + xi:
            inside = not inside
        j = i
    return inside


def point_in_geometry(lon, lat, geom):
    if geom["type"] == "Polygon":
        polys = [geom["coordinates"]]
    elif geom["type"] == "MultiPolygon":
        polys = geom["coordinates"]
    else:
        return False
    for poly in polys:
        if poly and _point_in_ring(lon, lat, poly[0]) and not any(
            _point_in_ring(lon, lat, hole) for hole in poly[1:]
        ):
            return True
    return False


def zone_for_point(lat, lon, max_fallback_miles=0.6):
    """Map a point to a curated zone: polygon test first, then nearest centroid."""
    for lid, geom in load_polygons().items():
        if point_in_geometry(lon, lat, geom):
            return lid
    best = min(zones(), key=lambda z: haversine_miles(lat, lon, z["lat"], z["lon"]))
    if haversine_miles(lat, lon, best["lat"], best["lon"]) <= max_fallback_miles:
        return best["id"]
    return None


# ---------------------------------------------------------------------------
# Regions: what a driver can actually target. Trips carry drivers between
# zones every 15-20 minutes, so plans are made at the region level, with a
# staging spot (the best zone in the region) for when the driver is idle.
# ---------------------------------------------------------------------------
_REGIONS = [
    ("midtown_west", "Midtown West", [186, 230, 48, 100, 246, 164, 68]),
    ("midtown_east", "Midtown East", [161, 162, 163, 170]),
    ("village", "Village / Union Sq", [234, 90, 107, 79, 113, 114, 249, 148]),
    ("lower_mn", "Lower Manhattan", [231, 87, 261]),
    ("upper_mn", "Upper Manhattan", [237, 236, 142, 239, 41]),
    ("bk_north", "North Brooklyn", [255, 256, 112, 37]),
    ("bk_down", "Downtown Brooklyn", [66, 65, 97, 25, 181]),
    ("queens_west", "Western Queens", [7, 145, 129]),
    ("lga", "LaGuardia", [138]),
    ("jfk", "JFK", [132]),
    ("bronx", "South Bronx", [247]),
]


@lru_cache(maxsize=1)
def regions():
    out = []
    for rid, name, ids in _REGIONS:
        zs = [zone_by_id(i) for i in ids]
        out.append({
            "id": rid, "name": name, "zone_ids": ids,
            "borough": zs[0]["borough"],
            "lat": sum(z["lat"] for z in zs) / len(zs),
            "lon": sum(z["lon"] for z in zs) / len(zs),
            "airport": all(z["airport"] for z in zs),
        })
    return out


@lru_cache(maxsize=1)
def region_of_zone():
    return {zid: r["id"] for r in regions() for zid in r["zone_ids"]}


def region_by_id(rid):
    return next(r for r in regions() if r["id"] == rid)


# ---------------------------------------------------------------------------
# Bulk point -> zone assignment (for build-time aggregation of many points)
# ---------------------------------------------------------------------------
def _bbox(geom):
    pts = []
    polys = [geom["coordinates"]] if geom["type"] == "Polygon" else geom["coordinates"]
    for poly in polys:
        for ring in poly[:1]:
            pts.extend(ring)
    xs, ys = [p[0] for p in pts], [p[1] for p in pts]
    return min(xs), min(ys), max(xs), max(ys)


def assign_points(points, max_fallback_miles=0.6):
    """points: iterable of (lat, lon). Returns a list of zone ids (or None).
    Uses polygons with a bounding-box prefilter when they exist, else the
    nearest tracked centroid within max_fallback_miles."""
    polys = load_polygons()
    boxes = [(lid, _bbox(g), g) for lid, g in polys.items()]
    zs = zones()
    out = []
    for lat, lon in points:
        if lat is None or lon is None:
            out.append(None)
            continue
        hit = None
        for lid, (x0, y0, x1, y1), g in boxes:
            if x0 <= lon <= x1 and y0 <= lat <= y1 and point_in_geometry(lon, lat, g):
                hit = lid
                break
        if hit is None and not boxes:
            best = min(zs, key=lambda z: (z["lat"] - lat) ** 2 + ((z["lon"] - lon) * 0.76) ** 2)
            if haversine_miles(lat, lon, best["lat"], best["lon"]) <= max_fallback_miles:
                hit = best["id"]
        out.append(hit)
    return out
