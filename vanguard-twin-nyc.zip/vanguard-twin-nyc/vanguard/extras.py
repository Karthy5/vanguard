"""
Build-time public data that changes slowly: aggregated once, served from
data/extras.json by the signals API.

    python -m vanguard.extras            # after `python -m vanguard.build` (uses its zone polygons)

Sections (each one is independent; a failure is recorded and the rest still build):

  precincts   police precinct of each tracked zone (to place permitted events and tickets)
  subway      station -> zone, route -> zones, stop -> zone (to place MTA alerts)
  ridership   average subway entries per zone x weekday x hour (MTA hourly ridership)
  crashes     injury crashes and cyclist injuries per zone x 4-hour block, last 12 months
  tickets     parking tickets per day per precinct x hour, last 90 days of data
  curb        FHV relief stands and commercial loading-zone signs per zone (DOT signs)

Every number here is aggregated from public records. Nothing is learned or assumed.
"""

import json
import sys
import time
from collections import defaultdict
from datetime import datetime, timedelta

from . import config, socrata
from .stateplane import to_latlon
from .zones import assign_points, point_in_geometry, zone_ids, zones

BLOCKS = [(0, 4), (4, 8), (8, 12), (12, 16), (16, 20), (20, 24)]


def log(msg):
    print(f"[extras {datetime.now():%H:%M:%S}] {msg}", flush=True)


def block_of(hour):
    return f"{(hour // 4) * 4:02d}-{(hour // 4) * 4 + 4:02d}"


def parse_ticket_hour(t):
    """'0840A' -> 8, '1230P' -> 12, '0105P' -> 13. None if unparseable."""
    t = (t or "").strip().upper()
    if len(t) != 5 or not t[:4].isdigit() or t[4] not in "AP":
        return None
    h = int(t[:2])
    if h > 12:
        return None
    if t[4] == "A":
        return 0 if h == 12 else h
    return 12 if h == 12 else h + 12


def soql_dow_to_python(dow):
    """SoQL date_extract_dow: 0 = Sunday. Python weekday(): 0 = Monday."""
    return (int(dow) + 6) % 7


def parse_precincts(value):
    """'14, 18,' -> [14, 18]."""
    out = []
    for part in str(value or "").replace(";", ",").split(","):
        part = part.strip()
        if part.isdigit():
            out.append(int(part))
    return out


# ---------------------------------------------------------------------------
# Aggregations (pure functions; tested offline)
# ---------------------------------------------------------------------------
def zones_by_precinct(precinct_rows):
    """precinct_rows: [{'precinct': '14', 'the_geom': {...}}] -> ({zone: precinct}, {precinct: [zones]})"""
    zone_pct = {}
    for z in zones():
        for row in precinct_rows:
            geom = row.get("the_geom")
            if geom and point_in_geometry(z["lon"], z["lat"], geom):
                zone_pct[z["id"]] = int(float(row["precinct"]))
                break
    pct_zones = defaultdict(list)
    for zid, p in zone_pct.items():
        pct_zones[p].append(zid)
    return zone_pct, {str(k): v for k, v in pct_zones.items()}


def subway_maps(station_rows):
    pts = [(_f(r.get("gtfs_latitude")), _f(r.get("gtfs_longitude"))) for r in station_rows]
    zs = assign_points(pts)
    stop_zone, complex_zone, route_zones = {}, {}, defaultdict(set)
    for r, zid in zip(station_rows, zs):
        if zid is None:
            continue
        if r.get("gtfs_stop_id"):
            stop_zone[str(r["gtfs_stop_id"])] = zid
        if r.get("complex_id") not in (None, ""):
            complex_zone[str(int(float(r["complex_id"])))] = zid
        for route in str(r.get("daytime_routes") or "").split():
            route_zones[route].add(zid)
    return {"stop_zone": stop_zone, "complex_zone": complex_zone,
            "route_zones": {k: sorted(v) for k, v in route_zones.items()}}


def ridership_by_zone(rows, complex_zone, weeks):
    """rows: [{'station_complex_id','dow','hr','riders'}] (SoQL dow) -> {zone: {'d-h': avg entries}}"""
    acc = defaultdict(float)
    for r in rows:
        zid = complex_zone.get(str(r.get("station_complex_id")))
        if zid is None:
            continue
        try:
            key = (zid, soql_dow_to_python(r["dow"]), int(r["hr"]))
            acc[key] += float(r["riders"])
        except (KeyError, TypeError, ValueError):
            continue
    out = defaultdict(dict)
    for (zid, d, h), v in acc.items():
        out[str(zid)][f"{d}-{h}"] = round(v / max(weeks, 1), 1)
    return dict(out)


def crashes_by_zone(rows, days):
    pts = [(_f(r.get("latitude")), _f(r.get("longitude"))) for r in rows]
    zs = assign_points(pts)
    out = defaultdict(lambda: {"injury_crashes": defaultdict(float), "cyclist_injuries": defaultdict(float)})
    scale = 365 / max(days, 1)
    for r, zid in zip(rows, zs):
        if zid is None:
            continue
        try:
            hour = int(str(r.get("crash_time", "")).split(":")[0])
        except ValueError:
            continue
        b = block_of(hour)
        out[str(zid)]["injury_crashes"][b] += scale
        out[str(zid)]["cyclist_injuries"][b] += (_f(r.get("number_of_cyclist_injured")) or 0) * scale
    return {z: {k: {b: round(v, 1) for b, v in d.items()} for k, d in v.items()} for z, v in out.items()}


def tickets_by_precinct(rows, days):
    """rows: [{'violation_precinct','violation_time','n'}] -> {precinct: {hour: tickets per day}}"""
    acc = defaultdict(float)
    for r in rows:
        h = parse_ticket_hour(r.get("violation_time"))
        try:
            p = int(float(r.get("violation_precinct")))
        except (TypeError, ValueError):
            continue
        if h is None or p <= 0:
            continue
        acc[(p, h)] += _f(r.get("n")) or 0
    out = defaultdict(dict)
    for (p, h), v in acc.items():
        out[str(p)][str(h)] = round(v / max(days, 1), 2)
    return dict(out)


def curb_by_zone(relief_rows, loading_rows):
    def located(rows):
        pts, keep = [], []
        for r in rows:
            ll = to_latlon(r.get("sign_x_coord"), r.get("sign_y_coord"))
            if ll:
                pts.append(ll)
                keep.append((r, ll))
        return keep, assign_points(pts)

    out = defaultdict(lambda: {"relief_stands": [], "loading_zone_blocks": 0})
    rel, rz = located(relief_rows)
    seen = set()
    for (r, (lat, lon)), zid in zip(rel, rz):
        if zid is None or r.get("order_number") in seen:
            continue
        seen.add(r.get("order_number"))
        out[str(zid)]["relief_stands"].append({
            "on_street": r.get("on_street"), "from_street": r.get("from_street"), "to_street": r.get("to_street"),
            "side": r.get("side_of_street"), "lat": round(lat, 6), "lon": round(lon, 6),
            "sign": r.get("sign_description"),
        })
    load, lz = located(loading_rows)
    blocks = defaultdict(set)
    for (r, _), zid in zip(load, lz):
        if zid is not None:
            blocks[str(zid)].add(r.get("order_number"))
    for zid, orders in blocks.items():
        out[zid]["loading_zone_blocks"] = len(orders)
    return dict(out)


def _f(v):
    """float or None."""
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


# ---------------------------------------------------------------------------
# Fetching
# ---------------------------------------------------------------------------
def _max_date(domain, ds, field, where=None):
    v = socrata.latest(domain, ds, field, where)
    if not v:
        raise RuntimeError(f"{ds}: no {field} values")
    return datetime.fromisoformat(v[:19])


def _windows(end, days, step_days):
    """[(start, stop)] covering `days` before `end`, newest first, `step_days` each."""
    out, stop = [], end
    start_all = end - timedelta(days=days)
    while stop > start_all:
        start = max(start_all, stop - timedelta(days=step_days))
        out.append((start, stop))
        stop = start
    return out


def _ts(dt):
    return dt.strftime("%Y-%m-%dT%H:%M:%S")


def _like_any(field, patterns):
    return " OR ".join(f"upper({field}) like '{p}'" for p in patterns)


def fetch_all():
    sections, status = {}, {}

    def run(name, fn):
        t0 = time.time()
        log(f"{name}: fetching ...")
        try:
            sections[name] = fn()
            status[name] = {"status": "ok", "seconds": round(time.time() - t0, 1)}
            log(f"{name}: ok ({status[name]['seconds']}s)")
        except Exception as exc:  # noqa: BLE001 - one bad source must not stop the rest
            status[name] = {"status": "failed", "error": f"{exc.__class__.__name__}: {str(exc)[:200]}"}
            log(f"{name}: FAILED {status[name]['error']}")

    def precincts():
        rows = socrata.get(socrata.NYC, config.DS_PRECINCTS, {"$limit": 200})
        zone_pct, pct_zones = zones_by_precinct(rows)
        return {"zone_precinct": {str(k): v for k, v in zone_pct.items()}, "precinct_zones": pct_zones}

    def subway():
        rows = socrata.get(socrata.NYS, config.DS_SUBWAY_STATIONS, {"$limit": 2000})
        return subway_maps(rows)

    def ridership():
        cz = (sections.get("subway") or {}).get("complex_zone") or {}
        if not cz:
            raise RuntimeError("needs the subway section")
        latest = _max_date(socrata.NYS, config.DS_SUBWAY_RIDERSHIP, "transit_timestamp")
        ids = ",".join(f"'{c}'" for c in sorted(cz))
        rows = []
        # One week per request: a single 8-week GROUP BY times out on the server
        for i, (a, b) in enumerate(_windows(latest + timedelta(hours=1), 7 * config.EXTRAS_SUBWAY_WEEKS, 7), 1):
            chunk = socrata.get_all(socrata.NYS, config.DS_SUBWAY_RIDERSHIP, {
                "$select": "station_complex_id, date_extract_dow(transit_timestamp) AS dow, "
                           "date_extract_hh(transit_timestamp) AS hr, sum(ridership) AS riders",
                "$where": f"transit_timestamp >= '{_ts(a)}' AND transit_timestamp < '{_ts(b)}' "
                          f"AND station_complex_id in ({ids})",
                "$group": "station_complex_id, dow, hr", "$order": "station_complex_id, dow, hr",
            }, timeout=180)
            rows.extend(chunk)
            log(f"ridership: week {i}/{config.EXTRAS_SUBWAY_WEEKS} ({len(chunk):,} rows)")
        return {"weeks": config.EXTRAS_SUBWAY_WEEKS, "through": latest.isoformat(timespec="minutes"),
                "zones": ridership_by_zone(rows, cz, config.EXTRAS_SUBWAY_WEEKS)}

    def crashes():
        latest = _max_date(socrata.NYC, config.DS_COLLISIONS, "crash_date")
        rows = []
        for a, b in _windows(latest + timedelta(days=1), config.EXTRAS_CRASH_DAYS, 92):
            rows.extend(socrata.get_all(socrata.NYC, config.DS_COLLISIONS, {
                "$select": "crash_time, latitude, longitude, number_of_cyclist_injured",
                "$where": f"crash_date >= '{_ts(a)}' AND crash_date < '{_ts(b)}' "
                          "AND number_of_persons_injured > 0 AND latitude IS NOT NULL",
                "$order": "collision_id",
            }, timeout=180))
            log(f"crashes: through {a:%Y-%m-%d} ({len(rows):,} rows)")
        return {"days": config.EXTRAS_CRASH_DAYS, "through": latest.date().isoformat(),
                "zones": crashes_by_zone(rows, config.EXTRAS_CRASH_DAYS)}

    def tickets():
        today = datetime.now().strftime("%Y-%m-%dT00:00:00")
        latest = _max_date(socrata.NYC, config.DS_PARKING_VIOLATIONS, "issue_date", f"issue_date <= '{today}'")
        rows = []
        # 10 days per request: the dataset holds millions of tickets
        for a, b in _windows(latest + timedelta(days=1), config.EXTRAS_TICKET_DAYS, 10):
            rows.extend(socrata.get_all(socrata.NYC, config.DS_PARKING_VIOLATIONS, {
                "$select": "violation_precinct, violation_time, count(*) AS n",
                "$where": f"issue_date >= '{_ts(a)}' AND issue_date < '{_ts(b)}'",
                "$group": "violation_precinct, violation_time", "$order": "violation_precinct, violation_time",
            }, timeout=180))
            log(f"tickets: through {a:%Y-%m-%d} ({len(rows):,} rows)")
        return {"dataset": config.DS_PARKING_VIOLATIONS, "days": config.EXTRAS_TICKET_DAYS,
                "through": latest.date().isoformat(), "precincts": tickets_by_precinct(rows, config.EXTRAS_TICKET_DAYS)}

    def curb():
        cols = "order_number, on_street, from_street, to_street, side_of_street, sign_description, sign_x_coord, sign_y_coord"
        relief = socrata.get_all(socrata.NYC, config.DS_PARKING_SIGNS, {
            "$select": cols, "$where": _like_any("sign_description", config.RELIEF_STAND_PATTERNS),
            "$order": "order_number"})
        loading = socrata.get_all(socrata.NYC, config.DS_PARKING_SIGNS, {
            "$select": cols, "$where": _like_any("sign_description", config.LOADING_PATTERNS),
            "$order": "order_number"}, timeout=180)
        return {"relief_sign_rows": len(relief), "loading_sign_rows": len(loading),
                "zones": curb_by_zone(relief, loading)}

    for name, fn in [("precincts", precincts), ("subway", subway), ("ridership", ridership),
                     ("crashes", crashes), ("tickets", tickets), ("curb", curb)]:
        run(name, fn)
    return sections, status


def main():
    config.DATA_DIR.mkdir(exist_ok=True)
    if not config.ZONES_GEOJSON_PATH.exists():
        log("no zone polygons yet: points are matched to the nearest zone centroid. "
            "Run `python -m vanguard.build` first for exact polygons.")
    sections, status = fetch_all()
    payload = {"meta": {"generated_at": datetime.now().isoformat(timespec="seconds"),
                        "tracked_zones": len(zone_ids()), "sections": status}, **sections}
    config.EXTRAS_PATH.write_text(json.dumps(payload))
    ok = sum(1 for s in status.values() if s["status"] == "ok")
    log(f"wrote {config.EXTRAS_PATH} ({ok}/{len(status)} sections ok)")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
