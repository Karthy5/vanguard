"""
Scoring and shift planning.

For each zone and hour the model estimates logged-in earnings per hour:

    est $/hr = pay per engaged hour  x  utilization

  pay per engaged hour   learned from TLC trip records (zone x weekday x hour),
                         plus a weather adjustment learned by regression
  utilization            ASSUMPTION: base rate scaled by relative demand
                         (seasonal trips x weather effect x event prior)

The planner runs an exact dynamic program (Viterbi) over zones x hours.
It accounts for the commute in, moves between zones, tolls and operating cost.
"""

import json
import math
from datetime import datetime, timedelta

from . import config
from .feeds import nearest_speed
from .zones import haversine_miles, region_by_id, region_of_zone, regions, zone_by_id, zones

FEATURE_NAMES = ["intercept", "precip_mm", "rain_flag", "precip_x_manhattan", "precip_x_airport",
                 "cold_deg_below_45F", "hot_deg_above_82F"]

# Placeholder coefficients for when no build has been run. The UI flags them.
PRIOR_COEFS = {
    "demand": [0.0, 0.04, 0.05, 0.0, -0.02, 0.004, 0.003],
    "pay": [0.0, 0.8, 0.0, 0.0, 0.0, 0.0, 0.0],
}
PRIOR_HOUR_SHAPE = [0.55, 0.42, 0.32, 0.26, 0.28, 0.38, 0.62, 0.86, 0.95, 0.85, 0.78, 0.80,
                    0.84, 0.84, 0.88, 0.95, 1.00, 1.05, 1.08, 1.05, 1.00, 0.98, 0.92, 0.75]
PRIOR_DOW_SHAPE = [0.92, 0.95, 0.98, 1.02, 1.12, 1.15, 0.95]


# ---------------------------------------------------------------------------
# Calibration loading
# ---------------------------------------------------------------------------
class Calibration:
    def __init__(self):
        self._mtimes = None
        self.reload()

    def _stamp(self):
        return tuple(p.stat().st_mtime if p.exists() else None
                     for p in (config.BASELINE_PATH, config.BACKTEST_PATH))

    def reload(self):
        self._mtimes = self._stamp()
        self.baseline = json.loads(config.BASELINE_PATH.read_text()) if config.BASELINE_PATH.exists() else None
        self.backtest = json.loads(config.BACKTEST_PATH.read_text()) if config.BACKTEST_PATH.exists() else None
        self.calibrated = bool(self.baseline and self.backtest)
        if self.calibrated:
            ff = self.backtest["final_fit"]
            self.coefs = {k: [c["beta"] for c in ff[k]["coefs"]] for k in ("demand", "pay")}
        else:
            self.coefs = PRIOR_COEFS

    def maybe_reload(self):
        if self._stamp() != self._mtimes:
            self.reload()

    def slot(self, zone, dow, hr):
        if self.calibrated:
            row = self.baseline["zones"].get(str(zone["id"]), {}).get(f"{dow}-{hr}")
            if row and row[2] is not None:
                tm, mu, pr, p25, p75, n = row
                return {"trips": tm, "pay_rate": pr, "p25": p25 or pr * 0.85, "p75": p75 or pr * 1.15, "n": n}
            return None
        scale = 260 if zone["airport"] else (110 if zone["borough"] == "Manhattan" else 35)
        trips = scale * PRIOR_HOUR_SHAPE[hr] * PRIOR_DOW_SHAPE[dow]
        pr = 68.0 if zone["airport"] else (60.0 if zone["borough"] == "Manhattan" else 56.0)
        return {"trips": trips, "pay_rate": pr, "p25": pr * 0.85, "p75": pr * 1.15, "n": 0}

    def status(self):
        if not self.calibrated:
            return {"mode": "priors",
                    "message": "Placeholder priors, not calibrated. Run `python -m vanguard.build` to fit on real TLC data."}
        m = self.baseline["meta"]
        return {"mode": "calibrated", "months": m["months"], "trips": m.get("trips"),
                "message": f"Calibrated on {m.get('trips', 0):,} TLC HVFHV trips ({', '.join(m['months'])})"}


CAL = Calibration()


# ---------------------------------------------------------------------------
# Per-hour estimate
# ---------------------------------------------------------------------------
def _features(zone, precip, temp):
    p = min(max(precip or 0.0, 0.0), 10.0)
    t = temp if temp is not None else 60.0
    return [1.0, p, 1.0 if p >= 0.2 else 0.0,
            p if zone["borough"] == "Manhattan" else 0.0,
            p if zone["airport"] else 0.0,
            max(0.0, 45 - t), max(0.0, t - 82)]


def _dot(a, b):
    return sum(x * y for x, y in zip(a, b))


def _clock(dt):
    """6:30pm / 7pm. Built by hand: Windows strftime has no no-padding hour code."""
    h = dt.hour % 12 or 12
    ap = "am" if dt.hour < 12 else "pm"
    return f"{h}:{dt.minute:02d}{ap}" if dt.minute else f"{h}{ap}"


def _event_lift(zone_id, when, events):
    lift, why = 0.0, None
    for e in events:
        if e["zone_id"] != zone_id:
            continue
        start, end = datetime.fromisoformat(e["start"]), datetime.fromisoformat(e["est_end"])
        mid = when + timedelta(minutes=30)
        size = config.EVENT_EGRESS_MAX_DEMAND_LIFT * min(1.0, e["capacity_est"] / config.EVENT_FULL_EFFECT_CAPACITY)
        if end - timedelta(minutes=30) <= mid <= end + timedelta(minutes=75):
            val, tag = size, f"{e['venue']} lets out ~{_clock(end)}"
        elif start - timedelta(minutes=90) <= mid <= start:
            val, tag = size * 0.4, f"{e['venue']} arrivals before {_clock(start)}"
        else:
            continue
        if val > lift:
            lift, why = val, tag
    return lift, why


def _weather_at(wx, when):
    hourly = (wx or {}).get("hourly") or {}
    h = hourly.get(when.strftime("%Y-%m-%dT%H"))
    if h:
        return h["precip_mm"], h["temp_f"]
    return (wx or {}).get("precip_mm", 0.0) or 0.0, (wx or {}).get("temp_f")


def hour_estimates(when, live, layers):
    """Estimate every zone for one clock hour. Returns {zone_id: estimate}."""
    dow, hr = when.weekday(), when.hour
    precip, temp = _weather_at(live.get("weather"), when)
    events = (live.get("events") or {}).get("events", []) if layers["events"] else []

    slots = {z["id"]: CAL.slot(z, dow, hr) for z in zones()}
    trips = sorted(s["trips"] for s in slots.values() if s)
    median_trips = trips[len(trips) // 2] if trips else 1.0

    out = {}
    for z in zones():
        s = slots[z["id"]]
        if not s:
            continue
        x = _features(z, precip, temp)
        dem_mult = math.exp(_dot(x, CAL.coefs["demand"])) if layers["weather"] else 1.0
        pay_adj = _dot(x, CAL.coefs["pay"]) if layers["weather"] else 0.0
        ev, ev_why = _event_lift(z["id"], when, events)

        demand = s["trips"] * dem_mult * (1 + ev)
        surge = 1 + ev / config.EVENT_EGRESS_MAX_DEMAND_LIFT * config.EVENT_EGRESS_MAX_PAY_LIFT if ev else 1.0
        rel = max(demand, 0.1) / max(median_trips, 0.1)
        util = config.ASSUMED_BASE_UTILIZATION * rel ** config.UTILIZATION_DEMAND_ELASTICITY
        if z["airport"]:
            util *= config.AIRPORT_QUEUE_UTILIZATION_FACTOR
        util = min(config.UTILIZATION_CEIL, max(config.UTILIZATION_FLOOR, util))

        rate = max(0.0, s["pay_rate"] + pay_adj) * surge
        out[z["id"]] = {
            "est": rate * util,
            "lo": max(0.0, (s["p25"] + pay_adj) * surge * util),
            "hi": max(0.0, (s["p75"] + pay_adj) * surge * util),
            "pay_per_engaged_hr": rate,
            "utilization": util,
            "expected_trips": demand,
            # Display only: weather effect vs. a dry, mild hour (intercept excluded)
            "weather_demand_pct": (math.exp(_dot(x[1:], CAL.coefs["demand"][1:])) - 1) * 100
            if layers["weather"] else 0.0,
            "event_lift_pct": ev * 100,
            "event_why": ev_why,
            "precip_mm": precip,
            "n_weeks": s["n"],
        }
    return out


# ---------------------------------------------------------------------------
# Travel
# ---------------------------------------------------------------------------
def travel(a, b, hour, traffic, enabled=True):
    """a, b: dicts with lat, lon, borough. Returns minutes, cost, label."""
    if not enabled:
        return {"minutes": 0.0, "cost": 0.0, "toll": 0.0, "miles": 0.0, "crossing": None}
    miles = haversine_miles(a["lat"], a["lon"], b["lat"], b["lon"]) * config.ROAD_DETOUR_FACTOR
    sa, sb = nearest_speed(traffic, a["borough"]), nearest_speed(traffic, b["borough"])
    speed = 2 / (1 / sa + 1 / sb)
    minutes = miles / max(speed, 4.0) * 60
    peak = "peak" if hour in config.PEAK_HOURS else "offpeak"
    toll, crossing = 0.0, None
    if a["borough"] == "New Jersey" and b["borough"] != "New Jersey":
        minutes += config.HUDSON_CROSSING_DELAY_MIN[peak]
        toll = config.HUDSON_TOLL_USD
        crossing = "Hudson crossing"
    elif a["borough"] != b["borough"] and "Manhattan" in (a["borough"], b["borough"]):
        other = b["borough"] if a["borough"] == "Manhattan" else a["borough"]
        if other in ("Brooklyn", "Queens"):
            minutes += config.EAST_RIVER_CROSSING_DELAY_MIN[peak]
            crossing = "East River crossing"
        elif other == "Bronx":
            minutes += config.EAST_RIVER_CROSSING_DELAY_MIN[peak] * 0.5
            crossing = "Harlem River crossing"
    cost = miles * config.OPERATING_COST_PER_MILE + toll + config.CRZ_DRIVER_COST_FHV
    return {"minutes": minutes, "cost": cost, "toll": toll, "miles": miles, "crossing": crossing}


# ---------------------------------------------------------------------------
# Ranking and planning
# ---------------------------------------------------------------------------
def _reasons(e, tr, zone):
    r = []
    if e["event_why"]:
        r.append(f"{e['event_why']} (+{e['event_lift_pct']:.0f}% demand, prior)")
    if abs(e["weather_demand_pct"]) >= 2:
        sign = "+" if e["weather_demand_pct"] > 0 else ""
        r.append(f"Weather {sign}{e['weather_demand_pct']:.0f}% trips vs. a dry hour")
    r.append(f"${e['pay_per_engaged_hr']:.0f} per engaged hr, ~{e['utilization'] * 100:.0f}% busy (assumed)")
    if tr["crossing"]:
        r.append(f"{tr['crossing']}: {tr['minutes']:.0f} min, ${tr['cost']:.2f} incl. ${tr['toll']:.2f} toll"
                 if tr["toll"] else f"{tr['crossing']}: {tr['minutes']:.0f} min in")
    if zone["airport"]:
        r.append("Airport queue: utilization discounted")
    return r


def _start_time(start_hour):
    now = datetime.now().replace(minute=0, second=0, microsecond=0)
    start = now.replace(hour=start_hour)
    if start < now - timedelta(hours=1):
        start += timedelta(days=1)
    return start


def borough_for_point(lat, lon):
    """Rough borough for a GPS fix: west of the Hudson counts as New Jersey,
    otherwise the borough of the nearest tracked zone."""
    hudson_lon = -74.02 if lat < 40.75 else (-74.00 if lat < 40.80 else -73.96)
    if lon < hudson_lon:
        return "New Jersey"
    z = min(zones(), key=lambda z: haversine_miles(lat, lon, z["lat"], z["lon"]))
    return z["borough"]


# ---------------------------------------------------------------------------
# Trip flows between regions (TLC pickup -> dropoff shares)
# ---------------------------------------------------------------------------
def _prior_flows(ra):
    """Gravity prior when no build has run: nearby, busy regions get more trips."""
    a = region_by_id(ra)
    w = {}
    for b in regions():
        d = haversine_miles(a["lat"], a["lon"], b["lat"], b["lon"])
        mass = len(b["zone_ids"]) * (3 if b["borough"] == "Manhattan" else 1)
        w[b["id"]] = mass * math.exp(-d / 2.5)
    if a["airport"]:
        w[ra] = 0.02 * sum(w.values())
    tot = sum(w.values())
    return {k: 0.85 * v / tot for k, v in w.items()} | {"other": 0.15}


def flows_from(ra, hour):
    if CAL.calibrated:
        f = CAL.baseline.get("flows", {})
        bh = CAL.baseline.get("flow_bucket_hours", 4)
        got = f.get(str(hour // bh), {}).get(ra)
        if got:
            return got
    return _prior_flows(ra)


def paid_share(ra, rb, hour):
    """Share of a move from region ra to rb that can be done on paid trips."""
    if ra is None:
        return 0.0
    flow = flows_from(ra, hour).get(rb, 0.0)
    return min(config.REPOSITION_PAID_MAX, config.REPOSITION_PAID_MIN + config.REPOSITION_FLOW_SLOPE * flow)


def _origin_region(origin):
    if origin["borough"] == "New Jersey":
        return None   # NYC TLC trips don't start in NJ: the drive in is unpaid
    r = min(regions(), key=lambda r: haversine_miles(origin["lat"], origin["lon"], r["lat"], r["lon"]))
    near = haversine_miles(origin["lat"], origin["lon"], r["lat"], r["lon"]) <= config.ORIGIN_REGION_MAX_MILES
    return r["id"] if near else None


def _move(a_pt, b_pt, ra, rb, hour, traffic, enabled):
    """Travel from a to b, with the paid share of the move taken out of the cost."""
    tr = travel(a_pt, b_pt, hour, traffic, enabled)
    if not enabled:
        return {**tr, "paid_share": 0.0, "unpaid_minutes": 0.0}
    ps = paid_share(ra, rb, hour) if ra != rb else 1.0
    unpaid = tr["minutes"] * (1 - ps)
    cost = (tr["miles"] * config.OPERATING_COST_PER_MILE + tr["toll"]) * (1 - ps)
    return {**tr, "paid_share": ps, "unpaid_minutes": unpaid, "cost": cost}


# ---------------------------------------------------------------------------
# Ranking and planning
# ---------------------------------------------------------------------------
def _region_hour(region, est_t, hour):
    """Best staging zone in a region for one hour, discounted for trips that
    carry the driver out of the region (unpaid returns)."""
    zs = [est_t[z] | {"zone_id": z} for z in region["zone_ids"] if z in est_t]
    if not zs:
        return None
    best = max(zs, key=lambda e: e["est"])
    retention = flows_from(region["id"], hour).get(region["id"], 0.0)
    keep = 1 - config.LEAKAGE_COST * (1 - retention)
    ev = max(zs, key=lambda e: e["event_lift_pct"])
    return {**best, "est": best["est"] * keep, "lo": best["lo"] * keep, "hi": best["hi"] * keep,
            "retention": retention, "event_why": ev["event_why"], "event_lift_pct": ev["event_lift_pct"]}


def plan(origin_id, start_hour, shift_hours, layers, live, start_at=None, here=None):
    """start_at: exact shift start (datetime), used by the driver view so a plan
    stays pinned to today mid-shift. here: (lat, lon) from the driver's GPS."""
    CAL.maybe_reload()
    if here:
        lat, lon = here
        origin = {"label": "Your location", "lat": lat, "lon": lon, "borough": borough_for_point(lat, lon)}
        origin_id = "here"
    else:
        origin = config.ORIGINS.get(origin_id, config.ORIGINS["midtown"])
    traffic = live.get("traffic")
    on = layers["travel"]
    start = start_at.replace(minute=0, second=0, microsecond=0) if start_at else _start_time(start_hour)
    hours = [start + timedelta(hours=i) for i in range(shift_hours)]
    est = [hour_estimates(h, live, layers) for h in hours]
    origin_region = _origin_region(origin)

    # Zone heat map: stay-put value of each zone (used for the map colours)
    ranking = []
    for z in zones():
        if not all(z["id"] in e for e in est):
            continue
        tr = _move(origin, z, origin_region, region_of_zone()[z["id"]], start.hour, traffic, on)
        rem, gross = tr["unpaid_minutes"], 0.0
        for i in range(shift_hours):
            gross += est[i][z["id"]]["est"] * max(0.0, 1 - rem / 60)
            rem = max(0.0, rem - 60)
        e0 = est[0][z["id"]]
        ranking.append({"id": z["id"], "name": z["name"], "borough": z["borough"], "staging": z["staging"],
                        "lat": z["lat"], "lon": z["lon"], "airport": z["airport"],
                        "region": region_of_zone()[z["id"]],
                        "net_per_hr": (gross - tr["cost"]) / shift_hours,
                        "first_hour": e0, "commute": tr, "reasons": _reasons(e0, tr, z)})
    ranking.sort(key=lambda r: r["net_per_hr"], reverse=True)

    # Region values per hour
    regs = regions()
    rh = [[_region_hour(r, est[t], hours[t].hour) for r in regs] for t in range(shift_hours)]
    idx = [i for i in range(len(regs)) if all(rh[t][i] for t in range(shift_hours))]
    stage = lambda t, i: zone_by_id(rh[t][i]["zone_id"])  # noqa: E731

    commute = {i: _move(origin, stage(0, i), origin_region, regs[i]["id"], start.hour, traffic, on) for i in idx}

    def move(t, i, j):
        if i == j:
            return {"minutes": 0.0, "unpaid_minutes": 0.0, "cost": 0.0, "toll": 0.0, "miles": 0.0,
                    "crossing": None, "paid_share": 1.0}
        return _move(stage(t - 1, i), stage(t, j), regs[i]["id"], regs[j]["id"], hours[t].hour, traffic, on)

    # Viterbi over regions x hours
    V = [{} for _ in range(shift_hours)]
    back = [{} for _ in range(shift_hours)]
    for j in idx:
        V[0][j] = rh[0][j]["est"] * max(0.0, 1 - commute[j]["unpaid_minutes"] / 60) - commute[j]["cost"]
    for t in range(1, shift_hours):
        for j in idx:
            best, arg = -1e9, None
            for i in idx:
                spill = max(0.0, commute[i]["unpaid_minutes"] - 60) / 60 if t == 1 else 0.0
                m = move(t, i, j)
                val = V[t - 1][i] + rh[t][j]["est"] * max(0.0, 1 - spill - m["unpaid_minutes"] / 60) - m["cost"]
                if val > best:
                    best, arg = val, i
            V[t][j], back[t][j] = best, arg
    j = max(idx, key=lambda k: V[-1][k])
    path = [j]
    for t in range(shift_hours - 1, 0, -1):
        j = back[t][j]
        path.append(j)
    path.reverse()

    # Region ranking (stay in one region all shift) for "other options"
    region_ranking = []
    for i in idx:
        tot, rem = -commute[i]["cost"], commute[i]["unpaid_minutes"]
        for t in range(shift_hours):
            tot += rh[t][i]["est"] * max(0.0, 1 - rem / 60)
            rem = max(0.0, rem - 60)
        z0 = stage(0, i)
        region_ranking.append({"id": regs[i]["id"], "name": regs[i]["name"], "net_per_hr": tot / shift_hours,
                               "staging_zone": z0["name"], "staging": z0["staging"], "lat": z0["lat"], "lon": z0["lon"],
                               "commute": commute[i], "retention": rh[0][i]["retention"],
                               "event_why": rh[0][i]["event_why"]})
    region_ranking.sort(key=lambda r: r["net_per_hr"], reverse=True)

    # Build blocks
    blocks, cum = [], 0.0
    for t, j in enumerate(path):
        r, e, z = regs[j], rh[t][j], stage(t, j)
        if t == 0:
            tr = commute[j]
            f = max(0.0, 1 - tr["unpaid_minutes"] / 60)
        else:
            tr = move(t, path[t - 1], j)
            spill = max(0.0, commute[path[0]]["unpaid_minutes"] - 60) / 60 if t == 1 else 0.0
            f = max(0.0, 1 - spill - tr["unpaid_minutes"] / 60)
        earned = e["est"] * f - tr["cost"]
        cum += earned
        hour_row = {"t": hours[t].isoformat(timespec="minutes"), "earned": earned, "cum": cum,
                    "lo": e["lo"] * f - tr["cost"], "hi": e["hi"] * f - tr["cost"],
                    "zone": z["name"], "staging": z["staging"], "lat": z["lat"], "lon": z["lon"],
                    "event_why": e["event_why"], "precip_mm": e["precip_mm"], "retention": e["retention"]}
        if blocks and blocks[-1]["region_id"] == r["id"]:
            b = blocks[-1]
            b["end"] = (hours[t] + timedelta(hours=1)).isoformat(timespec="minutes")
            b["earned"] += earned
            b["hours"].append(hour_row)
        else:
            leave = hours[t] - timedelta(minutes=round(tr["minutes"])) if t > 0 else hours[t]
            blocks.append({
                "region_id": r["id"], "region": r["name"],
                "zone_id": z["id"], "zone": z["name"], "staging": z["staging"], "lat": z["lat"], "lon": z["lon"],
                "start": hours[t].isoformat(timespec="minutes"),
                "end": (hours[t] + timedelta(hours=1)).isoformat(timespec="minutes"),
                "earned": earned, "hours": [hour_row],
                "arrive": {"minutes": tr["minutes"], "unpaid_minutes": tr["unpaid_minutes"],
                           "paid_share": tr["paid_share"], "cost": tr["cost"], "crossing": tr["crossing"],
                           "leave_at": leave.isoformat(timespec="minutes"),
                           "from": origin["label"] if t == 0 else blocks[-1]["region"],
                           "how": _how(t, tr, r, z, origin)}})
    for b in blocks:
        b["why"] = _block_why(b)

    stay_best = region_ranking[0]["net_per_hr"] * shift_hours if region_ranking else 0.0
    return {
        "start": start.isoformat(timespec="minutes"),
        "origin": {**origin, "id": origin_id, "region": origin_region},
        "shift_hours": shift_hours, "layers": layers,
        "ranking": ranking,
        "regions": region_ranking,
        "plan": {"blocks": blocks, "total": cum, "per_hr": cum / shift_hours,
                 "band": [sum(h["lo"] for b in blocks for h in b["hours"]) / shift_hours,
                          sum(h["hi"] for b in blocks for h in b["hours"]) / shift_hours],
                 "stay_put_best": stay_best},
        "calibration": CAL.status(),
        "assumptions": assumptions(),
    }


def _how(t, tr, region, zone, origin):
    if t == 0:
        if not tr["minutes"]:
            return "You're already here."
        if tr["paid_share"] >= 0.4:
            return (f"Go online now and accept trips heading toward {region['name']}; "
                    f"if none come, set your destination filter to {zone['staging']}.")
        via = f" via the {tr['crossing']}" if tr["crossing"] else ""
        return f"Drive in{via}, then go online near {zone['staging']}."
    if tr["paid_share"] >= 0.4:
        return (f"Accept trips heading to {region['name']} (about {tr['paid_share']:.0%} of this move "
                f"can be paid); if none come, set your destination filter to {zone['staging']}.")
    return f"Few trips go this way. Drive over and go online near {zone['staging']}."


def _block_why(b):
    why = []
    evs = [h["event_why"] for h in b["hours"] if h["event_why"]]
    if evs:
        why.append(evs[0])
    wet = sum(1 for h in b["hours"] if h["precip_mm"] >= 0.2)
    if wet:
        why.append(f"Rain {wet}h: more trip requests")
    ret = b["hours"][0]["retention"]
    why.append(f"{ret:.0%} of trips from here end in this area")
    return why


def assumptions():
    return [
        {"name": "Base utilization", "value": f"{config.ASSUMED_BASE_UTILIZATION:.0%}",
         "why": "Public data shows pay per engaged hour, not idle time. Partner data replaces this."},
        {"name": "Utilization vs. demand elasticity", "value": f"{config.UTILIZATION_DEMAND_ELASTICITY}",
         "why": "How much busier a driver gets when a zone has more trips. Unobserved without driver logs."},
        {"name": "Airport queue factor", "value": f"{config.AIRPORT_QUEUE_UTILIZATION_FACTOR:.0%}",
         "why": "Airport trips pay well but involve long lot waits."},
        {"name": "Event egress lift", "value": f"up to +{config.EVENT_EGRESS_MAX_DEMAND_LIFT:.0%}",
         "why": "No free historical event feed, so this is an unvalidated prior."},
        {"name": "Paid share of a move", "value": f"{config.REPOSITION_PAID_MIN:.0%}–{config.REPOSITION_PAID_MAX:.0%}",
         "why": "How much of a move to a new area is done on paid trips. Scaled by measured A→B trip flows; the scaling is assumed."},
        {"name": "Leakage cost", "value": f"{config.LEAKAGE_COST:.0%}",
         "why": "Earnings lost to unpaid returns in an area where every trip leaves. Partner GPS traces would measure it."},
        {"name": "Event surge on pay", "value": f"up to +{config.EVENT_EGRESS_MAX_PAY_LIFT:.0%}",
         "why": "Surge pricing around let-outs. Unvalidated prior."},
        {"name": "Operating cost", "value": f"${config.OPERATING_COST_PER_MILE:.2f}/mi",
         "why": "Fuel and wear, excluding depreciation and insurance."},
        {"name": "Hudson toll (eastbound)", "value": f"${config.HUDSON_TOLL_USD:.2f}",
         "why": "PANYNJ E-ZPass rate. Verify the current rate."},
    ]
