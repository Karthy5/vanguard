"use strict";

// ── helpers ───────────────────────────────────────────────────────────────
const $ = (s, el = document) => el.querySelector(s);
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const money = (x, d = 0) => (x < 0 ? "−$" : "$") + Math.abs(x).toFixed(d);
const clock = (iso) => {
  const d = new Date(iso);
  const h = d.getHours() % 12 || 12, m = d.getMinutes();
  return h + (m ? ":" + String(m).padStart(2, "0") : "") + (d.getHours() < 12 ? "am" : "pm");
};
const debounce = (fn, ms) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; };

// ── tabs ──────────────────────────────────────────────────────────────────
document.querySelectorAll("button.tab").forEach((b) => b.addEventListener("click", () => {
  document.querySelectorAll("button.tab").forEach((x) => x.classList.toggle("on", x === b));
  document.querySelectorAll(".view").forEach((v) => v.classList.toggle("on", v.id === "view-" + b.dataset.view));
  if (b.dataset.view === "model") loadModel();
  else if (map) setTimeout(() => map.resize(), 50);
}));

// ── map ───────────────────────────────────────────────────────────────────
const CARTO = "https://basemaps.cartocdn.com/gl/dark-matter-gl-style/style.json";
const BLANK = { version: 8, sources: {}, layers: [{ id: "bg", type: "background", paint: { "background-color": "#0b0d10" } }] };
let map = null, mapReady = false, zonesGeo = null, markers = [], lastPlan = null;

function initMap() {
  map = new maplibregl.Map({
    container: "map", style: CARTO, center: [-73.955, 40.735], zoom: 10.7,
    attributionControl: { compact: true }, dragRotate: false,
  });
  map.addControl(new maplibregl.NavigationControl({ showCompass: false }), "top-right");
  let loaded = false;
  map.on("load", () => { loaded = true; setupLayers(); });
  // If the basemap can't load (offline, blocked), keep going on a blank canvas
  setTimeout(() => {
    if (!loaded) { map.setStyle(BLANK); map.once("style.load", setupLayers); }
  }, 5000);
}

let settingUp = false;
async function setupLayers() {
  if (mapReady || settingUp || map.getSource("zones")) return;
  settingUp = true;
  zonesGeo = zonesGeo || await fetch("/api/zones").then((r) => r.json());
  map.addSource("zones", { type: "geojson", data: zonesGeo });
  map.addSource("route", { type: "geojson", data: { type: "FeatureCollection", features: [] } });
  if (zonesGeo.has_polygons) {
    map.addLayer({ id: "zone-fill", type: "fill", source: "zones", paint: { "fill-color": "#1a1d22", "fill-opacity": 0.72 } });
    map.addLayer({ id: "zone-line", type: "line", source: "zones", paint: { "line-color": "#0b0d10", "line-width": 1 } });
  } else {
    map.addLayer({ id: "zone-fill", type: "circle", source: "zones",
      paint: { "circle-color": "#1a1d22", "circle-radius": ["interpolate", ["linear"], ["zoom"], 10, 7, 13, 18], "circle-opacity": 0.9,
               "circle-stroke-color": "#0b0d10", "circle-stroke-width": 1 } });
  }
  map.addLayer({ id: "route", type: "line", source: "route",
    paint: { "line-color": "#e8eaed", "line-width": 1.5, "line-dasharray": [2, 2], "line-opacity": 0.8 } });
  map.on("click", "zone-fill", (e) => {
    const id = e.features[0].properties.id;
    const r = lastPlan && lastPlan.ranking.find((z) => z.id === id);
    if (r) new maplibregl.Popup({ closeButton: false }).setLngLat(e.lngLat)
      .setHTML(`<b>${esc(r.name)}</b><br>${money(r.net_per_hr)}/hr net · ${esc(r.staging)}`).addTo(map);
  });
  mapReady = true;
  if (lastPlan) paintMap(lastPlan);
}

function paintMap(p) {
  if (!mapReady) return;
  const vals = p.ranking.map((r) => r.net_per_hr);
  const lo = Math.min(...vals), hi = Math.max(...vals);
  const byId = Object.fromEntries(p.ranking.map((r) => [r.id, r.net_per_hr]));
  zonesGeo.features.forEach((f) => { f.properties.v = byId[f.properties.id] ?? null; });
  map.getSource("zones").setData(zonesGeo);
  const ramp = hi > lo
    ? ["interpolate", ["linear"], ["get", "v"], lo, "#1a2420", lo + (hi - lo) * 0.45, "#3d5a2e", lo + (hi - lo) * 0.8, "#8fb534", hi, "#d4ff3a"]
    : "#8fb534";
  const color = ["case", ["==", ["get", "v"], null], "#16191d", ramp];
  map.setPaintProperty("zone-fill", zonesGeo.has_polygons ? "fill-color" : "circle-color", color);
  $("#rampLo").textContent = money(lo);
  $("#rampHi").textContent = money(hi);

  const o = p.origin;
  const pts = [[o.lon, o.lat], ...p.plan.blocks.map((b) => [b.lon, b.lat])];
  map.getSource("route").setData({ type: "Feature", geometry: { type: "LineString", coordinates: pts } });

  markers.forEach((m) => m.remove());
  markers = [];
  const pin = document.createElement("div"); pin.className = "pin"; pin.title = o.label;
  markers.push(new maplibregl.Marker({ element: pin }).setLngLat([o.lon, o.lat]).addTo(map));
  p.plan.blocks.forEach((b, i) => {
    const el = document.createElement("div");
    el.className = "rank-tag" + (i ? " dim" : "");
    el.textContent = `${i + 1} · ${clock(b.start)}`;
    markers.push(new maplibregl.Marker({ element: el, anchor: "bottom", offset: [0, -6] }).setLngLat([b.lon, b.lat]).addTo(map));
  });
}

// ── plan ──────────────────────────────────────────────────────────────────
const form = $("#inputs");

function params() {
  const f = new FormData(form);
  const q = new URLSearchParams({
    origin: f.get("origin"), start: f.get("start"), hours: f.get("hours"),
  });
  ["weather", "events", "travel"].forEach((k) => q.set(k, form.elements[k].checked ? "1" : "0"));
  return q;
}

let reqId = 0;
async function refresh() {
  const id = ++reqId;
  try {
    const r = await fetch("/api/plan?" + params());
    const p = await r.json().catch(() => ({ error: `server returned ${r.status} (not JSON)` }));
    if (!r.ok || p.error) throw new Error(p.error || `server returned ${r.status}`);
    if (id !== reqId) return;
    lastPlan = p;
    render(p);
  } catch (e) {
    $("#go").innerHTML = `<div class="eyebrow">Error</div><div class="empty">The plan failed: ${esc(e.message)}. Details are in the terminal running app.py.</div>`;
  }
}
const refreshSoon = debounce(refresh, 200);
form.addEventListener("input", refreshSoon);
form.addEventListener("submit", (e) => e.preventDefault());

function whyClass(s) {
  if (/lets out|arrivals/.test(s)) return "ev";
  if (/^Weather/.test(s)) return "rn";
  return "";
}

function render(p) {
  renderFeeds(p.live, p.calibration);
  const first = p.plan.blocks[0];
  const top = p.ranking.find((r) => r.id === first.zone_id);
  const c = first.arrive;
  const why = [...first.why];
  if (top) why.push(top.reasons.find((r) => /per engaged hr/.test(r)));
  $("#go").innerHTML = `
    <div class="eyebrow">Work · ${clock(p.start)}</div>
    <div class="go-zone">${esc(first.region)}</div>
    <div class="go-stage">Stage at ${esc(first.staging)} <span class="muted">· ${esc(first.zone)}</span></div>
    <div class="go-money"><span class="num">${money(p.plan.per_hr)}</span><span class="per">/hr over the shift</span></div>
    <div class="go-band">likely ${money(p.plan.band[0])}–${money(p.plan.band[1])}/hr · 25th–75th pct of past weeks</div>
    <div class="go-commute">
      <span>From ${esc(p.origin.label)}</span>
      <span><b>${Math.round(c.minutes)} min</b>${c.cost ? " · " + money(c.cost, 2) : ""}</span>
    </div>
    <p class="go-how">${esc(c.how)}</p>
    <ul class="why">${why.filter(Boolean).slice(0, 4).map((r) => `<li class="${whyClass(r)}">${esc(r)}</li>`).join("")}</ul>`;

  // Goal + timeline
  const total = p.plan.total;
  $("#planTotal").textContent = money(total);
  $("#planMeta").textContent = `${p.shift_hours}h · ${p.plan.blocks.length} area${p.plan.blocks.length > 1 ? "s" : ""}`;
  $("#bandText").textContent = `likely ${money(p.plan.band[0] * p.shift_hours)}–${money(p.plan.band[1] * p.shift_hours)} for the shift`;
  const stayGain = total - p.plan.stay_put_best;
  const rows = [];
  p.plan.blocks.forEach((b, i) => {
    if (i > 0) {
      const a = b.arrive;
      rows.push(`<li class="tl move"><div class="tl-time">${clock(a.leave_at)}</div>
        <div><div class="tl-zone">Head to ${esc(b.region)}</div>
        <div class="tl-sub">${esc(a.how)}<br>${Math.round(a.minutes)} min · ~${Math.round(a.paid_share * 100)}% on paid trips${a.crossing ? " · " + esc(a.crossing) : ""}</div></div>
        <div class="tl-amt"><small>${a.cost ? money(-a.cost, 2) : ""}</small></div></li>`);
    }
    const notes = [...new Set(b.hours.map((h) => h.event_why).filter(Boolean))].map((s) => `<span class="ev">${esc(s)}</span>`);
    const wet = b.hours.filter((h) => h.precip_mm >= 0.2).length;
    if (wet) notes.push(`<span class="rn">rain ${wet}h</span>`);
    rows.push(`<li class="tl"><div class="tl-time">${clock(b.start)}<br>${clock(b.end)}</div>
      <div><div class="tl-zone">${esc(b.region)}</div><div class="tl-sub">stage at ${esc(b.staging)} · ${Math.round(b.hours[0].retention * 100)}% of trips stay in the area${notes.length ? "<br>" + notes.join(" · ") : ""}</div></div>
      <div class="tl-amt">${money(b.earned)}<small>${money(b.hours[b.hours.length - 1].cum)} total</small></div></li>`);
  });
  if (p.plan.blocks.length > 1 && stayGain > 1) {
    rows.push(`<li class="tl"><div></div><div class="tl-sub">Moving beats staying in the best single area by ${money(stayGain)}.</div><div></div></li>`);
  }
  $("#timeline").innerHTML = rows.join("");

  $("#alts").innerHTML = p.regions.slice(0, 8).map((r, i) => `
    <li class="alt" data-lon="${r.lon}" data-lat="${r.lat}">
      <span class="alt-rank">${String(i + 1).padStart(2, "0")}</span>
      <div><div class="alt-name">${esc(r.name)}</div><div class="alt-sub">stage ${esc(r.staging_zone)} · ${Math.round(r.commute.minutes)} min in${r.commute.toll ? " · toll" : ""}${r.event_why ? " · event" : ""}</div></div>
      <span class="alt-amt">${money(r.net_per_hr)}</span>
    </li>`).join("");
  document.querySelectorAll(".alt").forEach((el) => el.addEventListener("click", () => {
    if (map) map.flyTo({ center: [+el.dataset.lon, +el.dataset.lat], zoom: 13, duration: 700 });
  }));

  renderConditions(p);
  paintMap(p);
}

function renderFeeds(live, cal) {
  const s = (f) => (f && f.status) || "offline";
  const items = [["Weather", live.weather], ["DOT speeds", live.traffic], ["FAA", live.airports], ["Events", live.events]];
  $("#feeds").innerHTML = items.map(([n, f]) =>
    `<span class="feed ${s(f)}" title="${esc(f && (f.error || f.fetched_at) || "")}"><i></i>${n}</span>`).join("");
  const banner = $("#calBanner");
  if (cal.mode !== "calibrated") {
    banner.hidden = false;
    banner.innerHTML = `Running on placeholder priors. Run <code>python -m vanguard.build</code> to calibrate on real NYC TLC trip records.`;
  } else banner.hidden = true;
}

function renderConditions(p) {
  const w = p.live.weather, a = p.live.airports;
  const rows = [];
  if (w.status === "live" || w.status === "stale") {
    rows.push(`<div class="cond-row"><span>${esc(w.label)} · ${Math.round(w.temp_f)}°F</span><span class="muted">${w.precip_mm} mm/h now</span></div>`);
  } else rows.push(`<div class="empty">Weather feed offline. Model assumes dry.</div>`);

  // Precip over the shift
  const hrs = p.plan.blocks.flatMap((b) => b.hours);
  const maxP = Math.max(1, ...hrs.map((h) => h.precip_mm));
  rows.push(`<div><div class="precip">${hrs.map((h) =>
    `<div class="${h.precip_mm >= 0.2 ? "wet" : ""}" style="height:${Math.max(6, (h.precip_mm / maxP) * 100)}%" title="${clock(h.t)} · ${h.precip_mm} mm"></div>`).join("")}</div>
    <div class="precip-labels"><span>${clock(hrs[0].t)}</span><span>precip over shift</span><span>${clock(hrs[hrs.length - 1].t)}</span></div></div>`);

  const t = p.live.traffic;
  if (t.status === "live" || t.status === "stale") {
    const mn = t.median_mph && t.median_mph.Manhattan;
    rows.push(`<div class="cond-row"><span>Manhattan traffic</span><span class="mono">${mn ? mn + " mph" : "—"}</span></div>`);
  }
  if (a.status === "live" || a.status === "stale") {
    const d = a.delays || {};
    ["JFK", "LGA"].forEach((k) => rows.push(`<div class="cond-row"><span>${k}</span><span class="muted">${(d[k] || []).length ? esc(d[k][0]) : "no FAA programs"}</span></div>`));
  }
  $("#cond").innerHTML = rows.join("");

  const ev = p.live.events;
  if (ev.status === "disabled") {
    $("#evCount").textContent = "off";
    $("#events").innerHTML = `<li class="empty">Add a free Ticketmaster key to <code>.env</code> to turn on the event layer.</li>`;
  } else if (!ev.events || !ev.events.length) {
    $("#evCount").textContent = ev.status;
    $("#events").innerHTML = `<li class="empty">${ev.status === "offline" ? "Event feed offline." : "No large events in the next 20 hours."}</li>`;
  } else {
    $("#evCount").textContent = ev.events.length + " tracked";
    $("#events").innerHTML = ev.events.slice(0, 10).map((e) => `
      <li><div>${esc(e.name)}</div>
      <div class="ev-t">out ~${clock(e.est_end)} <span class="ev-v">· ${esc(e.venue)} · ${esc(e.zone_name)}</span></div></li>`).join("");
  }
}

// ── model view ────────────────────────────────────────────────────────────
let modelLoaded = false;
async function loadModel() {
  if (modelLoaded) return;
  const d = await fetch("/api/backtest").then((r) => r.json());
  modelLoaded = true;
  const body = $("#modelBody");
  const assumptions = `
    <section><div class="block-head" style="padding-left:0"><h2>Assumptions the public data can't pin down</h2></div>
    <table class="t"><thead><tr><th>Parameter</th><th>Value</th><th>Why it's an assumption</th></tr></thead><tbody>
    ${d.assumptions.map((a) => `<tr><td>${esc(a.name)}</td><td class="n">${esc(a.value)}</td><td style="color:var(--fg-2)">${esc(a.why)}</td></tr>`).join("")}
    </tbody></table></section>`;

  if (!d.backtest) {
    body.innerHTML = `
      <div class="lede"><h1>No backtest yet</h1>
      <p>The app is running on placeholder priors. Run <code class="mono">python -m vanguard.build</code>. It downloads NYC TLC High-Volume FHV trip records (every Uber and Lyft trip, with driver pay), joins hourly weather, holds out the last 14 days, and reports out-of-sample error here.</p></div>
      ${assumptions}`;
    return;
  }
  const bt = d.backtest, h = bt.holdout, dm = h.demand, pay = h.pay, m = bt.meta;
  const pctCls = (x) => (x == null ? "" : x > 0 ? "good" : "bad");
  const fmtPct = (x) => (x == null ? "—" : Math.abs(x) < 0.05 ? "0.0%" : (x > 0 ? "−" : "+") + Math.abs(x).toFixed(1) + "%");

  body.innerHTML = `
    <div class="lede">
      <h1>Does weather improve the forecast? Out-of-sample check.</h1>
      <p>Fit on ${esc(m.start.slice(0, 10))} to ${esc(m.cutoff.slice(0, 10))} and scored on the following ${m.holdout_days} days, which the model never saw.
      ${Number(m.trips).toLocaleString()} real TLC high-volume FHV trips across ${esc(m.months.join(", "))}.
      The baseline is the zone × weekday × hour average. "With weather" adds the regression below.</p>
    </div>
    <div class="stats">
      <div class="stat"><div class="k">Trips per zone-hour · MAE</div><div class="v">${dm.mae_trips_baseline.toFixed(2)} → ${dm.mae_trips_with_weather.toFixed(2)}</div><div class="s">all ${h.holdout_zone_hours.toLocaleString()} holdout zone-hours</div></div>
      <div class="stat"><div class="k">Error change, all hours</div><div class="v ${pctCls(dm.error_reduction_pct)}">${fmtPct(dm.error_reduction_pct)}</div><div class="s">negative = weather helped</div></div>
      <div class="stat"><div class="k">Error change, rain hours</div><div class="v ${pctCls(dm.rain_error_reduction_pct)}">${fmtPct(dm.rain_error_reduction_pct)}</div><div class="s">${h.holdout_rain_zone_hours.toLocaleString()} zone-hours ≥ ${m.rain_threshold_mm} mm</div></div>
      <div class="stat"><div class="k">Pay per engaged hr · wMAE</div><div class="v">${money(pay.wmae_pay_rate_baseline, 2)} → ${money(pay.wmae_pay_rate_with_weather, 2)}</div><div class="s">${fmtPct(pay.error_reduction_pct)} error change</div></div>
    </div>
    <div class="chart">
      <div class="chart-key"><span><i style="background:var(--fg)"></i>actual trips</span><span><i style="background:var(--fg-3)"></i>baseline</span><span><i style="background:var(--signal)"></i>with weather</span><span><i style="background:var(--rain);height:6px"></i>precip</span><span style="margin-left:auto">sum across ${""}tracked zones · holdout</span></div>
      ${chart(h.city_hourly)}
    </div>
    <div class="two">
      ${coefTable("Trip demand · log(1 + trips) residual", bt.final_fit.demand, (b) => (Math.exp(b) - 1) * 100, "% trips")}
      ${coefTable("Pay per engaged hour · $ residual", bt.final_fit.pay, (b) => b, "$/hr")}
    </div>
    ${assumptions}
    <section class="note">
      <div class="block-head" style="padding-left:0"><h2>What this does and doesn't show</h2></div>
      <p><b>Measured:</b> how weather moves trip volume and pay per engaged hour, by zone, on held-out days.
      <b>Not measured:</b> what a driver earns per <i>logged-in</i> hour (it needs idle time), whether the event prior is right, and whether drivers who follow the plan earn more.
      The last one needs a controlled pilot with driver earnings data.</p>
    </section>`;
}

function coefTable(title, fit, transform, unit) {
  const rows = fit.coefs.filter((c) => c.name !== "intercept").map((c) => {
    if (c.p == null) {
      return `<tr><td>${esc(c.name)}</td><td class="n" colspan="3" style="color:var(--fg-3)">no variation in this data</td></tr>`;
    }
    const sig = c.p < 0.05;
    return `<tr class="${sig ? "sig" : ""}"><td>${esc(c.name)}</td>
      <td class="n">${transform(c.beta).toFixed(2)}</td>
      <td class="n">[${transform(c.ci95[0]).toFixed(2)}, ${transform(c.ci95[1]).toFixed(2)}]</td>
      <td class="n">${c.p < 0.001 ? "<0.001" : c.p.toFixed(3)}</td></tr>`;
  }).join("");
  return `<section><div class="block-head" style="padding-left:0"><h2>${esc(title)}</h2></div>
    <table class="t"><thead><tr><th>Feature</th><th>Effect (${unit})</th><th>95% CI</th><th>p</th></tr></thead><tbody>${rows}</tbody></table>
    <p class="muted" style="margin-top:8px">n = ${fit.n.toLocaleString()} · R² = ${fit.r2 == null ? "—" : fit.r2.toFixed(3)} · SE ${esc(fit.se_kind)}</p></section>`;
}

function chart(series) {
  if (!series || !series.length) return "";
  const W = 1000, H = 260, padL = 44, padB = 22, rainH = 40;
  const n = series.length;
  const ymax = Math.max(...series.map((s) => Math.max(s.actual, s.baseline, s.with_weather))) * 1.05;
  const pmax = Math.max(1, ...series.map((s) => s.precip_mm));
  const x = (i) => padL + (i / (n - 1)) * (W - padL - 4);
  const y = (v) => (H - padB - rainH) - (v / ymax) * (H - padB - rainH - 8);
  const line = (k) => series.map((s, i) => `${i ? "L" : "M"}${x(i).toFixed(1)},${y(s[k]).toFixed(1)}`).join("");
  const bars = series.map((s, i) => {
    if (s.precip_mm < 0.05) return "";
    const bh = (s.precip_mm / pmax) * (rainH - 6);
    return `<rect x="${x(i) - 1}" y="${H - padB - bh}" width="2.2" height="${bh}" fill="#5aa9ff"/>`;
  }).join("");
  const ticks = [0, 0.5, 1].map((f) => `<text x="${padL - 8}" y="${y(ymax * f) + 4}" text-anchor="end">${Math.round(ymax * f).toLocaleString()}</text>
    <line x1="${padL}" x2="${W}" y1="${y(ymax * f)}" y2="${y(ymax * f)}" stroke="#22272e"/>`).join("");
  const days = series.map((s, i) => [s.ts, i]).filter(([ts]) => ts.endsWith("T00")).map(([ts, i]) =>
    `<text x="${x(i)}" y="${H - 6}" text-anchor="middle">${ts.slice(5, 10)}</text>`).join("");
  return `<svg viewBox="0 0 ${W} ${H}" preserveAspectRatio="none" font-family="Plex Mono, monospace" font-size="10" fill="#6b7280">
    ${ticks}${bars}
    <path d="${line("baseline")}" fill="none" stroke="#6b7280" stroke-width="1"/>
    <path d="${line("actual")}" fill="none" stroke="#e8eaed" stroke-width="1"/>
    <path d="${line("with_weather")}" fill="none" stroke="#d4ff3a" stroke-width="1.2"/>
    ${days}</svg>`;
}

// ── boot ──────────────────────────────────────────────────────────────────
(function boot() {
  const now = new Date();
  const startSel = form.elements.start;
  if (now.getHours() >= 6) startSel.value = String(Math.min(23, now.getHours() + (now.getMinutes() > 30 ? 1 : 0)));
  try { initMap(); } catch (e) { console.warn("map disabled", e); }
  refresh();
  setInterval(refresh, 5 * 60 * 1000);
})();
