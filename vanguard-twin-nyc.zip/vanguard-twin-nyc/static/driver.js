"use strict";
// Driver view: one shift, pinned to a start time, re-fetched every 5 minutes
// so live weather/events/traffic update without moving the plan's clock.

const $ = (s) => document.querySelector(s);
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const money = (x) => (x < 0 ? "−$" : "$") + Math.abs(Math.round(x));
const clock = (d) => {
  d = d instanceof Date ? d : new Date(d);
  const h = d.getHours() % 12 || 12, m = d.getMinutes();
  return h + (m ? ":" + String(m).padStart(2, "0") : "") + (d.getHours() < 12 ? "am" : "pm");
};
const localIso = (d) => {
  const p = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}T${p(d.getHours())}:${p(d.getMinutes())}`;
};
const span = (ms) => {
  const m = Math.max(0, Math.round(ms / 60000));
  return m >= 60 ? `${Math.floor(m / 60)}h ${String(m % 60).padStart(2, "0")}m` : `${m} min`;
};

const KEY = "vanguard.shift.v1";
const store = {
  get() { try { return JSON.parse(localStorage.getItem(KEY)); } catch { return null; } },
  set(v) { try { localStorage.setItem(KEY, JSON.stringify(v)); } catch { /* private mode */ } },
  clear() { try { localStorage.removeItem(KEY); } catch { /* ignore */ } },
};

let shift = store.get();
let plan = null;

// ── Setup: pick length/start, then one tap on a starting point starts the shift ──
const draft = { hours: 5, later: false };

function showSetup() {
  $("#setup").hidden = false; $("#shift").hidden = true; $("#editBtn").hidden = true; $("#liveDot").hidden = true;
  const last = store.get() || shift;
  if (last && last.hours) draft.hours = last.hours;
  $("#hoursOut").textContent = draft.hours + "h";
  $("#laterHour").value = String(Math.min(23, new Date().getHours() + 1));
  document.querySelectorAll(".d-choice").forEach((x) => x.classList.remove("on"));
}

document.querySelectorAll("#startSeg button").forEach((b) => b.addEventListener("click", () => {
  draft.later = b.dataset.start === "later";
  document.querySelectorAll("#startSeg button").forEach((x) => x.classList.toggle("on", x === b));
  $("#laterHour").hidden = !draft.later;
}));

document.querySelectorAll("[data-step=hours]").forEach((b) => b.addEventListener("click", () => {
  draft.hours = Math.max(2, Math.min(10, draft.hours + +b.dataset.d));
  $("#hoursOut").textContent = draft.hours + "h";
}));

document.querySelectorAll(".d-choice").forEach((btn) => btn.addEventListener("click", async () => {
  const o = btn.dataset.origin;
  let lat = null, lon = null;
  btn.classList.add("on");
  if (o === "here") {
    const hint = $("#gpsHint");
    hint.hidden = false; hint.textContent = "Getting your location…";
    try {
      ({ lat, lon } = await locate());
      hint.hidden = true;
    } catch {
      hint.textContent = "Couldn't get your location. Tap the closest area instead.";
      btn.classList.remove("on");
      return;
    }
  }
  const start = new Date();
  start.setMinutes(0, 0, 0);
  if (draft.later) {
    start.setHours(+$("#laterHour").value);
    if (start < new Date(Date.now() - 3600e3)) start.setDate(start.getDate() + 1);
  }
  shift = { origin: o, lat, lon, hours: draft.hours,
            startAt: localIso(start), departedAt: localIso(draft.later ? start : new Date()) };
  store.set(shift);
  showShift();
}));

function locate() {
  return new Promise((res, rej) => {
    if (!navigator.geolocation) return rej(new Error("no geolocation"));
    navigator.geolocation.getCurrentPosition(
      (p) => res({ lat: p.coords.latitude, lon: p.coords.longitude }),
      rej, { enableHighAccuracy: true, timeout: 12000, maximumAge: 60000 });
  });
}

// ── Shift ────────────────────────────────────────────────────────────────
async function fetchPlan() {
  const q = new URLSearchParams({ origin: shift.origin, hours: shift.hours, start_at: shift.startAt });
  if (shift.origin === "here") { q.set("lat", shift.lat); q.set("lon", shift.lon); }
  const r = await fetch("/api/plan?" + q);
  const body = await r.json().catch(() => ({ error: "server " + r.status }));
  if (!r.ok || body.error) throw new Error(body.error || "server " + r.status);
  plan = body;
  renderLive();
  render();
}

function showShift() {
  $("#setup").hidden = true; $("#shift").hidden = false; $("#editBtn").hidden = false; $("#liveDot").hidden = false;
  keepAwake();
  fetchPlan().catch((e) => { $("#now").innerHTML = `<div class="d-eyebrow">Offline</div><div class="d-why">Couldn't load the plan (${esc(e.message)}). Retrying…</div>`; });
}

function renderLive() {
  const l = plan.live, ok = ["weather", "traffic"].every((k) => l[k] && l[k].status === "live");
  const el = $("#liveDot");
  el.className = "d-live " + (ok ? "ok" : "warn");
  $("#liveText").textContent = ok ? "live" : "partial data";
}

function hoursFlat() {
  return plan.plan.blocks.flatMap((b) => b.hours.map((h) => ({ ...h, block: b })));
}

function render() {
  if (!plan) return;
  const now = new Date();
  const start = new Date(plan.start);
  const end = new Date(start.getTime() + plan.shift_hours * 3600e3);
  const blocks = plan.plan.blocks;
  const idx = blocks.findIndex((b) => now >= new Date(b.start) && now < new Date(b.end));
  const cur = idx >= 0 ? blocks[idx] : null;

  const pb = plan.plan.band;
  $("#strip").innerHTML = `<span>${clock(start)}–${clock(end)}</span><span>est. ${money(pb[0] * plan.shift_hours)}–${money(pb[1] * plan.shift_hours)} shift</span>`;

  // Shift over
  if (now >= end) {
    $("#now").innerHTML = `<div class="d-done"><div class="d-eyebrow">Shift done</div>
      <div class="num">${money(plan.plan.total)}</div><div class="d-why">was the plan's estimate for this shift</div></div>`;
    $("#next").hidden = true; $("#alert").hidden = true;
    renderProgress(now, start); renderRest(now);
    return;
  }

  // Current or first stop
  const b = cur || blocks[0];
  const before = now < start;
  const arriveMin = Math.round(b.arrive.minutes);
  // The plan's clock is floored to the hour; arrival counts from when the driver actually left.
  const departed = new Date(shift.departedAt || plan.start);
  const arriving = !before && b === blocks[0] && now < new Date(Math.max(start, departed) + arriveMin * 60e3);
  let eyebrow;
  if (before) eyebrow = `Shift starts ${clock(start)} · ${span(start - now)}`;
  else if (arriving) eyebrow = `Head to · ~${arriveMin} min`;
  else eyebrow = `Now · until ${clock(b.end)}`;

  const rows = b.hours;
  const lo = rows.reduce((s, h) => s + Math.max(0, h.lo), 0) / rows.length;
  const hi = rows.reduce((s, h) => s + Math.max(0, h.hi), 0) / rows.length;
  // Event let-outs already show in the alert banner, so show the next reason here
  const why = b.why.find((w) => !/lets out|arrivals/.test(w)) || "";

  $("#now").innerHTML = `
    <div class="d-eyebrow">${esc(eyebrow)}</div>
    <div class="d-zone">${esc(b.region)}</div>
    <div class="d-stage">Between trips, wait at ${esc(cur ? stagingNow(b, now).staging : b.staging)}</div>
    <div class="d-money"><span class="num">${money(lo)}–${money(hi)}</span><span>/hr expected here</span></div>
    ${why ? `<div class="d-why">${esc(why)}</div>` : ""}
    ${before || arriving ? `<div class="d-how">${esc(b.arrive.how)}</div>` : `<div class="d-how">Take any trip. If it drops you outside ${esc(b.region)}, accept trips heading back.</div>`}
    <div class="d-nav">
      <a class="go" href="${gmaps(cur ? stagingNow(b, now) : b)}" target="_blank" rel="noopener">Google Maps</a>
      <a class="alt" href="${waze(cur ? stagingNow(b, now) : b)}" target="_blank" rel="noopener">Waze</a>
    </div>`;

  // Next move
  const nxt = before ? null : blocks[(cur ? idx : 0) + 1];
  const nx = $("#next");
  nx.hidden = false;
  if (before) {
    const leave = new Date(start);
    nx.innerHTML = `<span class="lbl">Leave</span><span class="what">${clock(leave)} from ${esc(plan.origin.label)}</span>
      <span class="sub">${arriveMin} min drive${b.arrive.cost ? " · " + money(b.arrive.cost) + " tolls + gas" : ""}</span>
      <span class="count">${span(leave - now)}<small>to go</small></span>`;
  } else if (nxt) {
    const at = new Date(nxt.arrive.leave_at);
    nx.innerHTML = `<span class="lbl">Next · from ${clock(at)}</span><span class="what">Head to ${esc(nxt.region)}</span>
      <span class="sub">${esc(nxt.arrive.how)}</span>
      <span class="count">${span(at - now)}<small>${at > now ? "until you head over" : "head over now"}</small></span>`;
  } else {
    nx.innerHTML = `<span class="lbl">Next</span><span class="what">Stay here to the end</span>
      <span class="sub">Shift ends ${clock(end)}</span><span class="count">${span(end - now)}<small>left</small></span>`;
  }

  renderAlert(now);
  renderProgress(now, start);
  renderRest(now);
  $("#fine").textContent = `Estimates from public NYC trip data${plan.calibration.mode === "calibrated" ? "" : " (uncalibrated priors)"}, assuming you're on a trip ~${Math.round(+(plan.assumptions[0].value.replace("%", "")))}% of the time. Not a guarantee. Don't use while driving.`;
}

function renderAlert(now) {
  const soon = hoursFlat().filter((h) => {
    const t = new Date(h.t);
    return t >= new Date(now.getTime() - 3600e3) && t <= new Date(now.getTime() + 90 * 60e3);
  });
  const ev = soon.find((h) => h.event_why);
  const wet = soon.find((h) => h.precip_mm >= 0.5 && new Date(h.t) > now);
  const a = $("#alert");
  if (ev) { a.className = "d-alert"; a.textContent = ev.event_why + " · " + ev.block.region; a.hidden = false; }
  else if (wet) { a.className = "d-alert rain"; a.textContent = `Rain from ${clock(wet.t)}. Expect more requests; stay in your area.`; a.hidden = false; }
  else a.hidden = true;
}

function renderProgress(now, start) {
  let byNow = 0;
  for (const h of hoursFlat()) {
    const f = Math.max(0, Math.min(1, (now - new Date(h.t)) / 3600e3));
    byNow += h.earned * f;
  }
  const total = plan.plan.total, [lo, hi] = plan.plan.band.map((x) => x * plan.shift_hours);
  const pct = total > 0 ? Math.min(100, (Math.max(0, byNow) / total) * 100) : 0;
  $("#progress").innerHTML = `
    <div class="d-prog-row"><span>On plan by now <b>${money(Math.max(0, byNow))}</b></span><span>shift est. <b>${money(total)}</b></span></div>
    <div class="d-track"><div class="now" style="width:${pct}%"></div></div>
    <div class="d-prog-row" style="margin-top:6px"><span></span><span>likely ${money(lo)}–${money(hi)}</span></div>`;
}

function renderRest(now) {
  $("#rest").innerHTML = plan.plan.blocks.map((b) => {
    const s = new Date(b.start), e = new Date(b.end);
    const cls = now >= e ? "done" : (now >= s ? "cur" : "");
    return `<li class="${cls}"><span class="t">${clock(s)}–${clock(e)}</span>
      <div><div class="z">${esc(b.region)}</div><div class="s">wait at ${esc(b.staging)}</div></div>
      <span class="a">${money(b.earned)}</span></li>`;
  }).join("");
}

// The best waiting spot inside an area can change hour to hour (e.g. an event lets out)
function stagingNow(b, now) {
  const h = [...b.hours].reverse().find((x) => new Date(x.t) <= now) || b.hours[0];
  return { staging: h.staging, lat: h.lat, lon: h.lon };
}

function gmaps(b) {
  const cross = /&/.test(b.staging) && !/lot/i.test(b.staging);
  const dest = cross ? b.staging.replace(/\s*\(.*?\)/g, "") + ", New York, NY" : `${b.lat},${b.lon}`;
  return "https://www.google.com/maps/dir/?api=1&travelmode=driving&destination=" + encodeURIComponent(dest);
}
const waze = (b) => `https://waze.com/ul?ll=${b.lat},${b.lon}&navigate=yes`;

// ── Actions ──────────────────────────────────────────────────────────────
$("#editBtn").addEventListener("click", showSetup);
$("#endBtn").addEventListener("click", () => { store.clear(); shift = null; plan = null; showSetup(); });
$("#replanBtn").addEventListener("click", async () => {
  const btn = $("#replanBtn");
  btn.textContent = "Locating…";
  try {
    const pos = await locate();
    const end = new Date(new Date(shift.startAt).getTime() + shift.hours * 3600e3);
    const now = new Date(); now.setMinutes(0, 0, 0);
    shift = { ...shift, origin: "here", lat: pos.lat, lon: pos.lon, startAt: localIso(now), departedAt: localIso(new Date()),
              hours: Math.max(1, Math.ceil((end - now) / 3600e3)) };
    store.set(shift);
    await fetchPlan();
    btn.textContent = "Replanned";
  } catch {
    btn.textContent = "No GPS. Try again";
  }
  setTimeout(() => { btn.textContent = "Replan from here"; }, 2500);
});

// Keep the screen on while a shift is open (where supported)
let lock = null;
async function keepAwake() {
  try { if ("wakeLock" in navigator && !lock) { lock = await navigator.wakeLock.request("screen"); lock.addEventListener("release", () => { lock = null; }); } } catch { /* not allowed */ }
}
document.addEventListener("visibilitychange", () => { if (!document.hidden && shift) { keepAwake(); render(); } });

// ── Boot ─────────────────────────────────────────────────────────────────
if (shift && new Date(new Date(shift.startAt).getTime() + shift.hours * 3600e3 + 3 * 3600e3) > new Date()) showShift();
else { store.clear(); shift = null; showSetup(); }
setInterval(render, 15000);
setInterval(() => { if (shift) fetchPlan().catch(() => {}); }, 5 * 60 * 1000);
